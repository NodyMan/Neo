package uz.max.neo_app

import android.app.Notification
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// Lets Neo read phone notifications (only after Max turns on "Notification access" for Neo).
class NeoNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            if (sbn.packageName == packageName) return
            val n = sbn.notification ?: return
            if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0) return
            if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
            val ex = n.extras ?: return
            val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val body = ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT)
            val text = body?.toString() ?: ""
            if (title.isEmpty() && text.isEmpty()) return
            val app = try {
                packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
            } catch (e: Exception) {
                sbn.packageName
            }
            val o = JSONObject()
            o.put("app", app)
            o.put("pkg", sbn.packageName)
            o.put("title", title.take(200))
            o.put("text", text.take(800))
            o.put("ts", sbn.postTime)
            NeoNotes.add(this, o)
        } catch (e: Exception) {
        }
    }
}

object NeoNotes {
    private const val FILE = "neo_notifications.json"
    private const val KEEP = 300

    @Synchronized
    fun read(ctx: Context): JSONArray {
        return try {
            JSONArray(File(ctx.filesDir, FILE).readText())
        } catch (e: Exception) {
            JSONArray()
        }
    }

    @Synchronized
    fun add(ctx: Context, o: JSONObject) {
        val arr = read(ctx)
        // Apps often re-post the same notification; skip exact repeats.
        val from = maxOf(0, arr.length() - 20)
        for (i in from until arr.length()) {
            val p = arr.optJSONObject(i) ?: continue
            if (p.optString("pkg") == o.optString("pkg") && p.optString("title") == o.optString("title") && p.optString("text") == o.optString("text")) return
        }
        arr.put(o)
        val out = JSONArray()
        val start = maxOf(0, arr.length() - KEEP)
        for (i in start until arr.length()) out.put(arr.get(i))
        File(ctx.filesDir, FILE).writeText(out.toString())
    }

    @Synchronized
    fun since(ctx: Context, sinceMs: Long): String {
        val arr = read(ctx)
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val p = arr.optJSONObject(i) ?: continue
            if (p.optLong("ts") > sinceMs) out.put(p)
        }
        return out.toString()
    }
}
