#!/usr/bin/env bash
# Generates the android/ folder and applies Neo's Android settings.
# Run from the neo_app folder. Safe to run more than once.
set -e

flutter create --platforms=android --org uz.max --project-name neo_app .

M=android/app/src/main/AndroidManifest.xml
RES=android/app/src/main/res

# Permissions: internet, microphone, alarms/timers, see installed apps (to open them by name).
if ! grep -q 'android.permission.RECORD_AUDIO' "$M"; then
  sed -i '0,/<application/s//<uses-permission android:name="android.permission.INTERNET"\/>\n    <uses-permission android:name="android.permission.RECORD_AUDIO"\/>\n    <queries><intent><action android:name="android.intent.action.TTS_SERVICE"\/><\/intent><\/queries>\n    <application/' "$M"
fi
if ! grep -q 'com.android.alarm.permission.SET_ALARM' "$M"; then
  sed -i '0,/<application/s//<uses-permission android:name="com.android.alarm.permission.SET_ALARM"\/>\n    <uses-permission android:name="android.permission.QUERY_ALL_PACKAGES"\/>\n    <application/' "$M"
fi

# Home-screen shortcuts (long-press the Neo icon).
if ! grep -q 'android.app.shortcuts' "$M"; then
  sed -i '0,/<intent-filter>/s//<meta-data android:name="android.app.shortcuts" android:resource="@xml\/shortcuts"\/>\n            <intent-filter>/' "$M"
fi

sed -i 's/android:label="neo_app"/android:label="Neo"/' "$M"
if ! grep -q 'android:roundIcon' "$M"; then
  sed -i 's/android:icon="@mipmap\/ic_launcher"/android:icon="@mipmap\/ic_launcher"\n        android:roundIcon="@mipmap\/ic_launcher_round"/' "$M"
fi

# Neo's Android code (phone actions, voice playback, shortcuts).
KT=$(find android/app/src/main -name MainActivity.kt | head -1)
if [ -z "$KT" ]; then
  KT=android/app/src/main/kotlin/uz/max/neo_app/MainActivity.kt
  mkdir -p "$(dirname "$KT")"
fi
find android/app/src/main -name 'MainActivity.java' -delete
cp tool/android/MainActivity.kt "$KT"
cp tool/android/NeoNotificationListener.kt "$(dirname "$KT")/NeoNotificationListener.kt"

# Notification reader service (Max turns it on in Android settings → Notification access).
if ! grep -q 'NeoNotificationListener' "$M"; then
  sed -i 's#</application>#    <service android:name=".NeoNotificationListener" android:label="Neo" android:exported="true" android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE">\n            <intent-filter><action android:name="android.service.notification.NotificationListenerService"/></intent-filter>\n        </service>\n    </application>#' "$M"
fi

# Resources: shortcuts, strings, Neo icon.
mkdir -p "$RES/xml" "$RES/values" "$RES/mipmap-anydpi-v26"
cp tool/android/res/xml/shortcuts.xml "$RES/xml/shortcuts.xml"
cp tool/android/res/values/neo_strings.xml "$RES/values/neo_strings.xml"
for d in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  mkdir -p "$RES/mipmap-$d"
  cp "tool/android/icons/ic_launcher-$d.png" "$RES/mipmap-$d/ic_launcher.png"
  cp "tool/android/icons/ic_launcher_round-$d.png" "$RES/mipmap-$d/ic_launcher_round.png"
  cp "tool/android/icons/ic_launcher_foreground-$d.png" "$RES/mipmap-$d/ic_launcher_foreground.png"
done
cat > "$RES/values/neo_icon_colors.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="neo_icon_background">#F3EFE8</color>
</resources>
XML
for n in ic_launcher ic_launcher_round; do
  cat > "$RES/mipmap-anydpi-v26/$n.xml" <<'XML'
<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/neo_icon_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
XML
done

for f in android/app/build.gradle.kts android/app/build.gradle; do
  if [ -f "$f" ]; then
    sed -i -E 's/minSdk = flutter\.minSdkVersion/minSdk = 24/; s/minSdkVersion flutter\.minSdkVersion/minSdkVersion 24/' "$f"
  fi
done

echo "Android project ready."
