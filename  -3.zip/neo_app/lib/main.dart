import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config.dart';
import 'neo/neo_brain.dart';
import 'neo/phone.dart';
import 'screens/login_screen.dart';
import 'screens/shell.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabasePublishableKey);
  Phone.init();
  runApp(const NeoApp());
}

class NeoApp extends StatelessWidget {
  const NeoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Color>(
      valueListenable: neo.colorListenable,
      builder: (context, color, _) => MaterialApp(
        title: 'Neo',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(color),
        home: const AuthGate(),
      ),
    );
  }
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: supabase.auth.onAuthStateChange,
      builder: (context, _) {
        final signedIn = supabase.auth.currentSession != null;
        // Start/stop Neo's live subscriptions after this frame, never during build.
        WidgetsBinding.instance.addPostFrameCallback((_) => signedIn ? neo.start() : neo.stop());
        return signedIn ? const Shell() : const LoginScreen();
      },
    );
  }
}
