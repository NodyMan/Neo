/// Neo's offline mini-brain: understands simple phone commands without internet
/// (English, Russian, Uzbek). Anything else waits in the outbox until Neo is online.
class LocalBrain {
  LocalBrain._();

  /// Returns a reply + phone actions, or null if it needs the real (online) Neo.
  static ({String reply, List<Map<String, dynamic>> actions})? handle(String input) {
    final t = input.toLowerCase().trim().replaceAll(RegExp(r'[!?.,]+$'), '');
    final ru = RegExp(r'[а-яё]').hasMatch(t);
    String say(String en, String r) => ru ? r : en;

    // Timer: "set a 10 minute timer", "таймер на 5 минут", "10 daqiqaga taymer"
    if (RegExp(r'(timer|таймер|taymer)').hasMatch(t)) {
      var secs = 0;
      final h = RegExp(r'(\d+)\s*(h\b|hour|час|soat)').firstMatch(t);
      final m = RegExp(r'(\d+)\s*(m\b|min|мин|daqiqa)').firstMatch(t);
      final s = RegExp(r'(\d+)\s*(s\b|sec|сек|soniya)').firstMatch(t);
      if (h != null) secs += int.parse(h.group(1)!) * 3600;
      if (m != null) secs += int.parse(m.group(1)!) * 60;
      if (s != null) secs += int.parse(s.group(1)!);
      if (secs == 0) {
        final n = RegExp(r'(\d+)').firstMatch(t);
        if (n != null) secs = int.parse(n.group(1)!) * 60;
      }
      if (secs > 0) {
        final label = secs >= 60 ? '${secs ~/ 60} min' : '$secs s';
        return (
          reply: say('Timer set for $label.', 'Таймер на $label поставил.'),
          actions: <Map<String, dynamic>>[
            {'action': 'timer', 'target': '$secs', 'extra': 'Neo'}
          ],
        );
      }
    }

    // Alarm: "wake me up at 7", "alarm 6:30", "разбуди в 7:15", "будильник на 8"
    if (RegExp(r'(wake|alarm|будильник|разбуди|uyg.?ot|budilnik)').hasMatch(t)) {
      final tm = RegExp(r'(\d{1,2})(?:[:.](\d{2}))?\s*(am|pm)?').firstMatch(t);
      if (tm != null) {
        var hh = int.parse(tm.group(1)!);
        final mm = int.tryParse(tm.group(2) ?? '') ?? 0;
        if (tm.group(3) == 'pm' && hh < 12) hh += 12;
        if (tm.group(3) == 'am' && hh == 12) hh = 0;
        if (hh <= 23 && mm <= 59) {
          final time = '${hh.toString().padLeft(2, '0')}:${mm.toString().padLeft(2, '0')}';
          return (
            reply: say('Alarm set for $time.', 'Будильник на $time готов.'),
            actions: <Map<String, dynamic>>[
              {'action': 'alarm', 'target': time, 'extra': 'Neo'}
            ],
          );
        }
      }
    }

    // Call: "call 90 123 45 67", "позвони 901234567"
    final call = RegExp(r'(call|dial|позвони|набери|qo.?ng.?iroq)\D*([+\d][\d\s\-()]{6,})').firstMatch(t);
    if (call != null) {
      final phone = call.group(2)!.replaceAll(RegExp(r'[^\d+]'), '');
      return (reply: say('Opening the dialer for $phone.', 'Открываю звонок на $phone.'), actions: <Map<String, dynamic>>[
        {'action': 'call', 'target': phone}
      ]);
    }

    // Music controls: "next song", "pause", "следующая песня", "пауза", "громче"
    final media = RegExp(r'^(next( song| track)?|skip|следующ\S*( песн\S*| трек)?|previous( song)?|предыдущ\S*|pause( music)?|пауза|stop music|resume|play|продолжи|louder|volume up|громче|quieter|volume down|тише)$').firstMatch(t);
    if (media != null) {
      final w = media.group(0)!;
      final cmd = RegExp(r'next|skip|следующ').hasMatch(w)
          ? 'next'
          : RegExp(r'prev|предыдущ').hasMatch(w)
              ? 'previous'
              : RegExp(r'pause|пауза|stop').hasMatch(w)
                  ? 'pause'
                  : RegExp(r'louder|up|громче').hasMatch(w)
                      ? 'volume_up'
                      : RegExp(r'quieter|down|тише').hasMatch(w)
                          ? 'volume_down'
                          : 'play';
      return (reply: say('Done.', 'Готово.'), actions: <Map<String, dynamic>>[
        {'action': 'media', 'target': cmd}
      ]);
    }

    // Camera
    if (RegExp(r'^(open (the )?camera|camera|открой камеру|камера|kamera(ni och)?)$').hasMatch(t)) {
      return (reply: say('Camera.', 'Камера.'), actions: <Map<String, dynamic>>[
        {'action': 'camera'}
      ]);
    }

    // Settings: "open wifi settings", "открой блютуз"
    final st = RegExp(r'(wi-?fi|вай-?фай|bluetooth|блютуз|battery|батаре|location|геолокац|sound|звук|display|экран)').firstMatch(t);
    if (st != null && RegExp(r'(open|settings|открой|настройк|sozlama)').hasMatch(t)) {
      final k = st.group(1)!;
      final target = k.contains('fi') || k.contains('фай')
          ? 'wifi'
          : k.contains('blue') || k.contains('блю')
              ? 'bluetooth'
              : k.contains('batt') || k.contains('батар')
                  ? 'battery'
                  : k.contains('loc') || k.contains('гео')
                      ? 'location'
                      : k.contains('sound') || k.contains('звук')
                          ? 'sound'
                          : 'display';
      return (reply: say('Opening $target settings.', 'Открываю настройки.'), actions: <Map<String, dynamic>>[
        {'action': 'settings', 'target': target}
      ]);
    }

    // Navigate: "take me to Chorsu", "отвези в Чорсу", "маршрут до ..."
    final nav = RegExp(r'^(take me to|navigate to|directions to|drive to|отвези( меня)? (в|на|до)|маршрут до|поехали (в|на))\s+(.+)$').firstMatch(t);
    if (nav != null) {
      final place = nav.group(nav.groupCount)!;
      return (reply: say('Starting navigation to $place.', 'Строю маршрут: $place.'), actions: <Map<String, dynamic>>[
        {'action': 'navigate', 'target': place}
      ]);
    }

    // Open app: "open telegram", "открой телеграм", "telegramni och"
    final openEn = RegExp(r'^(open|launch|start|открой|запусти|включи)\s+(.+)$').firstMatch(t);
    final openUz = openEn == null ? RegExp(r'^(.+?)(ni)?\s+och$').firstMatch(t) : null;
    final rawApp = openEn?.group(2) ?? openUz?.group(1);
    if (rawApp != null && rawApp.trim().isNotEmpty) {
      var app = rawApp.trim();
      app = _appAliases[app] ?? app;
      return (reply: say('Opening $app.', 'Открываю $app.'), actions: <Map<String, dynamic>>[
        {'action': 'open_app', 'target': app, 'package': _packages[app.toLowerCase()] ?? ''}
      ]);
    }
    return null;
  }

  static const _appAliases = {
    'телеграм': 'Telegram',
    'телеграмм': 'Telegram',
    'ватсап': 'WhatsApp',
    'вотсап': 'WhatsApp',
    'инстаграм': 'Instagram',
    'ютуб': 'YouTube',
    'хром': 'Chrome',
    'карты': 'Maps',
    'камеру': 'Camera',
    'настройки': 'Settings',
    'калькулятор': 'Calculator',
  };

  static const _packages = {
    'telegram': 'org.telegram.messenger',
    'whatsapp': 'com.whatsapp',
    'instagram': 'com.instagram.android',
    'youtube': 'com.google.android.youtube',
    'chrome': 'com.android.chrome',
    'gmail': 'com.google.android.gm',
    'maps': 'com.google.android.apps.maps',
    'google maps': 'com.google.android.apps.maps',
    'spotify': 'com.spotify.music',
    'settings': 'com.android.settings',
  };
}
