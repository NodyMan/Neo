import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// "Soft Day" palette.
class NeoColors {
  static const ground = Color(0xFFF3EFE8);
  static const card = Color(0xFFFFFFFF);
  static const ink = Color(0xFF1F1D1A);
  static const muted = Color(0xFF6B655C);
  static const line = Color(0xFFE2DCD1);
  static const chip = Color(0xFFF8F6F2);
  static const onInk = Color(0xFFF3EFE8);
  static const onInkMuted = Color(0xFFCFC8BC);
  static const good = Color(0xFF2F6B3F);
  static const danger = Color(0xFFB3261E);

  static const accents = <Color>[
    Color(0xFFF08A5D), // coral
    Color(0xFF9DD3A8), // sage
    Color(0xFFF5C451), // butter
    Color(0xFF8FA8F0), // periwinkle
  ];
}

ThemeData buildTheme(Color accent) {
  final base = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: accent,
      primary: NeoColors.ink,
      onPrimary: NeoColors.onInk,
      surface: NeoColors.ground,
      onSurface: NeoColors.ink,
    ),
    scaffoldBackgroundColor: NeoColors.ground,
  );
  final text = GoogleFonts.plusJakartaSansTextTheme(base.textTheme).apply(
    bodyColor: NeoColors.ink,
    displayColor: NeoColors.ink,
  );
  return base.copyWith(
    textTheme: text,
    appBarTheme: AppBarTheme(
      backgroundColor: NeoColors.ground,
      foregroundColor: NeoColors.ink,
      elevation: 0,
      scrolledUnderElevation: 0,
      titleTextStyle: text.titleLarge?.copyWith(fontWeight: FontWeight.w800),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: NeoColors.card,
      hintStyle: const TextStyle(color: NeoColors.muted),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
  );
}

/// Rounded white card used everywhere.
class SoftCard extends StatelessWidget {
  const SoftCard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.color = NeoColors.card, this.radius = 24, this.onTap});
  final Widget child;
  final EdgeInsets padding;
  final Color color;
  final double radius;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final box = Container(
      padding: padding,
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(radius)),
      child: child,
    );
    if (onTap == null) return box;
    return Material(
      color: Colors.transparent,
      child: InkWell(borderRadius: BorderRadius.circular(radius), onTap: onTap, child: box),
    );
  }
}

String formatSum(num v) {
  final s = v.round().abs().toString();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write(' ');
    b.write(s[i]);
  }
  return (v < 0 ? '−' : '') + b.toString();
}
