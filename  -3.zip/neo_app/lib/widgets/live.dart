import 'dart:async';

import 'package:supabase_flutter/supabase_flutter.dart';

/// A live Supabase stream that never dies: if the login token expired while the
/// phone was asleep (or the internet dropped), it refreshes the token and reconnects
/// instead of showing an error.
Stream<List<Map<String, dynamic>>> liveStream(Stream<List<Map<String, dynamic>>> Function() open) async* {
  var wait = 2;
  while (true) {
    try {
      await for (final rows in open()) {
        wait = 2;
        yield rows;
      }
      return; // closed normally (signed out / disposed)
    } catch (_) {
      await freshToken();
      await Future<void>.delayed(Duration(seconds: wait));
      if (wait < 30) wait *= 2;
    }
  }
}

/// A valid access token, refreshing it first if it's expired or about to expire.
Future<String?> freshToken() async {
  final auth = Supabase.instance.client.auth;
  final s = auth.currentSession;
  if (s == null) return null;
  final exp = s.expiresAt;
  final soon = exp == null || DateTime.fromMillisecondsSinceEpoch(exp * 1000).isBefore(DateTime.now().add(const Duration(seconds: 90)));
  if (soon) {
    try {
      await auth.refreshSession();
    } catch (_) {}
  }
  return auth.currentSession?.accessToken;
}
