import 'package:flutter/material.dart';

class Cat {
  const Cat(this.name, this.icon, this.color);
  final String name;
  final IconData icon;
  final Color color;
}

/// Spending categories (debit) and income categories (credit).
const spendCats = <Cat>[
  Cat('Food', Icons.restaurant_rounded, Color(0xFFF08A5D)),
  Cat('Transport', Icons.directions_car_rounded, Color(0xFF8FA8F0)),
  Cat('Shopping', Icons.shopping_bag_rounded, Color(0xFFE7A0C7)),
  Cat('Bills', Icons.receipt_long_rounded, Color(0xFFF5C451)),
  Cat('Health', Icons.favorite_rounded, Color(0xFFE2475C)),
  Cat('Entertainment', Icons.sports_esports_rounded, Color(0xFFB79CF0)),
  Cat('Education', Icons.school_rounded, Color(0xFF6CC3D5)),
  Cat('Home', Icons.home_rounded, Color(0xFF9DD3A8)),
  Cat('Transfers', Icons.swap_horiz_rounded, Color(0xFFA9A196)),
  Cat('Other', Icons.more_horiz_rounded, Color(0xFFCFC8BC)),
];

const incomeCats = <Cat>[
  Cat('Salary', Icons.work_rounded, Color(0xFF6DBE85)),
  Cat('Freelance', Icons.laptop_mac_rounded, Color(0xFF6CC3D5)),
  Cat('Gift', Icons.card_giftcard_rounded, Color(0xFFE7A0C7)),
  Cat('Refund', Icons.undo_rounded, Color(0xFF8FA8F0)),
  Cat('Transfers', Icons.swap_horiz_rounded, Color(0xFFA9A196)),
  Cat('Other', Icons.more_horiz_rounded, Color(0xFFCFC8BC)),
];

Cat catFor(String? name) {
  for (final c in [...spendCats, ...incomeCats]) {
    if (c.name.toLowerCase() == (name ?? '').toLowerCase()) return c;
  }
  return Cat(name == null || name.isEmpty ? 'Other' : name, Icons.label_rounded, const Color(0xFFCFC8BC));
}

const spendTypes = {'purchase', 'p2p', 'withdrawal', 'fee'};

bool isSpend(Map<String, dynamic> r) => r['direction'] == 'debit' && spendTypes.contains(r['type']);
bool isIncome(Map<String, dynamic> r) => r['direction'] == 'credit' && r['type'] != 'transfer_own';
