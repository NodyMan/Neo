import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../neo/neo_brain.dart';
import '../theme.dart';
import '../widgets/live.dart';

/// Things Neo wants to do. Nothing happens until Max taps Approve;
/// n8n watches approvals.status and carries out approved actions.
class ApprovalsScreen extends StatefulWidget {
  const ApprovalsScreen({super.key});

  @override
  State<ApprovalsScreen> createState() => _ApprovalsScreenState();
}

class _ApprovalsScreenState extends State<ApprovalsScreen> {
  late final Stream<List<Map<String, dynamic>>> pending =
      liveStream(() => supabase.from('approvals').stream(primaryKey: ['id']).eq('status', 'pending').order('ts', ascending: false));

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 4),
          child: Text('Approvals', style: t.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 0, 20, 8),
          child: Text('Neo asks before sending, deleting or changing anything.', style: TextStyle(color: NeoColors.muted)),
        ),
        Expanded(
          child: StreamBuilder<List<Map<String, dynamic>>>(
            stream: pending,
            builder: (context, snap) {
              if (snap.hasError) return Center(child: Text('Error: ${snap.error}'));
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final rows = snap.data!;
              if (rows.isEmpty) {
                return const Center(child: Text('Nothing waiting for you.', style: TextStyle(color: NeoColors.muted)));
              }
              return ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                itemCount: rows.length,
                separatorBuilder: (_, __) => const SizedBox(height: 12),
                itemBuilder: (context, i) => _ApprovalCard(row: rows[i]),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _ApprovalCard extends StatefulWidget {
  const _ApprovalCard({required this.row});
  final Map<String, dynamic> row;

  @override
  State<_ApprovalCard> createState() => _ApprovalCardState();
}

class _ApprovalCardState extends State<_ApprovalCard> {
  bool _busy = false;

  Future<void> _decide(String status) async {
    setState(() => _busy = true);
    try {
      await supabase
          .from('approvals')
          .update({'status': status, 'decided_at': DateTime.now().toUtc().toIso8601String(), 'decided_via': 'app'})
          .eq('id', widget.row['id'])
          .eq('status', 'pending');
      if (status == 'approved') neo.poke();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed: $e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.row;
    final ts = DateTime.tryParse(r['ts']?.toString() ?? '')?.toLocal();
    return SoftCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(color: NeoColors.ground, borderRadius: BorderRadius.circular(12)),
                child: Text(r['action_type']?.toString() ?? 'action', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12)),
              ),
              const Spacer(),
              if (ts != null) Text(DateFormat('d MMM, HH:mm').format(ts), style: const TextStyle(color: NeoColors.muted, fontSize: 12)),
            ],
          ),
          const SizedBox(height: 10),
          SelectableText(r['preview_text']?.toString() ?? r['payload'].toString(), style: const TextStyle(height: 1.4)),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(48), shape: const StadiumBorder(), foregroundColor: NeoColors.ink),
                  onPressed: _busy ? null : () => _decide('rejected'),
                  child: const Text('Reject'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: FilledButton(
                  style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(48), shape: const StadiumBorder(), backgroundColor: NeoColors.ink),
                  onPressed: _busy ? null : () => _decide('approved'),
                  child: const Text('Approve'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
