import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../neo/neo_brain.dart';
import '../theme.dart';
import '../widgets/live.dart';

/// Everything Neo did, newest first, live.
class ActivityScreen extends StatefulWidget {
  const ActivityScreen({super.key});

  @override
  State<ActivityScreen> createState() => _ActivityScreenState();
}

class _ActivityScreenState extends State<ActivityScreen> {
  String _filter = 'all';
  late final Stream<List<Map<String, dynamic>>> _log =
      liveStream(() => supabase.from('activity_log').stream(primaryKey: ['id']).order('ts', ascending: false).limit(200));

  static const _filters = ['all', 'telegram', 'gmail', 'notification', 'sms', 'app', 'schedule'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Activity')),
      body: Column(
        children: [
          SizedBox(
            height: 52,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              children: [
                for (final f in _filters)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(f == 'all' ? 'All' : f[0].toUpperCase() + f.substring(1)),
                      selected: _filter == f,
                      onSelected: (_) => setState(() => _filter = f),
                      selectedColor: NeoColors.ink,
                      labelStyle: TextStyle(color: _filter == f ? NeoColors.onInk : NeoColors.ink, fontWeight: FontWeight.w600),
                      backgroundColor: NeoColors.card,
                      side: const BorderSide(color: NeoColors.line),
                      showCheckmark: false,
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: StreamBuilder<List<Map<String, dynamic>>>(
              stream: _log,
              builder: (context, snap) {
                if (snap.hasError) return Center(child: Text('Error: ${snap.error}'));
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                final rows = _filter == 'all' ? snap.data! : snap.data!.where((r) => r['source'] == _filter).toList();
                if (rows.isEmpty) return const Center(child: Text('Nothing here yet.', style: TextStyle(color: NeoColors.muted)));
                return ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  itemCount: rows.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, i) => _Tile(row: rows[i]),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile({required this.row});
  final Map<String, dynamic> row;

  IconData get _icon => switch (row['source']) {
        'telegram' => Icons.send_outlined,
        'gmail' => Icons.mail_outline,
        'notification' => Icons.notifications_none,
        'sms' => Icons.sms_outlined,
        'app' => Icons.phone_android,
        'schedule' => Icons.schedule,
        _ => Icons.bolt_outlined,
      };

  @override
  Widget build(BuildContext context) {
    final ts = DateTime.tryParse(row['ts']?.toString() ?? '')?.toLocal();
    final status = row['status']?.toString() ?? 'ok';
    final dot = switch (status) {
      'error' => NeoColors.danger,
      'pending' => const Color(0xFFB26A00),
      'skipped' => NeoColors.muted,
      _ => NeoColors.good,
    };
    return SoftCard(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      onTap: () => showModalBottomSheet(
        context: context,
        showDragHandle: true,
        isScrollControlled: true,
        backgroundColor: NeoColors.ground,
        builder: (_) => DraggableScrollableSheet(
          expand: false,
          initialChildSize: 0.6,
          builder: (context, c) => ListView(
            controller: c,
            padding: const EdgeInsets.all(20),
            children: [
              Text(row['action']?.toString() ?? '', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              Text('Status: $status', style: const TextStyle(color: NeoColors.muted)),
              const SizedBox(height: 16),
              const Text('Input', style: TextStyle(fontWeight: FontWeight.w700)),
              SelectableText(_pretty(row['input'])),
              const SizedBox(height: 16),
              const Text('Output', style: TextStyle(fontWeight: FontWeight.w700)),
              SelectableText(_pretty(row['output'])),
            ],
          ),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(color: NeoColors.ground, borderRadius: BorderRadius.circular(12)),
            child: Icon(_icon, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(row['action']?.toString() ?? '', style: const TextStyle(fontWeight: FontWeight.w600)),
                Text([if (row['tool'] != null) row['tool'], if (ts != null) DateFormat('d MMM, HH:mm').format(ts)].join(' · '),
                    style: const TextStyle(color: NeoColors.muted, fontSize: 12)),
              ],
            ),
          ),
          Icon(Icons.circle, size: 10, color: dot),
        ],
      ),
    );
  }

  static String _pretty(Object? v) {
    if (v == null) return '—';
    try {
      return const JsonEncoder.withIndent('  ').convert(v);
    } catch (_) {
      return v.toString();
    }
  }
}
