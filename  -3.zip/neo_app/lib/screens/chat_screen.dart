import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../neo/neo_brain.dart';
import '../neo/neo_face.dart';
import '../theme.dart';
import '../widgets/live.dart';
import '../widgets/talk_bar.dart';

/// Full conversation with Neo. History comes live from Supabase; the n8n backend
/// saves both your message and Neo's reply there.
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with AutomaticKeepAliveClientMixin {
  late final Stream<List<Map<String, dynamic>>> _messages =
      liveStream(() => supabase.from('messages').stream(primaryKey: ['id']).order('id', ascending: false).limit(150));

  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
          child: ListenableBuilder(
            listenable: neo,
            builder: (context, _) => SoftCard(
              padding: EdgeInsets.zero,
              radius: 24,
              child: SizedBox(
                height: 120,
                child: Row(
                  children: [
                    SizedBox(width: 150, child: NeoFace(mood: neo.mood, color: neo.color, voiceLevel: neo.voiceLevel, onTap: neo.poke)),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(right: 16),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Neo', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                            const SizedBox(height: 2),
                            Text(_status(neo.mood), style: const TextStyle(color: NeoColors.muted)),
                          ],
                        ),
                      ),
                    ),
                    ListenableBuilder(
                      listenable: neo,
                      builder: (context, _) => neo.mood == NeoMood.talking
                          ? IconButton(tooltip: 'Stop talking', onPressed: neo.stopSpeaking, icon: const Icon(Icons.volume_off_rounded))
                          : const SizedBox(width: 8),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        Expanded(
          child: StreamBuilder<List<Map<String, dynamic>>>(
            stream: _messages,
            builder: (context, snap) {
              if (snap.hasError) return Center(child: Text('Could not load chat: ${snap.error}'));
              final rows = snap.data;
              if (rows == null) return const Center(child: CircularProgressIndicator());
              return ValueListenableBuilder<String?>(
                valueListenable: neo.pendingListenable,
                builder: (context, pending, _) {
                  final items = <Widget>[
                    if (pending != null) ...[
                      const _Typing(),
                      _Bubble(text: pending, mine: true, time: null, channel: 'app'),
                    ],
                    for (final r in rows)
                      _Bubble(
                        text: r['text']?.toString() ?? '',
                        mine: r['role'] == 'user',
                        time: DateTime.tryParse(r['ts']?.toString() ?? '')?.toLocal(),
                        channel: r['channel']?.toString() ?? 'app',
                      ),
                  ];
                  if (items.isEmpty) {
                    return const Center(
                      child: Padding(
                        padding: EdgeInsets.all(32),
                        child: Text('Type below, or hold the mic and talk.\nNeo understands Uzbek, Russian and English.',
                            textAlign: TextAlign.center, style: TextStyle(color: NeoColors.muted)),
                      ),
                    );
                  }
                  return ListView(reverse: true, padding: const EdgeInsets.fromLTRB(16, 8, 16, 8), children: items);
                },
              );
            },
          ),
        ),
        const Padding(padding: EdgeInsets.fromLTRB(20, 4, 20, 8), child: TalkBar(hint: 'Message Neo')),
      ],
    );
  }

  static String _status(NeoMood m) => switch (m) {
        NeoMood.listening => 'Listening…',
        NeoMood.thinking => 'Thinking…',
        NeoMood.talking => 'Talking',
        NeoMood.happy => 'Happy to help',
        NeoMood.sleepy => 'Sleepy, but here',
        NeoMood.alert => 'Something needs your OK',
        NeoMood.idle => 'Ready',
      };
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.text, required this.mine, required this.time, required this.channel});
  final String text;
  final bool mine;
  final DateTime? time;
  final String channel;

  @override
  Widget build(BuildContext context) {
    final bg = mine ? NeoColors.ink : NeoColors.card;
    final fg = mine ? NeoColors.onInk : NeoColors.ink;
    final meta = [
      if (time != null) DateFormat('HH:mm').format(time!),
      if (channel == 'voice') 'voice',
      if (channel == 'telegram') 'Telegram',
    ].join(' · ');
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(20),
            topRight: const Radius.circular(20),
            bottomLeft: Radius.circular(mine ? 20 : 6),
            bottomRight: Radius.circular(mine ? 6 : 20),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (final part in _parts(text))
              part.code
                  ? _CodeBlock(code: part.text, lang: part.lang)
                  : SelectableText(part.text, style: TextStyle(color: fg, height: 1.35)),
            if (meta.isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(meta, style: TextStyle(color: fg.withValues(alpha: 0.6), fontSize: 11)),
            ],
          ],
        ),
      ),
    );
  }
}

class _Typing extends StatelessWidget {
  const _Typing();

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(color: NeoColors.card, borderRadius: BorderRadius.circular(20)),
        child: const Text('Neo is thinking…', style: TextStyle(color: NeoColors.muted)),
      ),
    );
  }
}

class _Part {
  const _Part(this.text, {this.code = false, this.lang = ''});
  final String text;
  final bool code;
  final String lang;
}

/// Splits a message into normal text and ```code``` blocks.
List<_Part> _parts(String text) {
  final out = <_Part>[];
  final re = RegExp(r'```([a-zA-Z0-9_+-]*)\n?([\s\S]*?)(```|$)');
  var last = 0;
  for (final m in re.allMatches(text)) {
    final before = text.substring(last, m.start).trim();
    if (before.isNotEmpty) out.add(_Part(before));
    final code = (m.group(2) ?? '').trimRight();
    if (code.isNotEmpty) out.add(_Part(code, code: true, lang: m.group(1) ?? ''));
    last = m.end;
  }
  final rest = text.substring(last).trim();
  if (rest.isNotEmpty || out.isEmpty) out.add(_Part(rest));
  return out;
}

class _CodeBlock extends StatelessWidget {
  const _CodeBlock({required this.code, required this.lang});
  final String code;
  final String lang;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(color: const Color(0xFF1F1D1A), borderRadius: BorderRadius.circular(12)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 12),
                child: Text(lang.isEmpty ? 'code' : lang, style: const TextStyle(color: Color(0xFFCFC8BC), fontSize: 11, fontWeight: FontWeight.w700)),
              ),
              const Spacer(),
              TextButton.icon(
                style: TextButton.styleFrom(foregroundColor: const Color(0xFFF3EFE8), visualDensity: VisualDensity.compact),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: code));
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Copied'), duration: Duration(seconds: 1)));
                },
                icon: const Icon(Icons.copy_rounded, size: 15),
                label: const Text('Copy', style: TextStyle(fontSize: 12)),
              ),
            ],
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: SelectableText(code, style: const TextStyle(fontFamily: 'monospace', fontSize: 12.5, color: Color(0xFFF3EFE8), height: 1.4)),
          ),
        ],
      ),
    );
  }
}
