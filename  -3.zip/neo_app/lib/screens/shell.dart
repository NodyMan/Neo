import 'package:flutter/material.dart';

import '../money/add_transaction_sheet.dart';
import '../neo/neo_brain.dart';
import '../neo/phone.dart';
import '../theme.dart';
import 'approvals_screen.dart';
import 'chat_screen.dart';
import 'home_screen.dart';
import 'money_screen.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _tab = 0;

  void go(int i) => setState(() => _tab = i);

  @override
  void initState() {
    super.initState();
    // Long-press the Neo icon on the home screen → "Talk to Neo" / "Add expense".
    Phone.onShortcut = _shortcut;
    Phone.launchShortcut().then((s) {
      if (s != null) _shortcut(s);
    });
  }

  @override
  void dispose() {
    Phone.onShortcut = null;
    super.dispose();
  }

  void _shortcut(String s) {
    if (!mounted) return;
    if (s == 'talk') {
      go(1);
    } else if (s == 'expense') {
      go(3);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) showAddTransaction(context);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: IndexedStack(
          index: _tab,
          children: [
            // Only the visible tab runs animations (Neo's face is 60 fps).
            TickerMode(enabled: _tab == 0, child: HomeScreen(onOpenTab: go)),
            TickerMode(enabled: _tab == 1, child: const ChatScreen()),
            const ApprovalsScreen(),
            const MoneyScreen(),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
          child: ListenableBuilder(
            listenable: neo,
            builder: (context, _) => Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(color: NeoColors.card, borderRadius: BorderRadius.circular(28)),
              child: Row(
                children: [
                  _NavItem(icon: Icons.home_outlined, label: 'Home', selected: _tab == 0, onTap: () => go(0)),
                  _NavItem(icon: Icons.chat_bubble_outline, label: 'Chat', selected: _tab == 1, onTap: () => go(1)),
                  _NavItem(icon: Icons.task_alt, label: 'Approvals', selected: _tab == 2, onTap: () => go(2), badge: neo.pendingApprovals),
                  _NavItem(icon: Icons.account_balance_wallet_outlined, label: 'Money', selected: _tab == 3, onTap: () => go(3)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({required this.icon, required this.label, required this.selected, required this.onTap, this.badge = 0});
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final int badge;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Semantics(
        selected: selected,
        button: true,
        label: label,
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(color: selected ? NeoColors.ground : Colors.transparent, borderRadius: BorderRadius.circular(22)),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Badge(isLabelVisible: badge > 0, label: Text('$badge'), child: Icon(icon, color: selected ? NeoColors.ink : NeoColors.muted)),
                const SizedBox(height: 2),
                Text(label,
                    style: TextStyle(fontSize: 11, fontWeight: selected ? FontWeight.w700 : FontWeight.w500, color: selected ? NeoColors.ink : NeoColors.muted)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
