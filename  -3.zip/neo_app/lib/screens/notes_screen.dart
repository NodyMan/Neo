import 'package:flutter/material.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../neo/neo_brain.dart';
import '../theme.dart';
import '../widgets/live.dart';

/// Max's knowledge base: everything he asked Neo to remember. Neo searches it too.
class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  final _search = TextEditingController();
  late final Stream<List<Map<String, dynamic>>> _notes =
      liveStream(() => supabase.from('notes').stream(primaryKey: ['id']).order('id', ascending: false).limit(300));
  String _q = '';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  bool _matches(Map<String, dynamic> n) {
    if (_q.isEmpty) return true;
    final hay = '${n['title'] ?? ''} ${n['content'] ?? ''} ${(n['tags'] as List?)?.join(' ') ?? ''}'.toLowerCase();
    return _q.toLowerCase().split(RegExp(r'\s+')).every(hay.contains);
  }

  Future<void> _edit({Map<String, dynamic>? note}) async {
    final title = TextEditingController(text: note?['title']?.toString() ?? '');
    final content = TextEditingController(text: note?['content']?.toString() ?? '');
    final tags = TextEditingController(text: (note?['tags'] as List?)?.join(', ') ?? '');
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: NeoColors.ground,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (c) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, 20 + MediaQuery.of(c).viewInsets.bottom),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(note == null ? 'New note' : 'Edit note', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
            const SizedBox(height: 14),
            TextField(controller: title, decoration: const InputDecoration(hintText: 'Title (optional)')),
            const SizedBox(height: 10),
            TextField(controller: content, minLines: 3, maxLines: 8, autofocus: note == null, decoration: const InputDecoration(hintText: 'What should Neo remember?')),
            const SizedBox(height: 10),
            TextField(controller: tags, decoration: const InputDecoration(hintText: 'Tags, comma separated')),
            const SizedBox(height: 16),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: NeoColors.ink, minimumSize: const Size.fromHeight(52)),
              onPressed: () => Navigator.pop(c, true),
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
    if (ok != true || content.text.trim().isEmpty) return;
    try {
      if (note != null) await supabase.rpc('neo_delete_note', params: {'p_id': note['id']});
      await supabase.rpc('neo_save_note', params: {'p_content': content.text.trim(), 'p_title': title.text.trim(), 'p_tags': tags.text.trim()});
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Not saved: $e')));
    }
  }

  Future<void> _delete(Map<String, dynamic> n) async {
    try {
      await supabase.rpc('neo_delete_note', params: {'p_id': n['id']});
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Not deleted: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Notes')),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: NeoColors.ink,
        foregroundColor: NeoColors.onInk,
        onPressed: () => _edit(),
        icon: const Icon(Icons.add),
        label: const Text('Note'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: TextField(
              controller: _search,
              onChanged: (v) => setState(() => _q = v.trim()),
              decoration: const InputDecoration(hintText: 'Search notes', prefixIcon: Icon(Icons.search_rounded)),
            ),
          ),
          Expanded(
            child: StreamBuilder<List<Map<String, dynamic>>>(
              stream: _notes,
              builder: (context, snap) {
                if (snap.hasError) return Center(child: Text('Could not load notes: ${snap.error}'));
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                final rows = snap.data!.where(_matches).toList();
                if (rows.isEmpty) {
                  return const Center(
                    child: Padding(
                      padding: EdgeInsets.all(32),
                      child: Text('Nothing here yet.\nTell Neo "remember that…" or tap + Note.',
                          textAlign: TextAlign.center, style: TextStyle(color: NeoColors.muted)),
                    ),
                  );
                }
                return ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
                  itemCount: rows.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 10),
                  itemBuilder: (context, i) {
                    final n = rows[i];
                    final tags = (n['tags'] as List?)?.map((e) => e.toString()).where((e) => e.isNotEmpty).toList() ?? const [];
                    final ts = DateTime.tryParse(n['ts']?.toString() ?? '')?.toLocal();
                    return Dismissible(
                      key: ValueKey(n['id']),
                      direction: DismissDirection.endToStart,
                      background: Container(
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 24),
                        decoration: BoxDecoration(color: NeoColors.danger, borderRadius: BorderRadius.circular(22)),
                        child: const Icon(Icons.delete_outline, color: Colors.white),
                      ),
                      onDismissed: (_) => _delete(n),
                      child: SoftCard(
                        onTap: () => _edit(note: n),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            if ((n['title'] ?? '').toString().isNotEmpty)
                              Text(n['title'].toString(), style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                            Text(n['content']?.toString() ?? '', maxLines: 6, overflow: TextOverflow.ellipsis, style: const TextStyle(height: 1.35)),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 6,
                              runSpacing: 6,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              children: [
                                for (final t in tags)
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                                    decoration: BoxDecoration(color: NeoColors.ground, borderRadius: BorderRadius.circular(20)),
                                    child: Text('#$t', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                                  ),
                                if (ts != null) Text(DateFormat('d MMM · HH:mm').format(ts), style: const TextStyle(color: NeoColors.muted, fontSize: 12)),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
