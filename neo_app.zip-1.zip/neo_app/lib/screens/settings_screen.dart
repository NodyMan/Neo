import 'package:flutter/material.dart';

import '../neo/neo_brain.dart';
import '../neo/phone.dart';
import '../config.dart';
import '../theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _set(BuildContext context, String key, Object value) async {
    try {
      await neo.saveSetting(key, value);
    } catch (e) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Not saved: $e')));
    }
  }

  Future<void> _kill(BuildContext context, bool on) async {
    if (!on) return _set(context, 'kill_switch', false);
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Stop Neo?'),
        content: const Text('Neo will stop taking any actions until you turn this off. It can still read and chat.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Stop Neo')),
        ],
      ),
    );
    if (ok == true && context.mounted) await _set(context, 'kill_switch', true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListenableBuilder(
        listenable: neo,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
          children: [
            SoftCard(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(
                children: [
                  SwitchListTile(
                    secondary: Icon(Icons.pan_tool_outlined, color: neo.killSwitch ? NeoColors.danger : null),
                    title: const Text('Kill switch'),
                    subtitle: Text(neo.killSwitch ? 'Neo is stopped — no actions will run' : 'Neo is running'),
                    value: neo.killSwitch,
                    onChanged: (v) => _kill(context, v),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            SoftCard(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: FutureBuilder<bool>(
                future: Phone.notificationAccess(),
                builder: (context, snap) {
                  final on = snap.data == true;
                  return ListTile(
                    leading: Icon(Icons.notifications_active_outlined, color: on ? NeoColors.good : null),
                    title: const Text('Read my notifications'),
                    subtitle: Text(on
                        ? 'On — ask "What did I miss?"'
                        : 'Off — tap, find Neo and allow access. If Android blocks it: App info → ⋮ → Allow restricted settings.'),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () async {
                      await Phone.run({'action': 'notification_access'});
                    },
                  );
                },
              ),
            ),
            const SizedBox(height: 12),
            SoftCard(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(
                children: [
                  SwitchListTile(
                    secondary: const Icon(Icons.record_voice_over_outlined),
                    title: const Text('Speak replies aloud'),
                    subtitle: const Text('Voice messages are always answered out loud'),
                    value: neo.voiceReplies,
                    onChanged: (v) => _set(context, 'voice_replies', v),
                  ),
                  ListTile(
                    leading: const Icon(Icons.graphic_eq_rounded),
                    title: const Text('Neo\'s voice'),
                    subtitle: Text('${neo.geminiVoice} · Google Gemini voice'),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const VoicePickerScreen())),
                  ),
                  SwitchListTile(
                    secondary: const Icon(Icons.hearing_rounded),
                    title: const Text('"Hey Neo" hands-free'),
                    subtitle: const Text('Neo listens while the app is open and the screen stays on'),
                    value: neo.handsFree,
                    onChanged: (v) => neo.setHandsFree(v),
                  ),
                  ListTile(
                    leading: const Icon(Icons.record_voice_over_rounded),
                    title: const Text('Hands-free language'),
                    subtitle: const Text('The language you speak after "Hey Neo"'),
                    trailing: DropdownButton<String>(
                      value: const ['en-US', 'ru-RU', 'uz-UZ'].contains(neo.wakeLang) ? neo.wakeLang : 'en-US',
                      underline: const SizedBox.shrink(),
                      items: const [
                        DropdownMenuItem(value: 'en-US', child: Text('English')),
                        DropdownMenuItem(value: 'ru-RU', child: Text('Русский')),
                        DropdownMenuItem(value: 'uz-UZ', child: Text('Oʻzbekcha')),
                      ],
                      onChanged: (v) {
                        if (v == null) return;
                        neo.wakeLang = v;
                        _set(context, 'wake_lang', v);
                      },
                    ),
                  ),
                  ListTile(
                    leading: const Icon(Icons.translate),
                    title: const Text('Backup voice language'),
                    subtitle: const Text('Only used if the Gemini voice is unavailable'),
                    trailing: DropdownButton<String>(
                      value: const ['same_as_user', 'uz', 'ru', 'en'].contains(neo.replyLanguage) ? neo.replyLanguage : 'same_as_user',
                      underline: const SizedBox.shrink(),
                      items: const [
                        DropdownMenuItem(value: 'same_as_user', child: Text('Auto')),
                        DropdownMenuItem(value: 'uz', child: Text('Oʻzbekcha')),
                        DropdownMenuItem(value: 'ru', child: Text('Русский')),
                        DropdownMenuItem(value: 'en', child: Text('English')),
                      ],
                      onChanged: (v) => v == null ? null : _set(context, 'reply_language', v),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            SoftCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Neo\'s colour', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      for (var i = 0; i < NeoColors.accents.length; i++)
                        Padding(
                          padding: const EdgeInsets.only(right: 12),
                          child: Semantics(
                            button: true,
                            selected: neo.color == NeoColors.accents[i],
                            label: ['Coral', 'Sage', 'Butter', 'Periwinkle'][i],
                            child: GestureDetector(
                              onTap: () => _set(context, 'neo_color', i),
                              child: Container(
                                width: 48,
                                height: 48,
                                decoration: BoxDecoration(
                                  color: NeoColors.accents[i],
                                  shape: BoxShape.circle,
                                  border: Border.all(color: neo.color == NeoColors.accents[i] ? NeoColors.ink : Colors.transparent, width: 3),
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            SoftCard(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: ListTile(
                leading: const Icon(Icons.logout),
                title: const Text('Sign out'),
                subtitle: Text(supabase.auth.currentUser?.email ?? ''),
                onTap: () async {
                  await supabase.auth.signOut();
                  if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
                },
              ),
            ),
            const SizedBox(height: 16),
            const Center(child: Text('Neo app $neoAppVersion', style: TextStyle(color: NeoColors.muted, fontSize: 12))),
          ],
        ),
      ),
    );
  }
}

/// Pick Neo's voice from Google Gemini's male voices. Tap to hear it.
class VoicePickerScreen extends StatefulWidget {
  const VoicePickerScreen({super.key});

  @override
  State<VoicePickerScreen> createState() => _VoicePickerScreenState();
}

class _VoicePickerScreenState extends State<VoicePickerScreen> {
  String? _loading;

  Future<void> _pick(String v) async {
    setState(() => _loading = v);
    await neo.chooseVoice(v);
    final ok = await neo.previewVoice(v);
    if (!mounted) return;
    setState(() => _loading = null);
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Saved. Could not play a sample right now — try again in a minute.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Neo\'s voice')),
      body: ListenableBuilder(
        listenable: neo,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(4, 0, 4, 12),
              child: Text(
                'Male voices by Google Gemini. They speak Uzbek, Russian and English. Tap one to hear it — it becomes Neo\'s voice.',
                style: TextStyle(color: NeoColors.muted),
              ),
            ),
            SoftCard(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(
                children: [
                  for (final (name, vibe) in NeoBrain.geminiVoices)
                    ListTile(
                      leading: Icon(
                        neo.geminiVoice == name ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                        color: neo.geminiVoice == name ? NeoColors.ink : NeoColors.muted,
                      ),
                      title: Text(name, style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text(vibe, style: const TextStyle(color: NeoColors.muted)),
                      trailing: _loading == name
                          ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5))
                          : const Icon(Icons.play_arrow_rounded),
                      onTap: _loading == null ? () => _pick(name) : null,
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
