#!/usr/bin/env bash
# Generates the windows/ folder and applies Neo's Windows settings (name, icon).
# Run from the neo_app folder in Git Bash. Safe to run more than once.
set -e

flutter create --platforms=windows --org uz.max --project-name neo_app .

cp tool/windows/app_icon.ico windows/runner/resources/app_icon.ico
sed -i 's/L"neo_app"/L"Neo"/' windows/runner/main.cpp
sed -i 's/"FileDescription", "neo_app"/"FileDescription", "Neo"/; s/"ProductName", "neo_app"/"ProductName", "Neo"/' windows/runner/Runner.rc
sed -i 's/set(BINARY_NAME "neo_app")/set(BINARY_NAME "Neo")/' windows/CMakeLists.txt

echo "Windows project ready."
