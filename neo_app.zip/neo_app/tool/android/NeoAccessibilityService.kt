package uz.max.neo_app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

// "Control the screen": lets Neo tap buttons, type, press Back/Home, scroll and read what's on screen.
// Only works after Max turns it on in Android Settings → Accessibility → Neo.
class NeoAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: NeoAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    // ---------- helpers ----------

    private fun roots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) {
                val r = w.root
                if (r != null) out.add(r)
            }
        } catch (e: Exception) {
        }
        if (out.isEmpty()) rootInActiveWindow?.let { out.add(it) }
        return out
    }

    private fun walk(node: AccessibilityNodeInfo?, depth: Int, visit: (AccessibilityNodeInfo) -> Boolean): Boolean {
        if (node == null || depth > 40) return false
        if (visit(node)) return true
        for (i in 0 until node.childCount) {
            if (walk(node.getChild(i), depth + 1, visit)) return true
        }
        return false
    }

    private fun label(n: AccessibilityNodeInfo): String {
        val t = n.text?.toString() ?: ""
        val d = n.contentDescription?.toString() ?: ""
        return (t + " " + d).trim().lowercase()
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        var hops = 0
        while (cur != null && hops < 6) {
            if (cur.isClickable && cur.isEnabled) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
            hops++
        }
        // Not clickable anywhere up the tree: tap its centre.
        val r = Rect()
        n.getBoundsInScreen(r)
        return tapAt(r.exactCenterX(), r.exactCenterY())
    }

    private fun tapAt(x: Float, y: Float): Boolean {
        if (x <= 0 || y <= 0) return false
        val p = Path()
        p.moveTo(x, y)
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        return dispatchGesture(g, null, null)
    }

    // ---------- what Neo can do ----------

    /** Tap the first visible element whose text or description matches one of [targets]. */
    fun clickText(targets: List<String>, exactFirst: Boolean = true): Boolean {
        val wanted = targets.map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        if (wanted.isEmpty()) return false
        for (root in roots()) {
            if (exactFirst) {
                var hit: AccessibilityNodeInfo? = null
                walk(root, 0) { n ->
                    val l = label(n)
                    if (n.isVisibleToUser && wanted.any { l == it || n.text?.toString()?.lowercase() == it || n.contentDescription?.toString()?.lowercase() == it }) {
                        hit = n; true
                    } else false
                }
                hit?.let { if (clickNode(it)) return true }
            }
            var hit2: AccessibilityNodeInfo? = null
            walk(root, 0) { n ->
                val l = label(n)
                if (n.isVisibleToUser && l.isNotEmpty() && wanted.any { l.contains(it) }) {
                    hit2 = n; true
                } else false
            }
            hit2?.let { if (clickNode(it)) return true }
        }
        return false
    }

    /** Tap a view by its resource id, e.g. com.whatsapp:id/send. */
    fun clickId(id: String): Boolean {
        for (root in roots()) {
            val list = try { root.findAccessibilityNodeInfosByViewId(id) } catch (e: Exception) { null }
            val n = list?.firstOrNull { it.isVisibleToUser } ?: continue
            if (clickNode(n)) return true
        }
        return false
    }

    /** Type into the focused text field (or the first one on screen). */
    fun typeText(text: String, append: Boolean = false): Boolean {
        var target: AccessibilityNodeInfo? = null
        for (root in roots()) {
            val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (focused != null && focused.isEditable) {
                target = focused
                break
            }
            walk(root, 0) { n -> if (n.isEditable && n.isVisibleToUser) { target = n; true } else false }
            if (target != null) break
        }
        val f = target ?: return false
        f.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val current = if (append) (f.text?.toString() ?: "") else ""
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, current + text)
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun press(what: String): Boolean {
        val w = what.lowercase()
        val action = when {
            w.contains("back") || w.contains("назад") -> GLOBAL_ACTION_BACK
            w.contains("home") || w.contains("домой") -> GLOBAL_ACTION_HOME
            w.contains("recent") || w.contains("недав") -> GLOBAL_ACTION_RECENTS
            w.contains("quick") -> GLOBAL_ACTION_QUICK_SETTINGS
            w.contains("notif") || w.contains("уведом") -> GLOBAL_ACTION_NOTIFICATIONS
            w.contains("lock") || w.contains("блок") -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_LOCK_SCREEN else return false
            w.contains("screenshot") || w.contains("скрин") -> if (Build.VERSION.SDK_INT >= 28) GLOBAL_ACTION_TAKE_SCREENSHOT else return false
            w.contains("power") -> GLOBAL_ACTION_POWER_DIALOG
            else -> return false
        }
        return performGlobalAction(action)
    }

    fun scroll(down: Boolean): Boolean {
        var done = false
        for (root in roots()) {
            walk(root, 0) { n ->
                if (n.isScrollable && n.isVisibleToUser) {
                    done = n.performAction(if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
                    done
                } else false
            }
            if (done) return true
        }
        // Fallback: swipe.
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val p = Path()
        if (down) { p.moveTo(x, dm.heightPixels * 0.75f); p.lineTo(x, dm.heightPixels * 0.25f) } else { p.moveTo(x, dm.heightPixels * 0.25f); p.lineTo(x, dm.heightPixels * 0.75f) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 300)).build()
        return dispatchGesture(g, null, null)
    }

    /** All visible text on screen (for "what's on my screen?"). */
    fun readScreen(max: Int = 3000): String {
        val sb = StringBuilder()
        val seen = HashSet<String>()
        for (root in roots()) {
            walk(root, 0) { n ->
                if (n.isVisibleToUser) {
                    val t = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()
                    if (t.isNotEmpty() && t.length < 400 && seen.add(t)) sb.append(t).append('\n')
                }
                sb.length > max
            }
        }
        val pkg = rootInActiveWindow?.packageName?.toString() ?: ""
        return (if (pkg.isNotEmpty()) "[app: $pkg]\n" else "") + sb.toString().take(max)
    }
}
