Put hey_neo.ppn (and optional ey_neo.ppn) from Picovoice Console here (platform: Android).
