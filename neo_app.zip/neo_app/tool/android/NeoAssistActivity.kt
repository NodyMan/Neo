package uz.max.neo_app

import io.flutter.embedding.android.FlutterActivityLaunchConfigs.BackgroundMode

// The compact Neo popup (like the Google Assistant sheet): a see-through window over any app
// that runs Flutter's assistMain() — Neo's face and a live voice call at the bottom of the screen.
// It shares MainActivity's phone channel, so Neo's phone actions work from here too.
class NeoAssistActivity : MainActivity() {
    override fun getDartEntrypointFunctionName(): String = "assistMain"
    override fun getBackgroundMode(): BackgroundMode = BackgroundMode.transparent
    override fun shouldHandleDeeplinking(): Boolean = false
}
