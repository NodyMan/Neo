import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../config.dart';
import '../pc/pc_agent.dart';
import '../widgets/live.dart';
import 'phone.dart';

/// The tools Neo can use in a live voice session (Gemini function calling),
/// and the code that runs them on this device. Basic things run at once;
/// anything that can lose data or turn the computer off asks Max first.
class AgentTools {
  AgentTools._();

  /// Set by the UI: shows a confirm sheet and resolves to Max's answer.
  static Future<bool> Function(String title, String detail)? confirm;

  /// Set by the live session: lets a tool show Neo a picture (the screen).
  static void Function(Uint8List jpeg)? sendImage;

  static bool get onPc => PcAgent.available;

  // ---- declarations (OpenAPI subset, as the Gemini API wants them) ----

  static Map<String, dynamic> _fn(String name, String description, [Map<String, dynamic> props = const {}, List<String> required = const []]) => {
        'name': name,
        'description': description,
        if (props.isNotEmpty)
          'parameters': {
            'type': 'OBJECT',
            'properties': props,
            if (required.isNotEmpty) 'required': required,
          },
      };

  static Map<String, dynamic> _s(String d, [List<String>? options]) => {'type': 'STRING', 'description': d, if (options != null) 'enum': options};
  static Map<String, dynamic> _n(String d) => {'type': 'NUMBER', 'description': d};

  /// [chat]: the desktop text chat, which gets web_search as a tool (the live call has Google Search built in).
  static List<Map<String, dynamic>> declarations({bool chat = false}) {
    final common = [
      _fn('ask_neo_memory',
          "Ask Neo's personal back office about Max's own data: money and spending (analytics, budgets, transactions), tasks and reminders, "
              'notes and things he asked to remember, approvals, mood history, calendar. Also use it to SAVE things: '
              '"remember that…", "remind me tomorrow at 9 to…", "add a task…". Pass Max\'s request in his own words.',
          {'request': _s('What to look up or save, as a full sentence')},
          ['request']),
      _fn('set_timer', 'Start a countdown timer. Neo announces it when time is up.',
          {'seconds': _n('Length in seconds'), 'label': _s('What the timer is for, optional')}, ['seconds']),
      _fn('open_website', 'Open a website or link in the browser.', {'url': _s('Full URL or domain')}, ['url']),
      _fn('device_action',
          'Do something on this device with the app vocabulary: open_app (target = app name), web_search, youtube, '
              'play_music (target = song/artist), media (target = next|previous|pause|play|louder|quieter|mute), '
              'navigate/map_search (target = place), copy_text, send_message (target = contact, extra = text, package = app), '
              'call/sms (phone only, target = number), alarm (phone only, target = HH:MM), settings.',
          {
            'action': _s('Action name'),
            'target': _s('Main argument'),
            'extra': _s('Second argument, e.g. message text'),
            'package': _s('App, e.g. telegram, whatsapp, spotify'),
          },
          ['action']),
      if (chat)
        _fn('web_search', 'Search the web for fresh facts: news, prices, exchange rates, weather, docs, finding websites. Returns a short answer with sources.',
            {'query': _s('What to search for')}, ['query']),
    ];
    if (!onPc) return common;
    return [
      ...common,
      _fn('list_folder', 'List what is in a folder on the laptop. Shortcuts: desktop, documents, downloads, pictures, music, videos, home.',
          {'path': _s('Folder path or shortcut')}, ['path']),
      _fn('search_files', 'Find files or folders by part of their name on the laptop.',
          {'query': _s('Part of the name, e.g. "invoice" or ".pdf"'), 'folder': _s('Where to start, default home')}, ['query']),
      _fn('read_file', 'Read a text-like file (txt, md, csv, json, code, docx) so you can summarise or analyse it.',
          {'path': _s('File path')}, ['path']),
      _fn('write_file', 'Create or overwrite a text file, or append to it. Overwriting an existing file asks Max first.',
          {'path': _s('File path'), 'content': _s('Text to write'), 'append': {'type': 'BOOLEAN', 'description': 'Append instead of replacing'}},
          ['path', 'content']),
      _fn('create_folder', 'Create a folder.', {'path': _s('Folder path')}, ['path']),
      _fn('copy_path', 'Copy a file or folder.', {'from': _s('Source'), 'to': _s('Destination folder or path')}, ['from', 'to']),
      _fn('move_path', 'Move or rename a file or folder (asks Max first).', {'from': _s('Source'), 'to': _s('New path')}, ['from', 'to']),
      _fn('delete_path', 'Delete a file or folder to the Recycle Bin (asks Max first).', {'path': _s('Path')}, ['path']),
      _fn('open_path', 'Open a file, folder or app on the laptop, like double-clicking it.', {'path': _s('Path')}, ['path']),
      _fn('open_app', 'Open an app on the laptop by name (Telegram, Chrome, Word, Spotify, Settings…).', {'name': _s('App name')}, ['name']),
      _fn('close_app', 'Close a running app (asks Max first).', {'name': _s('App or window name')}, ['name']),
      _fn('running_apps', 'List the apps with open windows.'),
      _fn('power', 'Shut down, restart, sleep, lock or sign out of the laptop, or cancel a pending shutdown. Everything except lock and cancel asks Max first.',
          {
            'action': _s('What to do', ['shutdown', 'restart', 'sleep', 'lock', 'sign_out', 'cancel']),
            'delay_seconds': _n('Delay before shutdown/restart, default 30'),
          },
          ['action']),
      _fn('media_key', 'Press a media key: volume, mute, play/pause, next, previous.',
          {'key': _s('Key', ['volume_up', 'volume_down', 'mute', 'play_pause', 'next', 'previous', 'stop']), 'times': _n('How many presses, default 1')},
          ['key']),
      _fn('type_text', 'Type text into whatever is focused on the laptop.', {'text': _s('Text')}, ['text']),
      _fn('press_keys', 'Press keys with Windows SendKeys syntax: ^ = Ctrl, % = Alt, + = Shift, {ENTER}, {TAB}, {ESC}, e.g. "^s" to save.',
          {'keys': _s('SendKeys string')}, ['keys']),
      _fn('look_at_screen', 'Take a picture of the laptop screen and look at it, to see what Max sees.'),
      _fn('screenshot', 'Save a screenshot to Pictures\\Neo.'),
      _fn('system_info', 'Laptop status: battery, CPU, RAM, disk space, Wi-Fi, uptime, apps using the most memory.'),
      _fn('clipboard', 'Read what is on the clipboard.'),
    ];
  }

  // ---- running a call ----

  static Future<Map<String, dynamic>> run(String name, Map<String, dynamic> args) async {
    String s(String k) => (args[k] ?? '').toString();
    try {
      switch (name) {
        case 'ask_neo_memory':
          return await _askBackOffice(s('request'));
        case 'web_search':
          return await _webSearch(s('query'));
        case 'set_timer':
          final secs = (args['seconds'] as num?)?.round() ?? 60;
          NeoTimers.start(Duration(seconds: secs), s('label'));
          if (!onPc) unawaited(Phone.run({'action': 'timer', 'target': '$secs', 'extra': s('label')}));
          return {'ok': true, 'ends_at': DateTime.now().add(Duration(seconds: secs)).toIso8601String().substring(11, 16)};
        case 'open_website':
          final u = s('url');
          if (onPc) return await PcAgent.openPath(u.startsWith('http') ? u : 'https://$u');
          return {'result': await Phone.run({'action': 'open_url', 'target': u})};
        case 'device_action':
          final r = onPc ? await PcAgent.runAction(args) : await Phone.run(args, autoSend: false);
          return {'result': r};
        // ---- laptop ----
        case 'list_folder':
          return await PcAgent.listFolder(s('path'));
        case 'search_files':
          return await PcAgent.searchFiles(s('query'), folder: s('folder').isEmpty ? 'home' : s('folder'));
        case 'read_file':
          return await PcAgent.readFile(s('path'));
        case 'write_file':
          final append = args['append'] == true;
          if (!append && await PcAgent.exists(s('path'))) {
            if (!await _ask('Overwrite this file?', await PcAgent.resolve(s('path')))) return _declined;
          }
          return await PcAgent.writeFile(s('path'), s('content'), append: append);
        case 'create_folder':
          return await PcAgent.createFolder(s('path'));
        case 'copy_path':
          return await PcAgent.copyPath(s('from'), s('to'));
        case 'move_path':
          if (!await _ask('Move this?', '${await PcAgent.resolve(s('from'))}\n→ ${await PcAgent.resolve(s('to'))}')) return _declined;
          return await PcAgent.movePath(s('from'), s('to'));
        case 'delete_path':
          if (!await _ask('Delete this?', '${await PcAgent.resolve(s('path'))}\n(It goes to the Recycle Bin.)')) return _declined;
          return await PcAgent.deletePath(s('path'));
        case 'open_path':
          return await PcAgent.openPath(s('path'));
        case 'open_app':
          return await PcAgent.openApp(s('name'));
        case 'close_app':
          if (!await _ask('Close ${s('name')}?', 'Unsaved work in it may be lost.')) return _declined;
          return await PcAgent.closeApp(s('name'));
        case 'running_apps':
          return await PcAgent.runningApps();
        case 'power':
          final a = s('action');
          final delay = (args['delay_seconds'] as num?)?.round() ?? 30;
          const label = {'shutdown': 'Shut down the laptop?', 'restart': 'Restart the laptop?', 'sleep': 'Put the laptop to sleep?', 'sign_out': 'Sign out of Windows?'};
          if (label.containsKey(a) && !await _ask(label[a]!, a == 'shutdown' || a == 'restart' ? 'In $delay seconds. Save your work first.' : '')) {
            return _declined;
          }
          return await PcAgent.power(a, delaySeconds: delay);
        case 'media_key':
          return await PcAgent.media(s('key'), times: (args['times'] as num?)?.round() ?? 1);
        case 'type_text':
          return await PcAgent.typeText(s('text'));
        case 'press_keys':
          return await PcAgent.sendKeys(s('keys'));
        case 'look_at_screen':
          final jpg = await PcAgent.captureScreen(width: 1280, quality: 70);
          if (jpg == null) return {'error': 'could not capture the screen'};
          sendImage?.call(jpg);
          return {'ok': true, 'note': 'the screen image was just sent to you as video input; describe what you see'};
        case 'screenshot':
          return await PcAgent.screenshot();
        case 'system_info':
          return await PcAgent.systemInfo();
        case 'clipboard':
          return {'text': await PcAgent.clipboard()};
      }
      return {'error': 'unknown tool $name'};
    } on TimeoutException {
      return {'error': 'that took too long'};
    } catch (e) {
      return {'error': '$e'};
    }
  }

  static const _declined = {'declined': true, 'note': 'Max said no on screen. Do not retry; ask what he wants instead.'};

  static Future<bool> _ask(String title, String detail) async {
    final c = confirm;
    if (c == null) return false;
    return c(title, detail);
  }

  static Future<Map<String, dynamic>> _webSearch(String query) async {
    final token = await freshToken();
    if (token == null) return {'error': 'signed out'};
    final res = await http
        .post(Uri.parse('$supabaseUrl/functions/v1/neo-chat'),
            headers: {'Authorization': 'Bearer $token', 'apikey': supabasePublishableKey, 'Content-Type': 'application/json'},
            body: jsonEncode({'mode': 'search', 'query': query}))
        .timeout(const Duration(seconds: 60));
    final d = jsonDecode(utf8.decode(res.bodyBytes));
    if (res.statusCode != 200 || d is! Map) return {'error': (d is Map ? d['error'] : null) ?? 'search failed'};
    return Map<String, dynamic>.from(d);
  }

  /// The n8n back office knows Max's money, tasks, notes and memory, and can save new ones.
  static Future<Map<String, dynamic>> _askBackOffice(String request) async {
    final token = await freshToken();
    if (token == null) return {'error': 'signed out'};
    final res = await http
        .post(Uri.parse(neoWebhookUrl),
            headers: {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'},
            body: jsonEncode({'text': request, 'speak': false, 'device': onPc ? 'pc' : 'phone', 'source': 'live'}))
        .timeout(const Duration(seconds: 60));
    if (res.statusCode != 200) return {'error': 'back office answered ${res.statusCode}'};
    final d = jsonDecode(utf8.decode(res.bodyBytes));
    return {'answer': (d is Map ? d['reply'] : null)?.toString() ?? ''};
  }
}

/// In-app timers, so a timer works the same on the laptop and the phone.
class NeoTimers {
  NeoTimers._();
  static final active = ValueNotifier<List<NeoTimer>>([]);

  /// Called when a timer ends (the live session or the UI announces it).
  static void Function(NeoTimer t)? onDone;

  static void start(Duration d, String label) {
    late final NeoTimer t;
    t = NeoTimer(label, DateTime.now().add(d), Timer(d, () {
      active.value = [...active.value]..remove(t);
      onDone?.call(t);
    }));
    active.value = [...active.value, t];
  }

  static void cancel(NeoTimer t) {
    t.timer.cancel();
    active.value = [...active.value]..remove(t);
  }
}

class NeoTimer {
  NeoTimer(this.label, this.endsAt, this.timer);
  final String label;
  final DateTime endsAt;
  final Timer timer;
}

/// Short description of where Neo is running, for his instructions.
String deviceDescription() {
  if (Platform.isWindows) return "Max's Windows laptop (${Platform.environment['COMPUTERNAME'] ?? 'PC'})";
  if (Platform.isAndroid) return "Max's Android phone";
  return Platform.operatingSystem;
}
