import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter_soloud/flutter_soloud.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:record/record.dart';

import '../config.dart';
import '../widgets/live.dart';
import 'agent_tools.dart';
import 'neo_brain.dart';

enum CallState { off, connecting, listening, thinking, speaking, error }

class CallLine {
  CallLine(this.who, this.text);
  final String who; // me | neo | tool
  String text;
}

/// A real-time voice conversation with Neo (Gemini Live): you talk, he answers out loud,
/// you can interrupt him, and he uses tools on this device while you talk.
class NeoCall extends ChangeNotifier {
  NeoCall._();
  static final NeoCall instance = NeoCall._();

  CallState state = CallState.off;
  String? error;
  bool muted = false;
  double level = 0; // 0..1: your voice while listening, Neo's while speaking
  final lines = <CallLine>[];
  Duration get elapsed => _started == null ? Duration.zero : DateTime.now().difference(_started!);

  bool get active => state != CallState.off && state != CallState.error;

  WebSocket? _ws;
  String? _token;
  String _model = liveModel;
  String? _resumeHandle;
  DateTime? _started;
  bool _ending = false;

  final _rec = AudioRecorder();
  StreamSubscription<Uint8List>? _mic;

  AudioSource? _out;
  SoundHandle? _outHandle;
  int _outBytes = 0;
  DateTime? _outStart;
  Timer? _doneSpeaking;
  Timer? _levelTimer;

  // ---- start / stop ----

  Future<void> start() async {
    if (active) return;
    _ending = false;
    error = null;
    lines.clear();
    _resumeHandle = null;
    _set(CallState.connecting);
    neo.stopSpeaking();
    try {
      if (!await _rec.hasPermission()) throw 'Neo needs the microphone for a call.';
      if (!SoLoud.instance.isInitialized) {
        await SoLoud.instance.init(sampleRate: 24000, channels: Channels.mono, bufferSize: 1024);
      }
      await _fetchToken();
      await _connect();
      _started = DateTime.now();
      _levelTimer = Timer.periodic(const Duration(milliseconds: 80), (_) => _tickLevel());
      AgentTools.sendImage = _sendImage;
      NeoTimers.onDone = (t) => sendText('[The timer "${t.label.isEmpty ? 'timer' : t.label}" just ended. Tell Max briefly.]');
    } catch (e) {
      await _teardown();
      error = e is String ? e : _friendly(e);
      _set(CallState.error);
    }
  }

  Future<void> stop() async {
    _ending = true;
    await _teardown();
    _set(CallState.off);
  }

  void toggleMute() {
    muted = !muted;
    notifyListeners();
  }

  /// Type into the call (or send Neo a note from the app).
  void sendText(String text) {
    if (_ws == null) return;
    _send({
      'realtimeInput': {'text': text}
    });
  }

  // ---- connection ----

  Future<void> _fetchToken() async {
    final jwt = await freshToken();
    if (jwt == null) throw 'Sign in first.';
    final r = await http
        .post(Uri.parse('$supabaseUrl/functions/v1/neo-live-token'),
            headers: {'Authorization': 'Bearer $jwt', 'apikey': supabasePublishableKey, 'Content-Type': 'application/json'}, body: '{}')
        .timeout(const Duration(seconds: 20));
    final d = jsonDecode(utf8.decode(r.bodyBytes));
    if (r.statusCode != 200 || d is! Map || d['token'] == null) {
      final msg = d is Map ? (d['error'] ?? 'error ${r.statusCode}') : 'error ${r.statusCode}';
      throw 'Live voice is not ready on the server: $msg';
    }
    _token = d['token'] as String;
    _model = (d['model'] as String?) ?? liveModel;
  }

  Future<void> _connect() async {
    final url = 'wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContentConstrained'
        '?access_token=${Uri.encodeQueryComponent(_token!)}';
    final ws = await WebSocket.connect(url).timeout(const Duration(seconds: 15));
    _ws = ws;
    final ready = Completer<void>();
    ws.listen(
      (data) => _onMessage(data, ready),
      onError: (Object e) {
        if (!ready.isCompleted) ready.completeError(e);
      },
      onDone: () {
        if (!ready.isCompleted) ready.completeError('Gemini closed the connection (${ws.closeCode} ${ws.closeReason ?? ''})');
        _onClosed(ws);
      },
    );
    _send({'setup': _setup()});
    await ready.future.timeout(const Duration(seconds: 15));
    await _startMic();
    _set(CallState.listening);
  }

  Map<String, dynamic> _setup() {
    final now = DateFormat('EEEE d MMMM yyyy, HH:mm').format(DateTime.now());
    return {
      'model': 'models/$_model',
      'generationConfig': {
        'responseModalities': ['AUDIO'],
        'speechConfig': {
          'voiceConfig': {
            'prebuiltVoiceConfig': {'voiceName': neo.geminiVoice}
          }
        },
      },
      'systemInstruction': {
        'parts': [
          {'text': _instructions(now)}
        ]
      },
      'tools': [
        {'functionDeclarations': AgentTools.declarations()},
        {'googleSearch': {}},
      ],
      'inputAudioTranscription': {},
      'outputAudioTranscription': {},
      'contextWindowCompression': {'slidingWindow': {}},
      'sessionResumption': {if (_resumeHandle != null) 'handle': _resumeHandle},
    };
  }

  String _instructions(String now) => '''
You are Neo, Max's personal AI agent and right hand. You are on a live voice call with him, running on ${deviceDescription()}.
Now: $now (Tashkent time).

How you talk:
- Like a sharp, warm friend on the phone. Short spoken sentences, no lists, no markdown. Answer first, details only if asked.
- Always reply in the language Max speaks (Russian, Uzbek or English). You are male.
- If Max interrupts, stop and listen.

What you can do:
- Use your tools whenever they help, without asking permission for normal things (opening apps or sites, searching, reading files, timers, music, volume).
- Risky tools (delete, move, overwrite, close apps, shut down, restart, sleep) show Max a confirm button by themselves. Just call them; if the result says declined, accept it.
- Use Google Search for fresh facts: news, prices, exchange rates, weather, opening hours, finding websites.
- Use ask_neo_memory for anything about Max's own life: money and spending analytics, tasks, reminders, notes, things to remember. Use it to save new reminders and notes too.
- On the laptop: find, read, summarise and analyse files; organise folders; look at the screen when he says "look" or "what's on my screen".
- After a tool runs, say in a few words what you did. Never read out file paths in full; say the file name.
''';

  void _send(Map<String, dynamic> msg) {
    try {
      _ws?.add(jsonEncode(msg));
    } catch (_) {}
  }

  void _onClosed(WebSocket ws) {
    if (!identical(ws, _ws)) return;
    _ws = null;
    if (_ending || state == CallState.off) return;
    // Gemini ends sessions after a while: carry on in a new one where we left off.
    if (_resumeHandle != null) {
      _reconnect();
    } else {
      error = 'The call dropped.';
      _teardown().then((_) => _set(CallState.error));
    }
  }

  Future<void> _reconnect() async {
    _set(CallState.connecting);
    await _mic?.cancel();
    _mic = null;
    try {
      await _rec.stop();
    } catch (_) {}
    try {
      await _connect();
    } catch (_) {
      try {
        await _fetchToken();
        await _connect();
      } catch (e) {
        error = 'The call dropped.';
        await _teardown();
        _set(CallState.error);
      }
    }
  }

  // ---- incoming ----

  void _onMessage(dynamic data, Completer<void> ready) {
    final Map<String, dynamic> m;
    try {
      m = jsonDecode(data is String ? data : utf8.decode(data as List<int>)) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    if (m.containsKey('setupComplete')) {
      if (!ready.isCompleted) ready.complete();
      return;
    }
    final sc = m['serverContent'];
    if (sc is Map) _onServerContent(sc);
    final tc = m['toolCall'];
    if (tc is Map) _onToolCall(tc);
    final ru = m['sessionResumptionUpdate'];
    if (ru is Map && ru['resumable'] == true && (ru['newHandle'] ?? '').toString().isNotEmpty) {
      _resumeHandle = ru['newHandle'] as String;
    }
    if (m.containsKey('goAway') && _resumeHandle != null) {
      final old = _ws;
      _ws = null;
      old?.close();
      _reconnect();
    }
  }

  void _onServerContent(Map sc) {
    if (sc['interrupted'] == true) {
      _stopPlayback();
      _set(CallState.listening);
    }
    final input = (sc['inputTranscription'] as Map?)?['text'];
    if (input is String && input.trim().isNotEmpty) _appendLine('me', input);
    final output = (sc['outputTranscription'] as Map?)?['text'];
    if (output is String && output.isNotEmpty) _appendLine('neo', output);

    final turn = sc['modelTurn'];
    if (turn is Map && turn['parts'] is List) {
      for (final p in turn['parts'] as List) {
        final inline = (p as Map)['inlineData'];
        if (inline is Map && inline['data'] is String) _play(base64Decode(inline['data'] as String));
      }
    }
    if (sc['turnComplete'] == true) _endPlaybackStream();
  }

  void _appendLine(String who, String text) {
    if (lines.isNotEmpty && lines.last.who == who) {
      lines.last.text += text;
    } else {
      if (lines.length > 60) lines.removeAt(0);
      lines.add(CallLine(who, text.trimLeft()));
    }
    notifyListeners();
  }

  Future<void> _onToolCall(Map tc) async {
    final calls = (tc['functionCalls'] as List?)?.whereType<Map>().toList() ?? const [];
    if (calls.isEmpty) return;
    _set(CallState.thinking);
    final responses = <Map<String, dynamic>>[];
    for (final c in calls) {
      final name = (c['name'] ?? '').toString();
      final args = c['args'] is Map ? Map<String, dynamic>.from(c['args'] as Map) : <String, dynamic>{};
      lines.add(CallLine('tool', _toolLabel(name, args)));
      notifyListeners();
      final result = await AgentTools.run(name, args);
      responses.add({'id': c['id'], 'name': name, 'response': _trim(result)});
    }
    _send({
      'toolResponse': {'functionResponses': responses}
    });
  }

  /// Keep tool results small: the model only needs the gist.
  static Map<String, dynamic> _trim(Map<String, dynamic> r) {
    final s = jsonEncode(r);
    if (s.length < 24000) return r;
    return {'result_truncated': s.substring(0, 24000)};
  }

  static String _toolLabel(String name, Map<String, dynamic> a) {
    final arg = (a['path'] ?? a['query'] ?? a['name'] ?? a['url'] ?? a['action'] ?? a['request'] ?? a['key'] ?? '').toString();
    final short = arg.length > 40 ? '${arg.substring(0, 40)}…' : arg;
    final what = name.replaceAll('_', ' ');
    return short.isEmpty ? what : '$what · $short';
  }

  void _sendImage(Uint8List jpeg) {
    _send({
      'realtimeInput': {
        'video': {'mimeType': 'image/jpeg', 'data': base64Encode(jpeg)}
      }
    });
  }

  // ---- microphone → Gemini ----

  Future<void> _startMic() async {
    final stream = await _rec.startStream(const RecordConfig(
      encoder: AudioEncoder.pcm16bits,
      sampleRate: 16000,
      numChannels: 1,
      echoCancel: true,
      noiseSuppress: true,
      autoGain: true,
    ));
    _mic = stream.listen(_onMic);
  }

  double _micLevel = 0;

  void _onMic(Uint8List chunk) {
    final rms = _rms(chunk);
    _micLevel = _micLevel * 0.6 + rms * 0.4;
    if (muted || _ws == null) return;
    // On a phone speaker Neo can hear himself. While he talks, only pass on sound that is
    // clearly louder than his echo, so you can still interrupt him by speaking up.
    if (state == CallState.speaking && Platform.isAndroid && rms < 0.10) return;
    _send({
      'realtimeInput': {
        'audio': {'mimeType': 'audio/pcm;rate=16000', 'data': base64Encode(chunk)}
      }
    });
  }

  static double _rms(Uint8List b) {
    if (b.length < 2) return 0;
    final d = ByteData.sublistView(b);
    var sum = 0.0;
    final n = b.length ~/ 2;
    for (var i = 0; i < n; i++) {
      final v = d.getInt16(i * 2, Endian.little) / 32768.0;
      sum += v * v;
    }
    return math.min(1.0, math.sqrt(sum / n) * 3);
  }

  void _tickLevel() {
    final target = state == CallState.speaking ? 0.35 + math.Random().nextDouble() * 0.5 : (muted ? 0.0 : _micLevel);
    level = level * 0.5 + target * 0.5;
    notifyListeners();
  }

  // ---- Gemini → speaker (24 kHz 16-bit mono PCM) ----

  void _play(Uint8List pcm) {
    final s = SoLoud.instance;
    if (_out == null) {
      _out = s.setBufferStream(
        bufferingType: BufferingType.released,
        bufferingTimeNeeds: 0.12,
        sampleRate: 24000,
        channels: Channels.mono,
        format: BufferType.s16le,
      );
      _outHandle = s.play(_out!);
      _outBytes = 0;
      _outStart = DateTime.now();
    }
    s.addAudioDataStream(_out!, pcm);
    _outBytes += pcm.length;
    _doneSpeaking?.cancel();
    if (state != CallState.speaking) _set(CallState.speaking);
  }

  /// The model finished its turn: let the buffered audio play out, then listen again.
  void _endPlaybackStream() {
    final out = _out;
    if (out == null) {
      if (state == CallState.thinking || state == CallState.speaking) _set(CallState.listening);
      return;
    }
    try {
      SoLoud.instance.setDataIsEnded(out);
    } catch (_) {}
    final total = Duration(milliseconds: (_outBytes / 48).round()); // 24000 samples/s × 2 bytes
    final played = DateTime.now().difference(_outStart ?? DateTime.now());
    final left = total - played + const Duration(milliseconds: 250);
    final handle = _outHandle;
    _out = null;
    _outHandle = null;
    _doneSpeaking = Timer(left.isNegative ? Duration.zero : left, () async {
      if (state == CallState.speaking) _set(CallState.listening);
      try {
        if (handle != null) await SoLoud.instance.stop(handle);
        await SoLoud.instance.disposeSource(out);
      } catch (_) {}
    });
  }

  void _stopPlayback() {
    _doneSpeaking?.cancel();
    final out = _out, h = _outHandle;
    _out = null;
    _outHandle = null;
    if (out == null) return;
    () async {
      try {
        if (h != null) await SoLoud.instance.stop(h);
        await SoLoud.instance.disposeSource(out);
      } catch (_) {}
    }();
  }

  // ---- cleanup ----

  Future<void> _teardown() async {
    _levelTimer?.cancel();
    _levelTimer = null;
    _doneSpeaking?.cancel();
    AgentTools.sendImage = null;
    NeoTimers.onDone = null;
    await _mic?.cancel();
    _mic = null;
    try {
      await _rec.stop();
    } catch (_) {}
    _stopPlayback();
    final ws = _ws;
    _ws = null;
    try {
      await ws?.close();
    } catch (_) {}
    level = 0;
    _started = null;
  }

  void _set(CallState s) {
    state = s;
    notifyListeners();
  }

  static String _friendly(Object e) {
    if (e is SocketException || e is TimeoutException || e is HandshakeException) return 'No connection to Neo. Check the internet.';
    if (e is WebSocketException) return 'Could not open the voice line.';
    return 'Something went wrong: $e';
  }
}
