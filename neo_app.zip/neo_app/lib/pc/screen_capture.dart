import 'dart:ffi';
import 'dart:isolate';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:ffi/ffi.dart';
import 'package:image/image.dart' as img;
import 'package:win32/win32.dart';

/// Native screen capture (GDI). Windows Defender blocks the PowerShell way of doing this,
/// so it is done here directly, off the UI thread.
class ScreenCapture {
  ScreenCapture._();

  /// JPEG of the primary screen, at most [width] px wide.
  /// [cursor] draws the mouse pointer (GDI captures leave it out), for the phone's remote view.
  static Future<Uint8List?> jpeg({int width = 1280, int quality = 70, bool cursor = false}) =>
      Isolate.run(() => _grab(width, quality, cursor));

  static Uint8List? _grab(int maxWidth, int quality, bool cursor) {
    final w = GetSystemMetrics(SM_CXSCREEN);
    final h = GetSystemMetrics(SM_CYSCREEN);
    if (w <= 0 || h <= 0) return null;
    final screen = GetDC(NULL);
    final mem = CreateCompatibleDC(screen);
    final bmp = CreateCompatibleBitmap(screen, w, h);
    final old = SelectObject(mem, bmp);
    final info = calloc<BITMAPINFO>();
    final pixels = calloc<Uint8>(w * h * 4);
    try {
      BitBlt(mem, 0, 0, w, h, screen, 0, 0, SRCCOPY);
      info.ref.bmiHeader
        ..biSize = sizeOf<BITMAPINFOHEADER>()
        ..biWidth = w
        ..biHeight = -h // top-down rows
        ..biPlanes = 1
        ..biBitCount = 32
        ..biCompression = BI_RGB;
      final rows = GetDIBits(mem, bmp, 0, h, pixels.cast(), info, DIB_RGB_COLORS);
      if (rows == 0) return null;
      final bytes = Uint8List.fromList(pixels.asTypedList(w * h * 4));
      var image = img.Image.fromBytes(width: w, height: h, bytes: bytes.buffer, numChannels: 4, order: img.ChannelOrder.bgra);
      if (cursor) {
        final pt = calloc<POINT>();
        try {
          if (GetCursorPos(pt) != 0) {
            final cx = pt.ref.x, cy = pt.ref.y;
            final r = math.max(6, w ~/ 200);
            img.fillCircle(image, x: cx, y: cy, radius: r + 3, color: img.ColorRgb8(255, 255, 255));
            img.fillCircle(image, x: cx, y: cy, radius: r, color: img.ColorRgb8(240, 138, 93));
          }
        } finally {
          calloc.free(pt);
        }
      }
      final target = math.min(maxWidth, w);
      if (target < w) image = img.copyResize(image, width: target, interpolation: img.Interpolation.average);
      return Uint8List.fromList(img.encodeJpg(image, quality: quality));
    } finally {
      SelectObject(mem, old);
      DeleteObject(bmp);
      DeleteDC(mem);
      ReleaseDC(NULL, screen);
      calloc.free(info);
      calloc.free(pixels);
    }
  }
}
