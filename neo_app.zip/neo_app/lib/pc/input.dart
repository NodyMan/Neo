import 'dart:ffi';

import 'package:ffi/ffi.dart';
import 'package:win32/win32.dart';

/// Mouse and keyboard for the phone's remote control (Windows SendInput).
/// Coordinates from the phone are 0..1 of the primary screen.
class PcInput {
  PcInput._();

  static (int, int) screen() => (GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN));

  static void _to(double x, double y) {
    final (w, h) = screen();
    SetCursorPos((x.clamp(0.0, 1.0) * (w - 1)).round(), (y.clamp(0.0, 1.0) * (h - 1)).round());
  }

  static void _mouse(int flags, {int data = 0}) {
    final i = calloc<INPUT>();
    try {
      i.ref.type = INPUT_MOUSE;
      i.ref.mi.dwFlags = flags;
      i.ref.mi.mouseData = data;
      SendInput(1, i, sizeOf<INPUT>());
    } finally {
      calloc.free(i);
    }
  }

  static (int, int) _buttonFlags(String button) => switch (button) {
        'right' => (MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP),
        'middle' => (MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP),
        _ => (MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP),
      };

  static void move(double x, double y) => _to(x, y);

  static void click(double x, double y, {String button = 'left', bool double = false}) {
    _to(x, y);
    final (down, up) = _buttonFlags(button);
    for (var n = 0; n < (double ? 2 : 1); n++) {
      _mouse(down);
      _mouse(up);
    }
  }

  static void down(double x, double y, {String button = 'left'}) {
    _to(x, y);
    _mouse(_buttonFlags(button).$1);
  }

  static void up(double x, double y, {String button = 'left'}) {
    _to(x, y);
    _mouse(_buttonFlags(button).$2);
  }

  /// [clicks] > 0 scrolls up, < 0 down (one click = one wheel notch).
  static void scroll(int clicks) => _mouse(MOUSEEVENTF_WHEEL, data: clicks * 120); // 120 = one wheel notch

  // ---- keyboard ----

  static const _vk = <String, int>{
    'enter': VK_RETURN, 'return': VK_RETURN, 'esc': VK_ESCAPE, 'escape': VK_ESCAPE, 'tab': VK_TAB, 'space': VK_SPACE,
    'backspace': VK_BACK, 'delete': VK_DELETE, 'del': VK_DELETE, 'up': VK_UP, 'down': VK_DOWN, 'left': VK_LEFT, 'right': VK_RIGHT,
    'home': VK_HOME, 'end': VK_END, 'pageup': VK_PRIOR, 'pagedown': VK_NEXT, 'win': VK_LWIN, 'windows': VK_LWIN,
    'ctrl': VK_CONTROL, 'control': VK_CONTROL, 'alt': VK_MENU, 'shift': VK_SHIFT,
    'volumeup': VK_VOLUME_UP, 'volumedown': VK_VOLUME_DOWN, 'volumemute': VK_VOLUME_MUTE, 'mute': VK_VOLUME_MUTE,
    'playpause': VK_MEDIA_PLAY_PAUSE, 'play': VK_MEDIA_PLAY_PAUSE, 'pause': VK_MEDIA_PLAY_PAUSE,
    'nexttrack': VK_MEDIA_NEXT_TRACK, 'next': VK_MEDIA_NEXT_TRACK, 'prevtrack': VK_MEDIA_PREV_TRACK, 'prev': VK_MEDIA_PREV_TRACK,
    'f1': VK_F1, 'f2': VK_F2, 'f3': VK_F3, 'f4': VK_F4, 'f5': VK_F5, 'f11': VK_F11, 'printscreen': VK_SNAPSHOT,
  };

  static int? _code(String k) {
    final c = _vk[k];
    if (c != null) return c;
    if (k.length == 1) {
      final u = k.toUpperCase().codeUnitAt(0);
      if ((u >= 0x30 && u <= 0x39) || (u >= 0x41 && u <= 0x5A)) return u;
    }
    return null;
  }

  static void _key(int vk, bool up) {
    final i = calloc<INPUT>();
    try {
      i.ref.type = INPUT_KEYBOARD;
      i.ref.ki.wVk = vk;
      i.ref.ki.dwFlags = up ? KEYEVENTF_KEYUP : 0;
      SendInput(1, i, sizeOf<INPUT>());
    } finally {
      calloc.free(i);
    }
  }

  /// "enter", "ctrl+c", "alt+tab", "win+d"… Returns false for an unknown key.
  static bool keys(String combo) {
    final codes = combo.toLowerCase().split('+').map((k) => _code(k.trim())).toList();
    if (codes.isEmpty || codes.any((c) => c == null)) return false;
    for (final c in codes) {
      _key(c!, false);
    }
    for (final c in codes.reversed) {
      _key(c!, true);
    }
    return true;
  }

  /// Types any text (Russian and Uzbek too) as Unicode key presses.
  static void type(String text) {
    for (final unit in text.replaceAll('\r', '').codeUnits) {
      if (unit == 10) {
        keys('enter');
        continue;
      }
      for (final up in [false, true]) {
        final i = calloc<INPUT>();
        try {
          i.ref.type = INPUT_KEYBOARD;
          i.ref.ki.wScan = unit;
          i.ref.ki.dwFlags = KEYEVENTF_UNICODE | (up ? KEYEVENTF_KEYUP : 0);
          SendInput(1, i, sizeOf<INPUT>());
        } finally {
          calloc.free(i);
        }
      }
    }
  }

  static void lock() => LockWorkStation();
}
