import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'screen_capture.dart';

/// Neo's hands on a Windows laptop: files, apps, power, keys, screen and system info.
/// Everything runs locally through dart:io and PowerShell; nothing here talks to the internet.
class PcAgent {
  PcAgent._();

  static bool get available => Platform.isWindows;

  // ---- well-known folders (Desktop may live in OneDrive) ----

  static Map<String, String>? _known;

  static Future<Map<String, String>> knownFolders() async {
    if (_known != null) return _known!;
    final home = Platform.environment['USERPROFILE'] ?? '';
    final m = <String, String>{'home': home};
    try {
      final r = await _ps(r"""
$o=[ordered]@{}
$o.desktop=[Environment]::GetFolderPath('Desktop')
$o.documents=[Environment]::GetFolderPath('MyDocuments')
$o.pictures=[Environment]::GetFolderPath('MyPictures')
$o.music=[Environment]::GetFolderPath('MyMusic')
$o.videos=[Environment]::GetFolderPath('MyVideos')
$o.downloads=(New-Object -ComObject Shell.Application).NameSpace('shell:Downloads').Self.Path
$o | ConvertTo-Json -Compress""");
      final j = jsonDecode(r) as Map<String, dynamic>;
      j.forEach((k, v) {
        if (v is String && v.isNotEmpty) m[k] = v;
      });
    } catch (_) {
      for (final k in ['Desktop', 'Documents', 'Downloads', 'Pictures', 'Music', 'Videos']) {
        m[k.toLowerCase()] = '$home\\$k';
      }
    }
    return _known = m;
  }

  /// "Desktop\\report.docx", "~/Downloads", "downloads" → absolute Windows path.
  static Future<String> resolve(String p) async {
    var s = p.trim().replaceAll('/', '\\');
    if (s.isEmpty) s = 'home';
    final known = await knownFolders();
    if (s == '~') return known['home']!;
    if (s.startsWith('~\\')) return '${known['home']}${s.substring(1)}';
    final first = s.split('\\').first.toLowerCase();
    if (known.containsKey(first) && !s.contains(':')) {
      final rest = s.length > first.length ? s.substring(first.length) : '';
      return '${known[first]}$rest';
    }
    if (!RegExp(r'^[a-zA-Z]:').hasMatch(s) && !s.startsWith('\\\\')) return '${known['home']}\\$s';
    return s;
  }

  // ---- files ----

  static Future<Map<String, dynamic>> listFolder(String path) async {
    final dir = Directory(await resolve(path));
    if (!await dir.exists()) return {'error': 'folder not found: ${dir.path}'};
    final items = <Map<String, dynamic>>[];
    await for (final e in dir.list(followLinks: false).handleError((_) {})) {
      final name = e.path.split('\\').last;
      if (name.startsWith('.') || name == 'desktop.ini') continue;
      try {
        final st = await e.stat();
        items.add({
          'name': name,
          'type': st.type == FileSystemEntityType.directory ? 'folder' : 'file',
          if (st.type == FileSystemEntityType.file) 'size': _size(st.size),
          'modified': st.modified.toIso8601String().substring(0, 16),
        });
      } catch (_) {}
      if (items.length >= 200) break;
    }
    items.sort((a, b) => (a['type'] == b['type'] ? 0 : (a['type'] == 'folder' ? -1 : 1)));
    return {'path': dir.path, 'count': items.length, 'items': items};
  }

  static const _skip = {r'appdata', r'node_modules', r'.git', r'$recycle.bin', r'windows', r'program files', r'program files (x86)', r'programdata'};

  /// Finds files and folders whose name contains [query], starting in [folder] (home by default).
  static Future<Map<String, dynamic>> searchFiles(String query, {String folder = 'home', int limit = 40}) async {
    final q = query.toLowerCase().trim();
    if (q.isEmpty) return {'error': 'empty search'};
    final start = await resolve(folder);
    final found = <Map<String, dynamic>>[];
    final queue = <Directory>[Directory(start)];
    final watch = Stopwatch()..start();
    while (queue.isNotEmpty && found.length < limit && watch.elapsed < const Duration(seconds: 10)) {
      final d = queue.removeAt(0);
      try {
        await for (final e in d.list(followLinks: false)) {
          final name = e.path.split('\\').last;
          final lower = name.toLowerCase();
          if (e is Directory) {
            if (!_skip.contains(lower) && !lower.startsWith('.')) queue.add(e);
          }
          if (lower.contains(q)) {
            found.add({'path': e.path, 'type': e is Directory ? 'folder' : 'file'});
            if (found.length >= limit) break;
          }
        }
      } catch (_) {
        // no access to this folder: skip it
      }
    }
    return {'query': query, 'searched_from': start, 'results': found, if (queue.isNotEmpty && found.length < limit) 'note': 'stopped after 10 s'};
  }

  static const _textExt = {
    'txt', 'md', 'csv', 'json', 'log', 'xml', 'html', 'htm', 'css', 'js', 'ts', 'dart', 'py', 'java', 'kt', 'c', 'cpp', 'h', 'cs',
    'go', 'rs', 'sql', 'yaml', 'yml', 'ini', 'cfg', 'bat', 'ps1', 'sh', 'srt', 'tsv',
  };

  static Future<Map<String, dynamic>> readFile(String path, {int maxChars = 20000}) async {
    final f = File(await resolve(path));
    if (!await f.exists()) return {'error': 'file not found: ${f.path}'};
    final ext = f.path.split('.').last.toLowerCase();
    if (!_textExt.contains(ext)) {
      if (ext == 'docx' || ext == 'pdf' || ext == 'xlsx' || ext == 'pptx') {
        final text = await _officeText(f.path, ext);
        if (text != null) return {'path': f.path, 'text': _cut(text, maxChars)};
      }
      return {'path': f.path, 'error': 'not a text file (.$ext); I can open it instead', 'size': _size(await f.length())};
    }
    try {
      final text = await f.readAsString();
      return {'path': f.path, 'chars': text.length, 'text': _cut(text, maxChars)};
    } catch (_) {
      final bytes = await f.readAsBytes();
      return {'path': f.path, 'text': _cut(latin1.decode(bytes, allowInvalid: true), maxChars)};
    }
  }

  /// Text out of Word documents (and PDFs if Word can open them) via the Office COM objects, when Office is installed.
  static Future<String?> _officeText(String path, String ext) async {
    if (ext != 'docx' && ext != 'pdf') return null;
    try {
      final r = await _ps("""
\$w=New-Object -ComObject Word.Application; \$w.Visible=\$false
try { \$d=\$w.Documents.Open('${_q(path)}', \$false, \$true); \$t=\$d.Content.Text; \$d.Close(\$false) } finally { \$w.Quit() }
\$t""", timeout: const Duration(seconds: 40));
      return r.trim().isEmpty ? null : r;
    } catch (_) {
      return null;
    }
  }

  static Future<Map<String, dynamic>> writeFile(String path, String content, {bool append = false}) async {
    final f = File(await resolve(path));
    await f.parent.create(recursive: true);
    await f.writeAsString(content, mode: append ? FileMode.append : FileMode.write, flush: true);
    return {'ok': true, 'path': f.path, 'chars': content.length};
  }

  static Future<bool> exists(String path) async => FileSystemEntity.typeSync(await resolve(path)) != FileSystemEntityType.notFound;

  static Future<Map<String, dynamic>> createFolder(String path) async {
    final d = Directory(await resolve(path));
    await d.create(recursive: true);
    return {'ok': true, 'path': d.path};
  }

  static Future<Map<String, dynamic>> copyPath(String from, String to) async {
    final src = await resolve(from), dst = await resolve(to);
    final r = await _ps("Copy-Item -LiteralPath '${_q(src)}' -Destination '${_q(dst)}' -Recurse -Force; 'ok'");
    return {'ok': r.contains('ok'), 'from': src, 'to': dst};
  }

  static Future<Map<String, dynamic>> movePath(String from, String to) async {
    final src = await resolve(from), dst = await resolve(to);
    final r = await _ps("Move-Item -LiteralPath '${_q(src)}' -Destination '${_q(dst)}' -Force; 'ok'");
    return {'ok': r.contains('ok'), 'from': src, 'to': dst};
  }

  /// Deletes to the Recycle Bin, so a mistake can still be undone.
  static Future<Map<String, dynamic>> deletePath(String path) async {
    final p = await resolve(path);
    if (FileSystemEntity.typeSync(p) == FileSystemEntityType.notFound) return {'error': 'not found: $p'};
    final isDir = FileSystemEntity.isDirectorySync(p);
    final r = await _ps("""
Add-Type -AssemblyName Microsoft.VisualBasic
[Microsoft.VisualBasic.FileIO.FileSystem]::${isDir ? 'DeleteDirectory' : 'DeleteFile'}('${_q(p)}','OnlyErrorDialogs','SendToRecycleBin'); 'ok'""");
    return {'ok': r.contains('ok'), 'path': p, 'note': 'moved to the Recycle Bin'};
  }

  /// Opens a file, folder, app or URL the way a double-click would.
  static Future<Map<String, dynamic>> openPath(String path) async {
    final p = RegExp(r'^[a-z][a-z0-9+.-]*:', caseSensitive: false).hasMatch(path) && !RegExp(r'^[a-zA-Z]:\\').hasMatch(path)
        ? path
        : await resolve(path);
    await Process.start('explorer.exe', [p], mode: ProcessStartMode.detached);
    return {'ok': true, 'opened': p};
  }

  // ---- apps ----

  static const _apps = {
    'telegram': 'tg://', 'whatsapp': 'whatsapp:', 'spotify': 'spotify:', 'settings': 'ms-settings:', 'calculator': 'calculator:',
    'store': 'ms-windows-store:', 'mail': 'outlookmail:', 'camera': 'microsoft.windows.camera:', 'notepad': 'notepad.exe',
    'paint': 'mspaint.exe', 'explorer': 'explorer.exe', 'files': 'explorer.exe', 'task manager': 'taskmgr.exe', 'terminal': 'wt.exe',
    'cmd': 'cmd.exe', 'chrome': 'chrome.exe', 'edge': 'msedge.exe', 'word': 'winword.exe', 'excel': 'excel.exe', 'powerpoint': 'powerpnt.exe',
    'vs code': 'code', 'vscode': 'code', 'youtube': 'https://www.youtube.com', 'gmail': 'https://mail.google.com',
    'instagram': 'https://www.instagram.com', 'chatgpt': 'https://chatgpt.com', 'github': 'https://github.com',
  };

  static Future<Map<String, dynamic>> openApp(String name) async {
    final n = name.trim().toLowerCase();
    if (n.isEmpty) return {'error': 'no app name'};
    final direct = _apps[n];
    if (direct != null) {
      await Process.start('cmd', ['/c', 'start', '', direct], mode: ProcessStartMode.detached, runInShell: false);
      return {'ok': true, 'opened': name};
    }
    // Find it among the Start menu apps (covers Store apps too).
    final r = await _ps("""
\$a = Get-StartApps | Where-Object { \$_.Name -like '*${_q(name)}*' } | Select-Object -First 1
if (\$a) { Start-Process ('shell:AppsFolder\\' + \$a.AppID); 'ok:' + \$a.Name } else { 'none' }""");
    if (r.startsWith('ok:')) return {'ok': true, 'opened': r.substring(3).trim()};
    try {
      await Process.start('cmd', ['/c', 'start', '', name], mode: ProcessStartMode.detached);
      return {'ok': true, 'opened': name};
    } catch (_) {
      return {'error': 'app not found: $name'};
    }
  }

  static Future<Map<String, dynamic>> runningApps() async {
    final r = await _ps(r"Get-Process | Where-Object { $_.MainWindowTitle } | Select-Object -First 40 ProcessName, MainWindowTitle | ConvertTo-Json -Compress");
    return {'apps': r.trim().isEmpty ? [] : jsonDecode(r)};
  }

  static Future<Map<String, dynamic>> closeApp(String name) async {
    final r = await _ps("""
\$p = Get-Process | Where-Object { \$_.ProcessName -like '*${_q(name)}*' -or \$_.MainWindowTitle -like '*${_q(name)}*' }
if (\$p) { \$p | ForEach-Object { \$_.CloseMainWindow() | Out-Null }; 'closed:' + (\$p | Select-Object -ExpandProperty ProcessName -Unique) -join ',' } else { 'none' }""");
    return r.startsWith('closed:') ? {'ok': true, 'closed': r.substring(7).trim()} : {'error': 'no running app matches $name'};
  }

  // ---- power ----

  static Future<Map<String, dynamic>> power(String action, {int delaySeconds = 30}) async {
    switch (action) {
      case 'shutdown':
        await Process.run('shutdown', ['/s', '/t', '$delaySeconds']);
        return {'ok': true, 'note': 'shutting down in $delaySeconds s; say "cancel shutdown" to stop'};
      case 'restart':
        await Process.run('shutdown', ['/r', '/t', '$delaySeconds']);
        return {'ok': true, 'note': 'restarting in $delaySeconds s'};
      case 'cancel':
        await Process.run('shutdown', ['/a']);
        return {'ok': true};
      case 'sleep':
        await Process.start('rundll32.exe', ['powrprof.dll,SetSuspendState', '0,1,0'], mode: ProcessStartMode.detached);
        return {'ok': true};
      case 'lock':
        await Process.start('rundll32.exe', ['user32.dll,LockWorkStation'], mode: ProcessStartMode.detached);
        return {'ok': true};
      case 'sign_out':
        await Process.run('shutdown', ['/l']);
        return {'ok': true};
    }
    return {'error': 'unknown power action $action'};
  }

  // ---- keyboard / media ----

  static const _keyCodes = {
    'volume_up': 175, 'volume_down': 174, 'mute': 173, 'play_pause': 179, 'next': 176, 'previous': 177, 'stop': 178,
  };

  static Future<Map<String, dynamic>> media(String key, {int times = 1}) async {
    final code = _keyCodes[key];
    if (code == null) return {'error': 'unknown media key $key'};
    await _ps("\$w=New-Object -ComObject WScript.Shell; 1..$times | ForEach-Object { \$w.SendKeys([char]$code) }; 'ok'");
    return {'ok': true};
  }

  /// SendKeys syntax: "^c" = Ctrl+C, "%{TAB}" = Alt+Tab, "{ENTER}", or plain text to type.
  static Future<Map<String, dynamic>> sendKeys(String keys) async {
    await _ps("\$w=New-Object -ComObject WScript.Shell; \$w.SendKeys('${_q(keys)}'); 'ok'");
    return {'ok': true};
  }

  static Future<Map<String, dynamic>> typeText(String text) async {
    // Paste through the clipboard: works for any language, unlike SendKeys.
    await _ps("Set-Clipboard -Value '${_q(text)}'; \$w=New-Object -ComObject WScript.Shell; Start-Sleep -Milliseconds 150; \$w.SendKeys('^v'); 'ok'");
    return {'ok': true};
  }

  static Future<Map<String, dynamic>> setClipboard(String text) async {
    await _ps("Set-Clipboard -Value '${_q(text)}'; 'ok'");
    return {'ok': true};
  }

  static Future<String> clipboard() async => (await _ps('Get-Clipboard -Raw')).trim();

  // ---- screen ----

  /// JPEG of the main screen, scaled to [width] px wide (for Neo to look at, or to save).
  static Future<Uint8List?> captureScreen({int width = 1280, int quality = 70, String? saveTo}) async {
    final bytes = await ScreenCapture.jpeg(width: width, quality: quality);
    if (bytes != null && saveTo != null) await File(saveTo).writeAsBytes(bytes, flush: true);
    return bytes;
  }

  static Future<Map<String, dynamic>> screenshot() async {
    final pics = (await knownFolders())['pictures'] ?? Directory.systemTemp.path;
    final dir = Directory('$pics\\Neo')..createSync(recursive: true);
    final ts = DateTime.now().toIso8601String().substring(0, 19).replaceAll(':', '-');
    final path = '${dir.path}\\neo_$ts.jpg';
    final b = await captureScreen(width: 3840, quality: 92, saveTo: path);
    return b == null ? {'error': 'could not capture the screen'} : {'ok': true, 'saved': path};
  }

  // ---- system info (for "how's my laptop?" and analytics) ----

  static Future<Map<String, dynamic>> systemInfo() async {
    final r = await _ps(r"""
$os=Get-CimInstance Win32_OperatingSystem
$cpu=(Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average
$bat=Get-CimInstance Win32_Battery | Select-Object -First 1
$disks=Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object { [ordered]@{ drive=$_.DeviceID; free_gb=[math]::Round($_.FreeSpace/1GB,1); size_gb=[math]::Round($_.Size/1GB,1) } }
$wifi=(netsh wlan show interfaces | Select-String '^\s+SSID\s+:' | Select-Object -First 1) -replace '.*:\s*',''
$top=Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 5 | ForEach-Object { [ordered]@{ name=$_.ProcessName; ram_mb=[math]::Round($_.WorkingSet64/1MB) } }
[ordered]@{
  pc=$env:COMPUTERNAME; windows=$os.Caption; uptime_hours=[math]::Round(((Get-Date)-$os.LastBootUpTime).TotalHours,1)
  cpu_percent=$cpu; ram_used_gb=[math]::Round(($os.TotalVisibleMemorySize-$os.FreePhysicalMemory)/1MB,1); ram_total_gb=[math]::Round($os.TotalVisibleMemorySize/1MB,1)
  battery_percent=$bat.EstimatedChargeRemaining; charging=($bat.BatteryStatus -eq 2); disks=@($disks); wifi=$wifi; top_ram_apps=@($top)
} | ConvertTo-Json -Compress -Depth 4""", timeout: const Duration(seconds: 25));
    try {
      return Map<String, dynamic>.from(jsonDecode(r) as Map);
    } catch (_) {
      return {'error': 'could not read system info'};
    }
  }

  // ---- the phone-style action vocabulary the n8n backend returns in chat ----

  static Future<String> runAction(Map<String, dynamic> a) async {
    final action = (a['action'] ?? a['type'] ?? '').toString();
    final target = (a['target'] ?? '').toString();
    final extra = (a['extra'] ?? '').toString();
    try {
      switch (action) {
        case 'open_url':
          await openPath(target.startsWith('http') ? target : 'https://$target');
        case 'web_search':
          await openPath('https://www.google.com/search?q=${Uri.encodeQueryComponent(target)}');
        case 'youtube':
          await openPath('https://www.youtube.com/results?search_query=${Uri.encodeQueryComponent(target)}');
        case 'map_search' || 'navigate':
          await openPath('https://www.google.com/maps/search/${Uri.encodeComponent(target)}');
        case 'open_app':
          final r = await openApp(target.isNotEmpty ? target : (a['package'] ?? '').toString());
          if (r['error'] != null) return '${r['error']}';
        case 'play_music':
          await openPath(target.isEmpty ? 'spotify:' : 'spotify:search:${Uri.encodeComponent(target)}');
        case 'media':
          final k = switch (target.toLowerCase()) {
            'next' => 'next',
            'previous' || 'prev' => 'previous',
            'louder' || 'up' => 'volume_up',
            'quieter' || 'down' => 'volume_down',
            'mute' => 'mute',
            _ => 'play_pause',
          };
          await media(k, times: k.startsWith('volume') ? 5 : 1);
        case 'type':
          await typeText(target);
        case 'copy_text' || 'share_text':
          await setClipboard(target);
        case 'send_message':
          await setClipboard(extra.isNotEmpty ? extra : target);
          await openApp((a['package'] ?? '').toString().contains('whatsapp') ? 'whatsapp' : 'telegram');
          return 'ok (text copied: paste it with Ctrl+V)';
        case 'settings':
          await openPath('ms-settings:');
        case 'timer' || 'alarm':
          return 'ok'; // handled by Neo's in-app timers (NeoTimers)
        case 'call' || 'sms' || 'camera' || 'install_app' || 'tap' || 'read_screen' || 'notifications' || 'notification_access':
          return 'phone only';
        default:
          return 'unknown action';
      }
      return 'ok';
    } catch (e) {
      return 'error: $e';
    }
  }

  // ---- helpers ----

  static String _q(String s) => s.replaceAll("'", "''");

  static String _cut(String s, int max) => s.length <= max ? s : '${s.substring(0, max)}\n…[cut: ${s.length - max} more characters]';

  static String _size(int b) {
    if (b < 1024) return '$b B';
    if (b < 1 << 20) return '${(b / 1024).toStringAsFixed(1)} KB';
    if (b < 1 << 30) return '${(b / (1 << 20)).toStringAsFixed(1)} MB';
    return '${(b / (1 << 30)).toStringAsFixed(2)} GB';
  }

  static Future<String> _ps(String script, {Duration timeout = const Duration(seconds: 20)}) async {
    final r = await Process.run(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', '[Console]::OutputEncoding=[Text.Encoding]::UTF8; $script'],
      stdoutEncoding: utf8,
      stderrEncoding: utf8,
    ).timeout(timeout);
    return (r.stdout as String).trim();
  }
}
