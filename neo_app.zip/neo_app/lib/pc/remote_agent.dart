import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import '../desktop/agent.dart';
import 'input.dart';
import 'screen_capture.dart';

/// Lets the phone's PC tab see and control this laptop.
///
/// Phone and laptop meet on the private Realtime channel "neo-remote:<user id>": only the same
/// account can join it (Supabase policies on realtime.messages), so a phone only ever sees the
/// laptops signed in to its own account.
///   phone → laptop  broadcast "cmd"   {to, from, op, …}  op = watch | unwatch | move | click | down | up | scroll | key | type | lock | ask | ping
///   laptop → phone  broadcast "frame" {from, seq, w, h, sw, sh, img}   JPEG, only while a phone is watching
///   laptop → phone  broadcast "pc"    {from, to, kind: reply | state | error, …}
///   presence        {kind: "pc", id, name, os, version}
class RemoteAgent extends ChangeNotifier {
  RemoteAgent._();
  static final RemoteAgent instance = RemoteAgent._();

  bool enabled = false;
  String status = 'off'; // off | connecting | online | error
  String? detail;
  final _watchers = <String, DateTime>{};
  int get watching => _live().length;

  late final String name = Platform.environment['COMPUTERNAME'] ?? 'PC';
  String? _id;
  RealtimeChannel? _ch;
  Timer? _streamTimer;
  bool _grabbing = false;
  int _seq = 0;
  int _lastHash = 0;
  DateTime _lastSent = DateTime.fromMillisecondsSinceEpoch(0);
  int _width = 1100;
  int _quality = 55;

  // ---- on / off (remembered on this PC; on by default) ----

  Future<File> _prefsFile() async => File('${(await getApplicationSupportDirectory()).path}${Platform.pathSeparator}remote.json');

  Future<void> init() async {
    var on = true;
    try {
      final f = await _prefsFile();
      if (await f.exists()) {
        final j = jsonDecode(await f.readAsString()) as Map;
        on = j['on'] != false;
        _id = j['id'] as String?;
      }
    } catch (_) {}
    _id ??= 'pc-${List.generate(12, (_) => math.Random.secure().nextInt(16).toRadixString(16)).join()}';
    await _savePrefs(on);
    if (on) await start();
  }

  Future<void> _savePrefs(bool on) async {
    try {
      await (await _prefsFile()).writeAsString(jsonEncode({'on': on, 'id': _id}));
    } catch (_) {}
  }

  Future<void> setEnabled(bool on) async {
    await _savePrefs(on);
    on ? await start() : await stop();
  }

  Future<void> start() async {
    if (enabled) return;
    final uid = Supabase.instance.client.auth.currentUser?.id;
    if (uid == null || _id == null) return;
    enabled = true;
    _set('connecting');
    final ch = Supabase.instance.client.channel('neo-remote:$uid', opts: RealtimeChannelConfig(self: false, private: true, key: _id!));
    ch.onBroadcast(event: 'cmd', callback: (raw) => _onCmd(_unwrap(raw)));
    ch.subscribe((s, error) async {
      if (s == RealtimeSubscribeStatus.subscribed) {
        await ch.track({'kind': 'pc', 'id': _id, 'name': name, 'os': 'Windows', 'version': neoAppVersion});
        _set('online');
      } else if (s == RealtimeSubscribeStatus.channelError || s == RealtimeSubscribeStatus.timedOut) {
        detail = error?.toString();
        _set('error');
      } else if (s == RealtimeSubscribeStatus.closed && enabled) {
        _set('connecting');
      }
    });
    _ch = ch;
  }

  Future<void> stop() async {
    enabled = false;
    _watchers.clear();
    _streamTimer?.cancel();
    _streamTimer = null;
    final ch = _ch;
    _ch = null;
    if (ch != null) await Supabase.instance.client.removeChannel(ch);
    _set('off');
  }

  void _set(String s) {
    status = s;
    notifyListeners();
  }

  static Map<String, dynamic> _unwrap(Map<String, dynamic> raw) {
    if (raw.containsKey('op')) return raw;
    final p = raw['payload'];
    return p is Map ? Map<String, dynamic>.from(p) : raw;
  }

  void _send(String event, Map<String, dynamic> payload) {
    _ch?.sendBroadcastMessage(event: event, payload: {'from': _id, ...payload});
  }

  // ---- commands from the phone ----

  double _d(Object? v) => (v as num?)?.toDouble() ?? 0;

  Future<void> _onCmd(Map<String, dynamic> m) async {
    if (m['to'] != _id && m['to'] != '*') return;
    final phone = '${m['from'] ?? 'phone'}';
    final op = '${m['op']}';
    final button = '${m['button'] ?? 'left'}';
    try {
      switch (op) {
        case 'watch':
          _watchers[phone] = DateTime.now();
          if (m['quality'] is num) _quality = (m['quality'] as num).round().clamp(20, 85);
          if (m['width'] is num) _width = (m['width'] as num).round().clamp(480, 1600);
          _ensureStream();
          notifyListeners();
        case 'unwatch':
          _watchers.remove(phone);
          notifyListeners();
        case 'move':
          PcInput.move(_d(m['x']), _d(m['y']));
        case 'click':
          PcInput.click(_d(m['x']), _d(m['y']), button: button, double: m['double'] == true);
        case 'down':
          PcInput.down(_d(m['x']), _d(m['y']), button: button);
        case 'up':
          PcInput.up(_d(m['x']), _d(m['y']), button: button);
        case 'scroll':
          if (m['x'] is num) PcInput.move(_d(m['x']), _d(m['y']));
          PcInput.scroll((m['dy'] as num?)?.round() ?? 0);
        case 'key':
          if (!PcInput.keys('${m['key']}')) _send('pc', {'to': phone, 'kind': 'error', 'text': 'Unknown key ${m['key']}'});
        case 'type':
          PcInput.type('${m['text'] ?? ''}');
        case 'lock':
          PcInput.lock();
        case 'ask':
          final text = '${m['text'] ?? ''}'.trim();
          if (text.isEmpty) return;
          final answer = await DesktopAgent.instance.askFromPhone(text);
          _send('pc', {'to': phone, 'kind': 'reply', 'text': answer});
        case 'ping':
          final (w, h) = PcInput.screen();
          _send('pc', {'to': phone, 'kind': 'state', 'w': w, 'h': h, 'name': name});
      }
      // Any input counts as watching, so the screen keeps coming while the phone is in use.
      if (op != 'unwatch' && op != 'ask') _watchers[phone] = DateTime.now();
    } catch (e) {
      _send('pc', {'to': phone, 'kind': 'error', 'text': '$e'.substring(0, math.min(200, '$e'.length))});
    }
  }

  // ---- screen stream (only while a phone is watching: it says "watch" every 5 s) ----

  List<String> _live() {
    final now = DateTime.now();
    _watchers.removeWhere((_, t) => now.difference(t) > const Duration(seconds: 12));
    return _watchers.keys.toList();
  }

  void _ensureStream() {
    if (_streamTimer != null) return;
    _streamTimer = Timer.periodic(const Duration(milliseconds: 250), (_) => _frame());
  }

  Future<void> _frame() async {
    if (_live().isEmpty || !enabled || _ch == null) {
      _streamTimer?.cancel();
      _streamTimer = null;
      notifyListeners();
      return;
    }
    if (_grabbing) return;
    _grabbing = true;
    try {
      var q = _quality;
      var jpg = await ScreenCapture.jpeg(width: _width, quality: q, cursor: true);
      // Supabase broadcast messages must stay small: lower the quality until the frame fits.
      while (jpg != null && jpg.length * 4 / 3 > 180000 && q > 25) {
        q -= 10;
        jpg = await ScreenCapture.jpeg(width: _width, quality: q, cursor: true);
      }
      if (jpg == null) return;
      final hash = Object.hashAll([jpg.length, for (var i = 0; i < jpg.length; i += 211) jpg[i]]);
      final now = DateTime.now();
      if (hash == _lastHash && now.difference(_lastSent) < const Duration(seconds: 3)) return; // unchanged screen
      _lastHash = hash;
      _lastSent = now;
      final (sw, sh) = PcInput.screen();
      final w = math.min(_width, sw);
      _send('frame', {'seq': ++_seq, 'w': w, 'h': (sh * w / sw).round(), 'sw': sw, 'sh': sh, 'img': base64Encode(jpg)});
    } catch (_) {
    } finally {
      _grabbing = false;
    }
  }
}
