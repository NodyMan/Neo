import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../pc/pc_agent.dart';
import '../theme.dart';

/// Small Markdown renderer for Neo's answers: headings, lists, quotes, tables (as text),
/// fenced code with a Copy button, and inline **bold**, *italic*, `code` and [links](…).
class NeoMarkdown extends StatelessWidget {
  const NeoMarkdown(this.text, {super.key, this.color = NeoColors.ink});
  final String text;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final blocks = <Widget>[];
    final lines = text.replaceAll('\r', '').split('\n');
    final para = <String>[];

    void flush() {
      if (para.isEmpty) return;
      blocks.add(_Inline(para.join('\n'), style: TextStyle(fontSize: 15, height: 1.55, color: color)));
      para.clear();
    }

    var i = 0;
    while (i < lines.length) {
      final l = lines[i];
      final t = l.trimLeft();
      if (t.startsWith('```')) {
        flush();
        final lang = t.substring(3).trim();
        final code = <String>[];
        i++;
        while (i < lines.length && !lines[i].trimLeft().startsWith('```')) {
          code.add(lines[i]);
          i++;
        }
        i++; // closing fence
        blocks.add(_CodeBlock(code.join('\n'), lang: lang));
        continue;
      }
      final h = RegExp(r'^(#{1,4})\s+(.*)$').firstMatch(t);
      if (h != null) {
        flush();
        final level = h.group(1)!.length;
        blocks.add(Padding(
          padding: EdgeInsets.only(top: blocks.isEmpty ? 0 : 6),
          child: _Inline(h.group(2)!, style: TextStyle(fontSize: [20.0, 18.0, 16.0, 15.0][level - 1], fontWeight: FontWeight.w800, height: 1.35, color: color)),
        ));
        i++;
        continue;
      }
      final bullet = RegExp(r'^(\s*)([-*•]|\d+[.)])\s+(.*)$').firstMatch(l);
      if (bullet != null) {
        flush();
        final indent = (bullet.group(1)!.length / 2).floor().clamp(0, 4);
        final mark = RegExp(r'\d').hasMatch(bullet.group(2)!) ? bullet.group(2)! : '•';
        blocks.add(Padding(
          padding: EdgeInsets.only(left: 4.0 + indent * 18),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SizedBox(width: 22, child: Text(mark, style: TextStyle(fontSize: 15, height: 1.55, color: NeoColors.muted))),
            Expanded(child: _Inline(bullet.group(3)!, style: TextStyle(fontSize: 15, height: 1.55, color: color))),
          ]),
        ));
        i++;
        continue;
      }
      if (t.startsWith('>')) {
        flush();
        blocks.add(Container(
          padding: const EdgeInsets.only(left: 12),
          decoration: const BoxDecoration(border: Border(left: BorderSide(color: NeoColors.line, width: 3))),
          child: _Inline(t.replaceFirst(RegExp(r'^>\s?'), ''), style: const TextStyle(fontSize: 15, height: 1.55, color: NeoColors.muted)),
        ));
        i++;
        continue;
      }
      if (t.startsWith('|') && t.endsWith('|')) {
        flush();
        final rows = <String>[];
        while (i < lines.length && lines[i].trim().startsWith('|')) {
          rows.add(lines[i].trim());
          i++;
        }
        blocks.add(_Table(rows));
        continue;
      }
      if (RegExp(r'^(-{3,}|\*{3,})$').hasMatch(t)) {
        flush();
        blocks.add(const Divider(height: 18));
        i++;
        continue;
      }
      if (t.isEmpty) {
        flush();
      } else {
        para.add(l);
      }
      i++;
    }
    flush();
    return SelectionArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          for (var k = 0; k < blocks.length; k++) Padding(padding: EdgeInsets.only(top: k == 0 ? 0 : 8), child: blocks[k]),
        ],
      ),
    );
  }
}

class _Inline extends StatelessWidget {
  const _Inline(this.text, {required this.style});
  final String text;
  final TextStyle style;

  static final _re = RegExp(r'(\*\*[^*]+\*\*|`[^`]+`|\[[^\]]+\]\([^)]+\)|(?<![*\w])\*[^*\n]+\*(?!\*)|_[^_\n]+_)');

  @override
  Widget build(BuildContext context) {
    final spans = <InlineSpan>[];
    var last = 0;
    for (final m in _re.allMatches(text)) {
      if (m.start > last) spans.add(TextSpan(text: text.substring(last, m.start)));
      final s = m.group(0)!;
      if (s.startsWith('**')) {
        spans.add(TextSpan(text: s.substring(2, s.length - 2), style: const TextStyle(fontWeight: FontWeight.w800)));
      } else if (s.startsWith('`')) {
        spans.add(WidgetSpan(
          alignment: PlaceholderAlignment.middle,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
            decoration: BoxDecoration(color: NeoColors.chip, borderRadius: BorderRadius.circular(5), border: Border.all(color: NeoColors.line)),
            child: Text(s.substring(1, s.length - 1), style: const TextStyle(fontFamily: 'Consolas', fontSize: 13.5, color: NeoColors.ink)),
          ),
        ));
      } else if (s.startsWith('[')) {
        final lm = RegExp(r'^\[([^\]]+)\]\(([^)]+)\)$').firstMatch(s)!;
        final url = lm.group(2)!;
        spans.add(TextSpan(
          text: lm.group(1),
          style: const TextStyle(color: Color(0xFF8FA8F0), decoration: TextDecoration.underline),
          recognizer: TapGestureRecognizer()..onTap = () => PcAgent.openPath(url),
        ));
      } else {
        spans.add(TextSpan(text: s.substring(1, s.length - 1), style: const TextStyle(fontStyle: FontStyle.italic)));
      }
      last = m.end;
    }
    if (last < text.length) spans.add(TextSpan(text: text.substring(last)));
    return Text.rich(TextSpan(style: style, children: spans));
  }
}

class _CodeBlock extends StatefulWidget {
  const _CodeBlock(this.code, {required this.lang});
  final String code;
  final String lang;

  @override
  State<_CodeBlock> createState() => _CodeBlockState();
}

class _CodeBlockState extends State<_CodeBlock> {
  bool _copied = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(color: const Color(0xFF0A0A0D), borderRadius: BorderRadius.circular(12), border: Border.all(color: NeoColors.line)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(12, 4, 4, 4),
            decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: NeoColors.line))),
            child: Row(children: [
              Text(widget.lang.isEmpty ? 'code' : widget.lang, style: const TextStyle(fontSize: 12, color: NeoColors.muted)),
              const Spacer(),
              TextButton.icon(
                style: TextButton.styleFrom(foregroundColor: NeoColors.muted, visualDensity: VisualDensity.compact),
                onPressed: () async {
                  await Clipboard.setData(ClipboardData(text: widget.code));
                  setState(() => _copied = true);
                  await Future<void>.delayed(const Duration(milliseconds: 1400));
                  if (mounted) setState(() => _copied = false);
                },
                icon: Icon(_copied ? Icons.check_rounded : Icons.copy_rounded, size: 14),
                label: Text(_copied ? 'Copied' : 'Copy', style: const TextStyle(fontSize: 12)),
              ),
            ]),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.all(12),
            child: Text(widget.code, style: const TextStyle(fontFamily: 'Consolas', fontSize: 13.5, height: 1.45, color: Color(0xFFE4E4EA))),
          ),
        ],
      ),
    );
  }
}

class _Table extends StatelessWidget {
  const _Table(this.rows);
  final List<String> rows;

  @override
  Widget build(BuildContext context) {
    final cells = rows
        .where((r) => !RegExp(r'^\|[\s:|-]+\|$').hasMatch(r))
        .map((r) => r.substring(1, r.length - 1).split('|').map((c) => c.trim()).toList())
        .toList();
    if (cells.isEmpty) return const SizedBox.shrink();
    final cols = cells.map((r) => r.length).reduce((a, b) => a > b ? a : b);
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Container(
        decoration: BoxDecoration(border: Border.all(color: NeoColors.line), borderRadius: BorderRadius.circular(10)),
        child: Table(
          defaultColumnWidth: const IntrinsicColumnWidth(),
          border: const TableBorder(horizontalInside: BorderSide(color: NeoColors.line), verticalInside: BorderSide(color: NeoColors.line)),
          children: [
            for (var r = 0; r < cells.length; r++)
              TableRow(
                decoration: r == 0 ? const BoxDecoration(color: NeoColors.chip) : null,
                children: [
                  for (var c = 0; c < cols; c++)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      child: _Inline(c < cells[r].length ? cells[r][c] : '',
                          style: TextStyle(fontSize: 14, color: NeoColors.ink, fontWeight: r == 0 ? FontWeight.w700 : FontWeight.w400)),
                    ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
