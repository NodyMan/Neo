import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../neo/agent_tools.dart';
import '../neo/live_call.dart';
import '../neo/neo_brain.dart';
import '../neo/neo_face.dart';
import '../screens/approvals_screen.dart';
import '../screens/home_screen.dart';
import '../screens/live_screen.dart';
import '../screens/money_screen.dart';
import '../screens/notes_screen.dart';
import '../screens/settings_screen.dart';
import '../theme.dart';
import 'agent.dart';
import 'markdown.dart';

/// Neo on the laptop: a desktop AI workspace (sidebar with chats and sections, a wide agent chat),
/// not the phone layout in a window.
class DesktopShell extends StatefulWidget {
  const DesktopShell({super.key});

  @override
  State<DesktopShell> createState() => _DesktopShellState();
}

enum _View { chat, voice, today, money, approvals, notes, settings }

const _mainBg = Color(0xFF121216);

class _DesktopShellState extends State<DesktopShell> {
  final agent = DesktopAgent.instance;
  _View _view = _View.chat;
  bool _sidebar = true;

  @override
  void initState() {
    super.initState();
    agent.addListener(_changed);
    NeoCall.instance.addListener(_changed);
    agent.load();
    AgentTools.confirm = _confirm;
  }

  @override
  void dispose() {
    agent.removeListener(_changed);
    NeoCall.instance.removeListener(_changed);
    AgentTools.confirm = null;
    super.dispose();
  }

  void _changed() {
    if (mounted) setState(() {});
  }

  void _go(_View v) => setState(() => _view = v);

  Future<bool> _confirm(String title, String detail) async {
    if (!mounted) return false;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        icon: Icon(Icons.shield_outlined, color: neo.color),
        title: Text(title),
        content: detail.isEmpty ? null : ConstrainedBox(constraints: const BoxConstraints(maxWidth: 420), child: Text(detail, style: const TextStyle(color: NeoColors.muted))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('No')),
          FilledButton(autofocus: true, onPressed: () => Navigator.pop(c, true), child: const Text('Yes, do it')),
        ],
      ),
    );
    return ok == true;
  }

  @override
  Widget build(BuildContext context) {
    return CallbackShortcuts(
      bindings: {
        const SingleActivator(LogicalKeyboardKey.keyN, control: true): () {
          agent.newChat();
          _go(_View.chat);
        },
        const SingleActivator(LogicalKeyboardKey.keyB, control: true): () => setState(() => _sidebar = !_sidebar),
      },
      child: Focus(
        autofocus: true,
        child: Scaffold(
          backgroundColor: NeoColors.ground,
          body: Row(
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                width: _sidebar ? 268 : 0,
                child: _sidebar ? _Sidebar(view: _view, onView: _go, onToggle: () => setState(() => _sidebar = false)) : null,
              ),
              Expanded(
                child: Container(
                  decoration: const BoxDecoration(color: _mainBg, border: Border(left: BorderSide(color: NeoColors.line))),
                  child: Column(
                    children: [
                      if (!_sidebar)
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                            padding: const EdgeInsets.all(8),
                            child: IconButton(tooltip: 'Show sidebar (Ctrl+B)', onPressed: () => setState(() => _sidebar = true), icon: const Icon(Icons.view_sidebar_outlined)),
                          ),
                        ),
                      Expanded(child: _body()),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _narrow(Widget child, {double width = 760}) => Center(child: ConstrainedBox(constraints: BoxConstraints(maxWidth: width), child: child));

  Widget _body() {
    switch (_view) {
      case _View.chat:
        return _ChatView(onVoice: () => _go(_View.voice));
      case _View.voice:
        return _narrow(const LiveScreen(), width: 560);
      case _View.today:
        return _narrow(HomeScreen(onOpenTab: (i) => _go(i == 2 ? _View.approvals : (i == 3 ? _View.money : _View.chat))));
      case _View.money:
        return _narrow(const MoneyScreen());
      case _View.approvals:
        return _narrow(const ApprovalsScreen());
      case _View.notes:
        return _narrow(const NotesScreen());
      case _View.settings:
        return _narrow(const SettingsScreen());
    }
  }
}

// ---------------------------------------------------------------- sidebar

class _Sidebar extends StatelessWidget {
  const _Sidebar({required this.view, required this.onView, required this.onToggle});
  final _View view;
  final void Function(_View) onView;
  final VoidCallback onToggle;

  @override
  Widget build(BuildContext context) {
    final agent = DesktopAgent.instance;
    final call = NeoCall.instance;
    return ClipRect(
      child: OverflowBox(
        alignment: Alignment.topLeft,
        minWidth: 268,
        maxWidth: 268,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 14, 12, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(children: [
                const SizedBox(width: 6),
                SizedBox(width: 30, height: 26, child: NeoFace(mood: agent.busy ? NeoMood.thinking : NeoMood.idle, color: neo.color)),
                const SizedBox(width: 8),
                const Text('Neo', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, letterSpacing: -0.3)),
                const Spacer(),
                IconButton(tooltip: 'Hide sidebar (Ctrl+B)', onPressed: onToggle, icon: const Icon(Icons.view_sidebar_outlined, size: 20, color: NeoColors.muted)),
              ]),
              const SizedBox(height: 12),
              _SideButton(
                icon: Icons.edit_square,
                label: 'New chat',
                hint: 'Ctrl+N',
                filled: true,
                onTap: () {
                  agent.newChat();
                  onView(_View.chat);
                },
              ),
              const SizedBox(height: 10),
              _SideItem(Icons.graphic_eq_rounded, call.active ? 'Voice · live' : 'Voice', view == _View.voice, () => onView(_View.voice),
                  dot: call.active ? NeoColors.good : null),
              _SideItem(Icons.wb_twilight_rounded, 'Today', view == _View.today, () => onView(_View.today)),
              _SideItem(Icons.account_balance_wallet_outlined, 'Money', view == _View.money, () => onView(_View.money)),
              ListenableBuilder(
                listenable: neo,
                builder: (context, _) => _SideItem(Icons.task_alt_rounded, 'Approvals', view == _View.approvals, () => onView(_View.approvals),
                    badge: neo.pendingApprovals),
              ),
              _SideItem(Icons.auto_stories_outlined, 'Notes', view == _View.notes, () => onView(_View.notes)),
              const SizedBox(height: 16),
              const Padding(
                padding: EdgeInsets.only(left: 10, bottom: 6),
                child: Text('Recent', style: TextStyle(fontSize: 12, color: NeoColors.muted, fontWeight: FontWeight.w600)),
              ),
              Expanded(
                child: agent.chats.isEmpty
                    ? const Padding(
                        padding: EdgeInsets.only(left: 10),
                        child: Text('Your chats show up here.', style: TextStyle(fontSize: 13, color: NeoColors.onInkMuted)),
                      )
                    : ListView.builder(
                        itemCount: agent.chats.length,
                        itemBuilder: (context, i) {
                          final c = agent.chats[i];
                          return _ChatItem(
                            c,
                            selected: view == _View.chat && identical(agent.current, c),
                            onTap: () {
                              agent.open(c);
                              onView(_View.chat);
                            },
                            onDelete: () => agent.delete(c),
                          );
                        },
                      ),
              ),
              const Divider(height: 16),
              _SideItem(Icons.tune_rounded, 'Settings', view == _View.settings, () => onView(_View.settings)),
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 6, 6, 0),
                child: Row(children: [
                  CircleAvatar(radius: 13, backgroundColor: neo.color, child: Text(_initial(), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: NeoColors.onInk))),
                  const SizedBox(width: 10),
                  Expanded(child: Text(supabase.auth.currentUser?.email ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, color: NeoColors.muted))),
                ]),
              ),
            ],
          ),
        ),
      ),
    );
  }

  static String _initial() {
    final e = supabase.auth.currentUser?.email ?? 'N';
    return e.isEmpty ? 'N' : e[0].toUpperCase();
  }
}

class _SideButton extends StatelessWidget {
  const _SideButton({required this.icon, required this.label, required this.onTap, this.hint, this.filled = false});
  final IconData icon;
  final String label;
  final String? hint;
  final bool filled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: filled ? NeoColors.chip : Colors.transparent,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), border: Border.all(color: NeoColors.line)),
          child: Row(children: [
            Icon(icon, size: 18),
            const SizedBox(width: 10),
            Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600))),
            if (hint != null) Text(hint!, style: const TextStyle(fontSize: 11, color: NeoColors.muted)),
          ]),
        ),
      ),
    );
  }
}

class _SideItem extends StatelessWidget {
  const _SideItem(this.icon, this.label, this.selected, this.onTap, {this.badge = 0, this.dot});
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final int badge;
  final Color? dot;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected ? NeoColors.chip : Colors.transparent,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          child: Row(children: [
            Icon(icon, size: 18, color: selected ? NeoColors.ink : NeoColors.muted),
            const SizedBox(width: 12),
            Expanded(child: Text(label, style: TextStyle(fontSize: 14, color: selected ? NeoColors.ink : NeoColors.muted, fontWeight: selected ? FontWeight.w600 : FontWeight.w500))),
            if (dot != null) Container(width: 8, height: 8, decoration: BoxDecoration(color: dot, shape: BoxShape.circle)),
            if (badge > 0) Badge(label: Text('$badge')),
          ]),
        ),
      ),
    );
  }
}

class _ChatItem extends StatefulWidget {
  const _ChatItem(this.c, {required this.selected, required this.onTap, required this.onDelete});
  final Conversation c;
  final bool selected;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  @override
  State<_ChatItem> createState() => _ChatItemState();
}

class _ChatItemState extends State<_ChatItem> {
  bool _hover = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _hover = true),
      onExit: (_) => setState(() => _hover = false),
      child: Material(
        color: widget.selected ? NeoColors.chip : (_hover ? NeoColors.card : Colors.transparent),
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: widget.onTap,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(10, 7, 4, 7),
            child: Row(children: [
              Expanded(
                child: Text(widget.c.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 13.5, color: widget.selected ? NeoColors.ink : const Color(0xFFC4C4CC))),
              ),
              SizedBox(
                width: 26,
                height: 22,
                child: _hover
                    ? IconButton(
                        padding: EdgeInsets.zero,
                        iconSize: 16,
                        tooltip: 'Delete chat',
                        onPressed: widget.onDelete,
                        icon: const Icon(Icons.delete_outline_rounded, color: NeoColors.muted),
                      )
                    : null,
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- chat

class _ChatView extends StatefulWidget {
  const _ChatView({required this.onVoice});
  final VoidCallback onVoice;

  @override
  State<_ChatView> createState() => _ChatViewState();
}

class _ChatViewState extends State<_ChatView> {
  final agent = DesktopAgent.instance;
  final _scroll = ScrollController();
  int _lastCount = 0;
  String _lastText = '';

  @override
  void initState() {
    super.initState();
    agent.addListener(_follow);
  }

  @override
  void dispose() {
    agent.removeListener(_follow);
    _scroll.dispose();
    super.dispose();
  }

  /// Keep the newest words in view while Neo is writing (unless Max scrolled up).
  void _follow() {
    final msgs = agent.current?.msgs ?? const [];
    final text = msgs.isEmpty ? '' : msgs.last.text;
    if (msgs.length == _lastCount && text == _lastText) return;
    _lastCount = msgs.length;
    _lastText = text;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scroll.hasClients) return;
      final p = _scroll.position;
      if (p.maxScrollExtent - p.pixels < 220) _scroll.jumpTo(p.maxScrollExtent);
    });
  }

  String _greeting() {
    final h = DateTime.now().hour;
    if (h < 5) return 'Still up, Max?';
    if (h < 12) return 'Good morning, Max';
    if (h < 18) return 'Good afternoon, Max';
    return 'Good evening, Max';
  }

  static const _ideas = [
    (Icons.folder_open_rounded, 'Tidy up my Downloads folder'),
    (Icons.storage_rounded, 'What is eating my disk space?'),
    (Icons.picture_as_pdf_outlined, 'Summarise the newest PDF on my Desktop'),
    (Icons.insights_rounded, 'How much did I spend this month, by category?'),
    (Icons.travel_explore_rounded, 'Find the best laptops under \$1000 right now'),
    (Icons.timer_outlined, 'Set a 25 minute focus timer'),
  ];

  @override
  Widget build(BuildContext context) {
    final c = agent.current;
    final empty = c == null || c.msgs.isEmpty;
    return Column(
      children: [
        // top bar
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 14, 0),
          child: Row(children: [
            Expanded(
              child: Text(empty ? '' : c.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, color: NeoColors.muted)),
            ),
            _QualityToggle(value: agent.quality, onChanged: agent.setQuality),
            const SizedBox(width: 8),
            Tooltip(
              message: 'Talk to Neo live',
              child: IconButton.filledTonal(onPressed: widget.onVoice, icon: const Icon(Icons.graphic_eq_rounded, size: 20)),
            ),
          ]),
        ),
        Expanded(
          child: empty
              ? Center(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 760),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        SizedBox(width: 96, height: 80, child: NeoFace(mood: NeoMood.happy, color: neo.color)),
                        const SizedBox(height: 10),
                        Text(_greeting(), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800, letterSpacing: -0.8)),
                        const SizedBox(height: 4),
                        const Text('Ask anything, or tell me what to do on this laptop.', style: TextStyle(color: NeoColors.muted)),
                        const SizedBox(height: 22),
                        const _Composer(big: true),
                        const SizedBox(height: 16),
                        Wrap(
                          alignment: WrapAlignment.center,
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            for (final (icon, idea) in _ideas)
                              ActionChip(
                                avatar: Icon(icon, size: 16, color: NeoColors.muted),
                                label: Text(idea, style: const TextStyle(fontSize: 13)),
                                onPressed: () => agent.send(idea),
                              ),
                          ],
                        ),
                      ]),
                    ),
                  ),
                )
              : ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.fromLTRB(24, 16, 24, 24),
                  itemCount: c.msgs.length,
                  itemBuilder: (context, i) => Center(
                    child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 760), child: _Message(c.msgs[i])),
                  ),
                ),
        ),
        if (!empty)
          Padding(
            padding: const EdgeInsets.fromLTRB(24, 0, 24, 6),
            child: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 760), child: const _Composer())),
          ),
        const Padding(
          padding: EdgeInsets.only(bottom: 8),
          child: Text('Neo can act on this laptop. Risky actions always ask you first.', style: TextStyle(fontSize: 11.5, color: NeoColors.onInkMuted)),
        ),
      ],
    );
  }
}

class _QualityToggle extends StatelessWidget {
  const _QualityToggle({required this.value, required this.onChanged});
  final String value;
  final void Function(String) onChanged;

  @override
  Widget build(BuildContext context) {
    return SegmentedButton<String>(
      showSelectedIcon: false,
      style: SegmentedButton.styleFrom(visualDensity: VisualDensity.compact, side: const BorderSide(color: NeoColors.line)),
      segments: const [
        ButtonSegment(value: 'fast', label: Text('Fast', style: TextStyle(fontSize: 13)), tooltip: 'Quick answers'),
        ButtonSegment(value: 'smart', label: Text('Smart', style: TextStyle(fontSize: 13)), tooltip: 'Deeper thinking for hard tasks'),
      ],
      selected: {value},
      onSelectionChanged: (s) => onChanged(s.first),
    );
  }
}

class _Message extends StatelessWidget {
  const _Message(this.m);
  final ChatMsg m;

  @override
  Widget build(BuildContext context) {
    if (m.role == 'user') {
      return Align(
        alignment: Alignment.centerRight,
        child: Container(
          margin: const EdgeInsets.only(top: 14, bottom: 6, left: 80),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
          decoration: BoxDecoration(color: NeoColors.chip, borderRadius: BorderRadius.circular(18), border: Border.all(color: NeoColors.line)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            if (m.files.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Wrap(spacing: 6, children: [
                  for (final f in m.files) Chip(avatar: const Icon(Icons.attach_file_rounded, size: 14), label: Text(f, style: const TextStyle(fontSize: 12)), visualDensity: VisualDensity.compact),
                ]),
              ),
            if (m.text.isNotEmpty) SelectableText(m.text, style: const TextStyle(fontSize: 15, height: 1.5)),
          ]),
        ),
      );
    }
    return Padding(
      padding: const EdgeInsets.only(top: 12, bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 2),
            child: SizedBox(width: 28, height: 24, child: NeoFace(mood: m.streaming ? NeoMood.thinking : NeoMood.idle, color: neo.color)),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (m.steps.isNotEmpty) _Steps(m.steps),
                if (m.text.isNotEmpty) NeoMarkdown(m.text, color: m.error ? NeoColors.danger : NeoColors.ink),
                if (m.streaming && m.text.isEmpty && m.steps.every((s) => s.status != 'running'))
                  const Padding(padding: EdgeInsets.only(top: 4), child: _Dots()),
                if (!m.streaming && m.text.isNotEmpty) _Actions(m),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Steps extends StatefulWidget {
  const _Steps(this.steps);
  final List<ToolStep> steps;

  @override
  State<_Steps> createState() => _StepsState();
}

class _StepsState extends State<_Steps> {
  bool _open = false;

  @override
  Widget build(BuildContext context) {
    final running = widget.steps.where((s) => s.status == 'running').length;
    final shown = _open ? widget.steps : widget.steps.reversed.take(3).toList().reversed.toList();
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), border: Border.all(color: NeoColors.line), color: NeoColors.card),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            onTap: () => setState(() => _open = !_open),
            child: Row(children: [
              Icon(running > 0 ? Icons.autorenew_rounded : Icons.bolt_rounded, size: 15, color: neo.color),
              const SizedBox(width: 8),
              Text(running > 0 ? 'Working…' : '${widget.steps.length} step${widget.steps.length == 1 ? '' : 's'}',
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
              const Spacer(),
              if (widget.steps.length > 3) Icon(_open ? Icons.expand_less_rounded : Icons.expand_more_rounded, size: 18, color: NeoColors.muted),
            ]),
          ),
          for (final s in shown)
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: Row(children: [
                SizedBox(
                  width: 15,
                  height: 15,
                  child: switch (s.status) {
                    'running' => const CircularProgressIndicator(strokeWidth: 1.6),
                    'declined' => const Icon(Icons.block_rounded, size: 15, color: NeoColors.muted),
                    'error' => const Icon(Icons.error_outline_rounded, size: 15, color: NeoColors.danger),
                    _ => const Icon(Icons.check_rounded, size: 15, color: NeoColors.good),
                  },
                ),
                const SizedBox(width: 8),
                Expanded(child: Text(s.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.5, color: NeoColors.muted, fontFamily: 'Consolas'))),
              ]),
            ),
        ],
      ),
    );
  }
}

class _Actions extends StatelessWidget {
  const _Actions(this.m);
  final ChatMsg m;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: Row(children: [
        IconButton(
          tooltip: 'Copy',
          iconSize: 16,
          visualDensity: VisualDensity.compact,
          onPressed: () => Clipboard.setData(ClipboardData(text: m.text)),
          icon: const Icon(Icons.copy_rounded, color: NeoColors.muted),
        ),
        IconButton(
          tooltip: 'Read aloud',
          iconSize: 16,
          visualDensity: VisualDensity.compact,
          onPressed: () => neo.say(m.text),
          icon: const Icon(Icons.volume_up_outlined, color: NeoColors.muted),
        ),
        const SizedBox(width: 6),
        Text(DateFormat('HH:mm').format(m.ts), style: const TextStyle(fontSize: 11, color: NeoColors.onInkMuted)),
      ]),
    );
  }
}

class _Dots extends StatefulWidget {
  const _Dots();

  @override
  State<_Dots> createState() => _DotsState();
}

class _DotsState extends State<_Dots> with SingleTickerProviderStateMixin {
  late final AnimationController _a = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))..repeat();

  @override
  void dispose() {
    _a.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _a,
      builder: (context, _) => Row(children: [
        for (var i = 0; i < 3; i++)
          Container(
            margin: const EdgeInsets.only(right: 5),
            width: 7,
            height: 7,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: NeoColors.muted.withValues(alpha: 0.3 + 0.7 * (((_a.value * 3 - i) % 3) < 1 ? 1 : 0)),
            ),
          ),
      ]),
    );
  }
}

// ---------------------------------------------------------------- composer

class _Composer extends StatefulWidget {
  const _Composer({this.big = false});
  final bool big;

  @override
  State<_Composer> createState() => _ComposerState();
}

class _ComposerState extends State<_Composer> {
  final agent = DesktopAgent.instance;
  final _text = TextEditingController();
  final _focus = FocusNode();
  final _files = <Attachment>[];

  @override
  void initState() {
    super.initState();
    agent.addListener(_changed);
    _text.addListener(_changed);
    _focus.onKeyEvent = (node, e) {
      if (e is KeyDownEvent && e.logicalKey == LogicalKeyboardKey.enter && !HardwareKeyboard.instance.isShiftPressed) {
        _send();
        return KeyEventResult.handled;
      }
      return KeyEventResult.ignored;
    };
    WidgetsBinding.instance.addPostFrameCallback((_) => _focus.requestFocus());
  }

  @override
  void dispose() {
    agent.removeListener(_changed);
    _text.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _changed() {
    if (mounted) setState(() {});
  }

  void _send() {
    if (agent.busy) return;
    final t = _text.text;
    if (t.trim().isEmpty && _files.isEmpty) return;
    final files = List<Attachment>.from(_files);
    _text.clear();
    setState(_files.clear);
    agent.send(t, files: files);
  }

  Future<void> _attach() async {
    final picked = await openFiles();
    if (picked.isEmpty) return;
    setState(() => _files.addAll(picked.map((x) => Attachment(x.path))));
    _focus.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    final busy = agent.busy;
    final canSend = _text.text.trim().isNotEmpty || _files.isNotEmpty;
    return Container(
      decoration: BoxDecoration(
        color: NeoColors.card,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: _focus.hasFocus ? const Color(0xFF3A3A44) : NeoColors.line),
        boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 24, offset: Offset(0, 8))],
      ),
      padding: const EdgeInsets.fromLTRB(14, 10, 10, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (_files.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Wrap(spacing: 6, runSpacing: 6, children: [
                for (final f in _files)
                  InputChip(
                    avatar: const Icon(Icons.description_outlined, size: 16),
                    label: Text(f.name, style: const TextStyle(fontSize: 12)),
                    onDeleted: () => setState(() => _files.remove(f)),
                    visualDensity: VisualDensity.compact,
                  ),
              ]),
            ),
          TextField(
            controller: _text,
            focusNode: _focus,
            minLines: widget.big ? 2 : 1,
            maxLines: 10,
            style: const TextStyle(fontSize: 15, height: 1.45),
            decoration: const InputDecoration(
              hintText: 'Message Neo…',
              filled: false,
              border: InputBorder.none,
              isDense: true,
              contentPadding: EdgeInsets.symmetric(vertical: 6),
            ),
          ),
          const SizedBox(height: 6),
          Row(children: [
            IconButton(tooltip: 'Attach files', onPressed: busy ? null : _attach, icon: const Icon(Icons.add_circle_outline_rounded, size: 20, color: NeoColors.muted)),
            IconButton(
              tooltip: 'Show Neo my screen',
              onPressed: busy ? null : () => agent.send('Look at my screen (use look_at_screen) and tell me what you see.'),
              icon: const Icon(Icons.screenshot_monitor_rounded, size: 20, color: NeoColors.muted),
            ),
            const Spacer(),
            Text(agent.quality == 'smart' ? 'Smart' : 'Fast', style: const TextStyle(fontSize: 12, color: NeoColors.muted)),
            const SizedBox(width: 10),
            busy
                ? IconButton.filled(tooltip: 'Stop', onPressed: agent.stop, icon: const Icon(Icons.stop_rounded, size: 20))
                : IconButton.filled(
                    tooltip: 'Send (Enter)',
                    onPressed: canSend ? _send : null,
                    style: IconButton.styleFrom(backgroundColor: canSend ? NeoColors.ink : NeoColors.chip),
                    icon: Icon(Icons.arrow_upward_rounded, size: 20, color: canSend ? NeoColors.onInk : NeoColors.muted),
                  ),
          ]),
        ],
      ),
    );
  }
}
