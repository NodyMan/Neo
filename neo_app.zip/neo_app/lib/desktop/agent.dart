import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';

import '../config.dart';
import '../neo/about_neo.dart';
import '../neo/agent_tools.dart';
import '../widgets/live.dart';

/// One step Neo took with a tool while answering.
class ToolStep {
  ToolStep(this.name, this.args, {this.status = 'running', this.result});
  final String name;
  final Map<String, dynamic> args;
  String status; // running | done | declined | error
  Map<String, dynamic>? result;

  String get label {
    final a = (args['path'] ?? args['query'] ?? args['name'] ?? args['url'] ?? args['request'] ?? args['action'] ?? args['key'] ?? args['from'] ?? '').toString();
    return a.isEmpty ? name.replaceAll('_', ' ') : '${name.replaceAll('_', ' ')} · ${a.length > 60 ? '${a.substring(0, 60)}…' : a}';
  }

  Map<String, dynamic> toJson() => {'name': name, 'args': args, 'status': status};
  static ToolStep fromJson(Map<String, dynamic> j) =>
      ToolStep(j['name'] as String, Map<String, dynamic>.from(j['args'] as Map? ?? {}), status: (j['status'] ?? 'done') as String);
}

class ChatMsg {
  ChatMsg(this.role, this.text, {List<ToolStep>? steps, List<String>? files, this.error = false, DateTime? ts})
      : steps = steps ?? [],
        files = files ?? [],
        ts = ts ?? DateTime.now();
  final String role; // user | neo
  String text;
  final List<ToolStep> steps;
  final List<String> files; // attachment names
  bool error;
  bool streaming = false;
  final DateTime ts;

  Map<String, dynamic> toJson() => {
        'role': role,
        'text': text,
        'steps': steps.map((s) => s.toJson()).toList(),
        'files': files,
        'error': error,
        'ts': ts.toIso8601String(),
      };
  static ChatMsg fromJson(Map<String, dynamic> j) => ChatMsg(
        j['role'] as String,
        (j['text'] ?? '') as String,
        steps: (j['steps'] as List? ?? []).map((e) => ToolStep.fromJson(Map<String, dynamic>.from(e as Map))).toList(),
        files: (j['files'] as List? ?? []).map((e) => '$e').toList(),
        error: j['error'] == true,
        ts: DateTime.tryParse('${j['ts']}'),
      );
}

class Conversation {
  Conversation(this.id, {this.title = 'New chat', DateTime? updated, List<Map<String, dynamic>>? contents, List<ChatMsg>? msgs})
      : updated = updated ?? DateTime.now(),
        contents = contents ?? [],
        msgs = msgs ?? [];
  final String id;
  String title;
  DateTime updated;
  final List<Map<String, dynamic>> contents; // Gemini history (with thought signatures)
  final List<ChatMsg> msgs; // what the screen shows

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'updated': updated.toIso8601String(),
        'contents': contents,
        'msgs': msgs.map((m) => m.toJson()).toList(),
      };
  static Conversation fromJson(Map<String, dynamic> j) => Conversation(
        j['id'] as String,
        title: (j['title'] ?? 'Chat') as String,
        updated: DateTime.tryParse('${j['updated']}'),
        contents: (j['contents'] as List? ?? []).map((e) => Map<String, dynamic>.from(e as Map)).toList(),
        msgs: (j['msgs'] as List? ?? []).map((e) => ChatMsg.fromJson(Map<String, dynamic>.from(e as Map))).toList(),
      );
}

/// A file the user attached to a message.
class Attachment {
  Attachment(this.path) : name = path.split(RegExp(r'[\\/]')).last;
  final String path;
  final String name;
}

/// Neo's desktop brain: a chat agent (Gemini through the neo-chat edge function) that can use
/// the laptop's tools — files, apps, power, screen, search — and shows every step it takes.
class DesktopAgent extends ChangeNotifier {
  DesktopAgent._();
  static final DesktopAgent instance = DesktopAgent._();

  final chats = <Conversation>[];
  Conversation? current;
  bool busy = false;
  String quality = 'fast'; // fast | smart
  bool _stop = false;
  http.Client? _client;

  // ---- storage (one JSON file per chat, on this PC) ----

  Future<Directory> _dir() async {
    final d = Directory('${(await getApplicationSupportDirectory()).path}${Platform.pathSeparator}chats');
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  Future<void> load() async {
    try {
      final d = await _dir();
      final list = <Conversation>[];
      await for (final f in d.list()) {
        if (f is File && f.path.endsWith('.json')) {
          try {
            list.add(Conversation.fromJson(jsonDecode(await f.readAsString()) as Map<String, dynamic>));
          } catch (_) {}
        }
      }
      list.sort((a, b) => b.updated.compareTo(a.updated));
      chats
        ..clear()
        ..addAll(list);
    } catch (_) {}
    notifyListeners();
  }

  Future<void> _save(Conversation c) async {
    try {
      final f = File('${(await _dir()).path}${Platform.pathSeparator}${c.id}.json');
      await f.writeAsString(jsonEncode(c.toJson()));
    } catch (_) {}
  }

  void newChat() {
    if (busy) return;
    current = null;
    notifyListeners();
  }

  void open(Conversation c) {
    if (busy) return;
    current = c;
    notifyListeners();
  }

  Future<void> delete(Conversation c) async {
    chats.remove(c);
    if (identical(current, c)) current = null;
    notifyListeners();
    try {
      await File('${(await _dir()).path}${Platform.pathSeparator}${c.id}.json').delete();
    } catch (_) {}
  }

  void setQuality(String q) {
    quality = q;
    notifyListeners();
  }

  void stop() {
    _stop = true;
    _client?.close();
  }

  // ---- talking ----

  /// Sends a message and returns Neo's final answer. [into] sends it to that chat instead of
  /// the one on screen (used for orders that come from the phone).
  Future<String> send(String text, {List<Attachment> files = const [], Conversation? into}) async {
    final t = text.trim();
    if ((t.isEmpty && files.isEmpty) || busy) return '';
    var c = into ?? current;
    if (c == null) {
      c = Conversation('${DateTime.now().millisecondsSinceEpoch}', title: _titleFrom(t.isEmpty ? files.first.name : t));
      chats.insert(0, c);
      current = c;
    } else if (into != null && !chats.contains(into)) {
      chats.insert(0, into);
    }
    busy = true;
    _stop = false;
    c.msgs.add(ChatMsg('user', t, files: files.map((f) => f.name).toList()));
    final reply = ChatMsg('neo', '')..streaming = true;
    c.msgs.add(reply);
    c.updated = DateTime.now();
    chats
      ..remove(c)
      ..insert(0, c);
    notifyListeners();

    c.contents.add({
      'role': 'user',
      'parts': [
        if (t.isNotEmpty) {'text': t},
        ...await _fileParts(files),
      ],
    });

    try {
      for (var round = 0; round < 14 && !_stop; round++) {
        final parts = await _stream(c, reply);
        if (parts.isEmpty) break;
        c.contents.add({'role': 'model', 'parts': parts});
        final calls = parts.where((p) => p['functionCall'] is Map).map((p) => Map<String, dynamic>.from(p['functionCall'] as Map)).toList();
        if (calls.isEmpty || _stop) break;
        final responses = <Map<String, dynamic>>[];
        for (final call in calls) {
          final name = '${call['name']}';
          final args = call['args'] is Map ? Map<String, dynamic>.from(call['args'] as Map) : <String, dynamic>{};
          final step = ToolStep(name, args);
          reply.steps.add(step);
          notifyListeners();
          final result = await AgentTools.run(name, args);
          step.status = result['declined'] == true ? 'declined' : (result['error'] != null ? 'error' : 'done');
          step.result = result;
          notifyListeners();
          responses.add({
            'functionResponse': {
              'name': name,
              if (call['id'] != null) 'id': call['id'],
              'response': _trim(result),
            }
          });
        }
        c.contents.add({'role': 'user', 'parts': responses});
        if (reply.text.isNotEmpty && !reply.text.endsWith('\n')) reply.text += '\n\n';
      }
      if (reply.text.trim().isEmpty && reply.steps.isNotEmpty) reply.text = 'Done.';
      if (_stop && reply.text.trim().isEmpty) reply.text = '_Stopped._';
    } catch (e) {
      if (_stop) {
        if (reply.text.trim().isEmpty) reply.text = '_Stopped._';
      } else {
        reply.error = true;
        reply.text = (reply.text.isEmpty ? '' : '${reply.text}\n\n') + _friendly(e);
      }
      // Drop a half-finished turn so the next message starts clean.
      while (c.contents.isNotEmpty && c.contents.last['role'] == 'model') {
        c.contents.removeLast();
      }
    } finally {
      reply.streaming = false;
      busy = false;
      _client = null;
      c.updated = DateTime.now();
      notifyListeners();
      await _save(c);
    }
    return reply.text;
  }

  /// Orders from the phone's PC tab ("Ask Neo on this PC") go to their own chat.
  Future<String> askFromPhone(String text) async {
    final c = chats.where((x) => x.id == 'phone').firstOrNull ?? Conversation('phone', title: '📱 From your phone');
    if (busy) return 'Neo is busy on the laptop right now. Try again in a moment.';
    return send(text, into: c);
  }

  /// One streamed model turn. Text shows up in [reply] as it arrives; returns the model's parts.
  Future<List<Map<String, dynamic>>> _stream(Conversation c, ChatMsg reply) async {
    final jwt = await freshToken();
    if (jwt == null) throw 'Sign in first.';
    final req = http.Request('POST', Uri.parse('$supabaseUrl/functions/v1/neo-chat'))
      ..headers.addAll({'Authorization': 'Bearer $jwt', 'apikey': supabasePublishableKey, 'Content-Type': 'application/json'})
      ..body = jsonEncode({
        'mode': 'chat',
        'quality': quality,
        'contents': c.contents,
        'systemInstruction': {
          'parts': [
            {'text': _instructions()}
          ]
        },
        'tools': [
          {'functionDeclarations': AgentTools.declarations(chat: true)}
        ],
      });
    final client = _client = http.Client();
    final res = await client.send(req).timeout(const Duration(seconds: 60));
    if (res.statusCode != 200) {
      final body = await res.stream.bytesToString();
      String msg;
      try {
        msg = '${(jsonDecode(body) as Map)['error']}';
      } catch (_) {
        msg = 'error ${res.statusCode}';
      }
      throw msg;
    }
    final parts = <Map<String, dynamic>>[];
    await for (final line in res.stream.transform(utf8.decoder).transform(const LineSplitter())) {
      if (_stop) break;
      if (!line.startsWith('data:')) continue;
      final data = line.substring(5).trim();
      if (data.isEmpty || data == '[DONE]') continue;
      Map<String, dynamic> chunk;
      try {
        chunk = jsonDecode(data) as Map<String, dynamic>;
      } catch (_) {
        continue;
      }
      final cands = chunk['candidates'];
      if (cands is! List || cands.isEmpty) continue;
      final content = (cands.first as Map)['content'];
      final ps = content is Map ? content['parts'] : null;
      if (ps is! List) continue;
      for (final raw in ps) {
        final p = Map<String, dynamic>.from(raw as Map);
        final isText = p['text'] is String && p['functionCall'] == null;
        if (isText && p['thought'] != true) {
          reply.text += p['text'] as String;
          notifyListeners();
        }
        // Merge consecutive plain text pieces into one part; keep everything else (calls, signatures) as sent.
        if (isText && parts.isNotEmpty && parts.last['text'] is String && parts.last['functionCall'] == null && parts.last['thought'] == p['thought']) {
          parts.last['text'] = (parts.last['text'] as String) + (p['text'] as String);
          if (p['thoughtSignature'] != null) parts.last['thoughtSignature'] = p['thoughtSignature'];
        } else {
          parts.add(p);
        }
      }
    }
    return parts;
  }

  static Future<List<Map<String, dynamic>>> _fileParts(List<Attachment> files) async {
    final out = <Map<String, dynamic>>[];
    for (final a in files) {
      final f = File(a.path);
      try {
        final ext = a.name.split('.').last.toLowerCase();
        final size = await f.length();
        const images = {'png': 'image/png', 'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'webp': 'image/webp', 'gif': 'image/gif'};
        if ((images.containsKey(ext) || ext == 'pdf') && size < 15 << 20) {
          out.add({'text': 'Attached file: ${a.path}'});
          out.add({
            'inlineData': {'mimeType': images[ext] ?? 'application/pdf', 'data': base64Encode(await f.readAsBytes())}
          });
        } else {
          final r = await AgentTools.run('read_file', {'path': a.path});
          final body = r['text'] ?? r['error'] ?? '';
          out.add({'text': 'Attached file: ${a.path}\n```\n$body\n```'});
        }
      } catch (e) {
        out.add({'text': 'Attached file ${a.path} could not be read: $e'});
      }
    }
    return out;
  }

  static Map<String, dynamic> _trim(Map<String, dynamic> r) {
    final s = jsonEncode(r);
    return s.length < 40000 ? r : {'result_truncated': s.substring(0, 40000)};
  }

  static String _titleFrom(String t) {
    final one = t.replaceAll(RegExp(r'\s+'), ' ').trim();
    return one.length <= 42 ? one : '${one.substring(0, math.min(42, one.length))}…';
  }

  static String _instructions() {
    final now = DateFormat('EEEE d MMMM yyyy, HH:mm').format(DateTime.now());
    return '''
You are Neo, Max's personal AI agent, in the Neo desktop app on ${deviceDescription()}. Now: $now (Tashkent).

You work like a top AI assistant (think ChatGPT / Claude / Gemini) that can also act on this laptop.
- Reply in the language Max writes in (Russian, Uzbek or English). You are male.
- Be direct. Lead with the answer. Use Markdown: short headings, bullet lists, tables when they help, and fenced code blocks with a language for code.
- Use tools whenever they help, without asking for normal things: search and read files, list folders, open apps and sites, timers, system info, web_search for fresh facts.
- Risky tools (delete, move, overwrite, close apps, shut down, restart, sleep) show Max a confirm button by themselves; just call them. If the result says declined, accept it.
- For Max's own life (money and spending analytics, tasks, reminders, notes, things to remember) use ask_neo_memory, also to save new reminders and notes.
- For analysis of files (CSV, spreadsheets, logs, documents), read them first, then give numbers, totals and clear conclusions.
- When you changed something on the laptop, end with one short line saying what you did.

$aboutNeo''';
  }

  static String _friendly(Object e) {
    if (e is SocketException || e is TimeoutException || e is http.ClientException) return '⚠️ No connection to Neo. Check the internet.';
    final s = '$e';
    if (s.contains('GEMINI_API_KEY')) return '⚠️ Neo\'s brain is not set up yet: add GEMINI_API_KEY in Supabase → Edge Functions → Secrets.';
    return '⚠️ $s';
  }
}
