import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../neo/neo_brain.dart';
import '../theme.dart';
import 'categories.dart';

/// Bottom sheet to add a transaction by hand. Returns true when saved.
Future<bool?> showAddTransaction(BuildContext context) {
  return showModalBottomSheet<bool>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    backgroundColor: NeoColors.ground,
    builder: (_) => const _AddTransactionSheet(),
  );
}

class _AddTransactionSheet extends StatefulWidget {
  const _AddTransactionSheet();

  @override
  State<_AddTransactionSheet> createState() => _AddTransactionSheetState();
}

class _AddTransactionSheetState extends State<_AddTransactionSheet> {
  final _amount = TextEditingController();
  final _merchant = TextEditingController();
  bool _income = false;
  String _category = 'Food';
  String _currency = 'UZS';
  DateTime _when = DateTime.now();
  bool _saving = false;
  String? _error;

  List<Cat> get _cats => _income ? incomeCats : spendCats;

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _when,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now(),
    );
    if (d == null || !mounted) return;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_when));
    setState(() => _when = DateTime(d.year, d.month, d.day, t?.hour ?? _when.hour, t?.minute ?? _when.minute));
  }

  Future<void> _save() async {
    final amount = double.tryParse(_amount.text.replaceAll(RegExp(r'[^0-9.]'), ''));
    if (amount == null || amount <= 0) {
      setState(() => _error = 'Enter an amount');
      return;
    }
    setState(() {
      _saving = true;
      _error = null;
    });
    try {
      await supabase.rpc('neo_add_transaction', params: {
        'p_amount': amount,
        'p_category': _category,
        'p_merchant': _merchant.text.trim(),
        'p_direction': _income ? 'credit' : 'debit',
        'p_type': _income ? 'topup' : 'purchase',
        'p_currency': _currency,
        'p_ts': _when.toUtc().toIso8601String(),
        'p_source': 'app',
      });
      if (mounted) Navigator.of(context).pop(true);
    } catch (e) {
      setState(() {
        _saving = false;
        _error = 'Not saved: $e';
      });
    }
  }

  @override
  void dispose() {
    _amount.dispose();
    _merchant.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 0, 20, 20 + bottom),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Add transaction', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 16),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, label: Text('Spent'), icon: Icon(Icons.arrow_upward_rounded)),
                ButtonSegment(value: true, label: Text('Received'), icon: Icon(Icons.arrow_downward_rounded)),
              ],
              selected: {_income},
              onSelectionChanged: (s) => setState(() {
                _income = s.first;
                _category = _cats.first.name;
              }),
              style: SegmentedButton.styleFrom(
                selectedBackgroundColor: NeoColors.ink,
                selectedForegroundColor: NeoColors.onInk,
                backgroundColor: NeoColors.card,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _amount,
                    autofocus: true,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9 .]'))],
                    style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800),
                    decoration: const InputDecoration(hintText: '0', labelText: 'Amount'),
                  ),
                ),
                const SizedBox(width: 10),
                DropdownButton<String>(
                  value: _currency,
                  underline: const SizedBox.shrink(),
                  items: const [
                    DropdownMenuItem(value: 'UZS', child: Text('UZS')),
                    DropdownMenuItem(value: 'USD', child: Text('USD')),
                    DropdownMenuItem(value: 'EUR', child: Text('EUR')),
                    DropdownMenuItem(value: 'RUB', child: Text('RUB')),
                  ],
                  onChanged: (v) => setState(() => _currency = v ?? 'UZS'),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Text('Category', style: TextStyle(fontWeight: FontWeight.w700, color: NeoColors.muted)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final c in _cats)
                  ChoiceChip(
                    avatar: Icon(c.icon, size: 18, color: _category == c.name ? NeoColors.onInk : NeoColors.ink),
                    label: Text(c.name),
                    selected: _category == c.name,
                    showCheckmark: false,
                    selectedColor: NeoColors.ink,
                    backgroundColor: NeoColors.card,
                    side: const BorderSide(color: NeoColors.line),
                    labelStyle: TextStyle(color: _category == c.name ? NeoColors.onInk : NeoColors.ink, fontWeight: FontWeight.w600),
                    onSelected: (_) => setState(() => _category = c.name),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _merchant,
              textCapitalization: TextCapitalization.words,
              decoration: InputDecoration(labelText: _income ? 'From (optional)' : 'Where / to whom (optional)'),
            ),
            const SizedBox(height: 12),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.event_rounded),
              title: Text(DateFormat('EEE d MMM, HH:mm').format(_when)),
              trailing: const Text('Change', style: TextStyle(fontWeight: FontWeight.w700)),
              onTap: _pickDate,
            ),
            if (_error != null) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(_error!, style: const TextStyle(color: NeoColors.danger))),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: FilledButton(
                style: FilledButton.styleFrom(backgroundColor: NeoColors.ink, shape: const StadiumBorder()),
                onPressed: _saving ? null : _save,
                child: _saving
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: NeoColors.onInk))
                    : const Text('Save', style: TextStyle(fontWeight: FontWeight.w700)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Edit category or delete an existing transaction. Returns true if changed.
Future<bool?> showEditTransaction(BuildContext context, Map<String, dynamic> row) {
  return showModalBottomSheet<bool>(
    context: context,
    showDragHandle: true,
    backgroundColor: NeoColors.ground,
    builder: (c) {
      final income = row['direction'] == 'credit';
      final cats = income ? incomeCats : spendCats;
      return SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('${income ? '+' : '−'}${formatSum((row['amount'] as num?) ?? 0)} ${row['currency'] ?? 'UZS'}',
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
              Text(row['merchant_norm']?.toString() ?? row['merchant_raw']?.toString() ?? '', style: const TextStyle(color: NeoColors.muted)),
              const SizedBox(height: 16),
              const Text('Change category', style: TextStyle(fontWeight: FontWeight.w700, color: NeoColors.muted)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final cat in cats)
                    ActionChip(
                      avatar: Icon(cat.icon, size: 18),
                      label: Text(cat.name),
                      backgroundColor: row['category'] == cat.name ? cat.color : NeoColors.card,
                      side: const BorderSide(color: NeoColors.line),
                      onPressed: () async {
                        await supabase.from('transactions').update({'category': cat.name}).eq('id', row['id']);
                        final m = row['merchant_norm'];
                        if (m != null && m.toString().isNotEmpty) {
                          await supabase.from('merchant_categories').upsert({'merchant_norm': m, 'category': cat.name, 'learned_from_user': true});
                        }
                        if (c.mounted) Navigator.of(c).pop(true);
                      },
                    ),
                ],
              ),
              const SizedBox(height: 16),
              TextButton.icon(
                style: TextButton.styleFrom(foregroundColor: NeoColors.danger),
                onPressed: () async {
                  await supabase.from('transactions').delete().eq('id', row['id']);
                  if (c.mounted) Navigator.of(c).pop(true);
                },
                icon: const Icon(Icons.delete_outline_rounded),
                label: const Text('Delete transaction'),
              ),
            ],
          ),
        ),
      );
    },
  );
}
