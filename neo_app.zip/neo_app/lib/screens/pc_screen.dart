import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../neo/neo_brain.dart';
import '../theme.dart';

/// Control a PC running "Neo for PC" (signed in to the same account): see its screen,
/// tap to click, type, press keys, and ask Neo to do things on it.
/// Phone and PC meet on the private Realtime channel "neo-remote:<user id>".
class PcScreen extends StatefulWidget {
  const PcScreen({super.key, required this.active});

  /// Only stream the PC's screen while this tab is on screen.
  final bool active;

  @override
  State<PcScreen> createState() => _PcScreenState();
}

class _PcInfo {
  _PcInfo(this.id, this.name, this.os);
  final String id;
  final String name;
  final String os;
}

class _PcScreenState extends State<PcScreen> {
  static final _phoneId = 'phone-${math.Random().nextInt(1 << 32).toRadixString(16)}';

  RealtimeChannel? _ch;
  String _status = 'connecting'; // connecting | online | error
  List<_PcInfo> _pcs = [];
  String? _pcId;
  Uint8List? _frame;
  double _aspect = 16 / 9;
  DateTime _lastFrame = DateTime.fromMillisecondsSinceEpoch(0);
  Timer? _watchTimer;
  bool _dragMode = false;
  bool _askBusy = false;
  String? _askReply;
  final _typeCtl = TextEditingController();
  final _askCtl = TextEditingController();
  final _zoom = TransformationController();

  _PcInfo? get _pc => _pcs.where((p) => p.id == _pcId).firstOrNull;

  bool _zoomed = false;

  @override
  void initState() {
    super.initState();
    // While zoomed in, one-finger moves pan the PC screen instead of scrolling this page.
    _zoom.addListener(() {
      final z = _zoom.value.getMaxScaleOnAxis() > 1.01;
      if (z != _zoomed) setState(() => _zoomed = z);
    });
    if (widget.active) _connect();
  }

  @override
  void didUpdateWidget(PcScreen old) {
    super.didUpdateWidget(old);
    if (widget.active && !old.active) {
      _ch == null ? _connect() : _startWatching();
    } else if (!widget.active && old.active) {
      _stopWatching();
    }
  }

  @override
  void dispose() {
    _stopWatching();
    final ch = _ch;
    if (ch != null) supabase.removeChannel(ch);
    _typeCtl.dispose();
    _askCtl.dispose();
    _zoom.dispose();
    super.dispose();
  }

  // ---- connection ----

  void _connect() {
    final uid = supabase.auth.currentUser?.id;
    if (uid == null) return;
    final ch = supabase.channel('neo-remote:$uid', opts: RealtimeChannelConfig(self: false, private: true, key: _phoneId));
    ch.onPresenceSync((_) => _readPresence());
    ch.onBroadcast(event: 'frame', callback: (raw) => _onFrame(_unwrap(raw)));
    ch.onBroadcast(event: 'pc', callback: (raw) => _onPcMessage(_unwrap(raw)));
    ch.subscribe((status, error) async {
      if (!mounted) return;
      if (status == RealtimeSubscribeStatus.subscribed) {
        setState(() => _status = 'online');
        await ch.track({'kind': 'phone', 'id': _phoneId});
        _startWatching();
      } else if (status == RealtimeSubscribeStatus.channelError || status == RealtimeSubscribeStatus.timedOut) {
        setState(() => _status = 'error');
      }
    });
    _ch = ch;
  }

  /// Broadcast callbacks may hand over the whole message or only its payload.
  static Map<String, dynamic> _unwrap(Map<String, dynamic> raw) {
    if (raw.containsKey('from')) return raw;
    final p = raw['payload'];
    return p is Map ? Map<String, dynamic>.from(p) : raw;
  }

  void _readPresence() {
    final ch = _ch;
    if (ch == null || !mounted) return;
    final pcs = <_PcInfo>[];
    for (final s in ch.presenceState()) {
      for (final p in s.presences) {
        final m = p.payload;
        if (m['kind'] == 'pc') pcs.add(_PcInfo('${m['id']}', '${m['name'] ?? 'PC'}', '${m['os'] ?? ''}'));
      }
    }
    setState(() {
      _pcs = pcs;
      if (_pcId == null || !pcs.any((p) => p.id == _pcId)) {
        _pcId = pcs.isEmpty ? null : pcs.first.id;
        _frame = null;
      }
    });
    _startWatching();
  }

  void _onFrame(Map<String, dynamic> m) {
    if (!mounted || m['from'] != _pcId) return;
    final img = m['img'];
    if (img is! String) return;
    final w = (m['w'] as num?)?.toDouble() ?? 16;
    final h = (m['h'] as num?)?.toDouble() ?? 9;
    setState(() {
      _frame = base64Decode(img);
      _aspect = w / h;
      _lastFrame = DateTime.now();
    });
  }

  void _onPcMessage(Map<String, dynamic> m) {
    if (!mounted || m['from'] != _pcId || (m['to'] != null && m['to'] != _phoneId)) return;
    if (m['kind'] == 'busy') setState(() => _askBusy = true);
    if (m['kind'] == 'reply' || m['kind'] == 'error') {
      setState(() {
        _askBusy = false;
        _askReply = '${m['text'] ?? ''}'.trim().isEmpty ? 'Done.' : '${m['text']}';
      });
    }
  }

  void _send(String op, [Map<String, dynamic> extra = const {}]) {
    final id = _pcId;
    if (id == null) return;
    _ch?.sendBroadcastMessage(event: 'cmd', payload: {'to': id, 'from': _phoneId, 'op': op, ...extra});
  }

  // The PC only streams while it hears "watch" at least every 12 s.
  void _startWatching() {
    if (!widget.active || _pcId == null || _status != 'online') return;
    _send('watch');
    _watchTimer?.cancel();
    _watchTimer = Timer.periodic(const Duration(seconds: 5), (_) => _send('watch'));
  }

  void _stopWatching() {
    _watchTimer?.cancel();
    _watchTimer = null;
    _send('unwatch');
  }

  // ---- input ----

  Offset _norm(Offset local, Size size) =>
      Offset((local.dx / size.width).clamp(0.0, 1.0), (local.dy / size.height).clamp(0.0, 1.0));

  Map<String, dynamic> _xy(Offset p) => {'x': p.dx, 'y': p.dy};

  void _typeSend({bool enter = false}) {
    final t = _typeCtl.text;
    if (t.isNotEmpty) _send('type', {'text': t});
    if (enter) _send('key', {'key': 'enter'});
    _typeCtl.clear();
  }

  void _ask() {
    final t = _askCtl.text.trim();
    if (t.isEmpty) return;
    setState(() {
      _askBusy = true;
      _askReply = null;
    });
    _send('ask', {'text': t});
    _askCtl.clear();
    FocusScope.of(context).unfocus();
  }

  // ---- UI ----

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context).textTheme;
    return ListView(
      physics: _dragMode || _zoomed ? const NeverScrollableScrollPhysics() : null,
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Text('PC', style: t.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(4, 0, 4, 12),
          child: Text('Control your computer. Install "Neo for PC" and sign in with this account.',
              style: TextStyle(color: NeoColors.muted)),
        ),
        _pcPicker(),
        const SizedBox(height: 12),
        if (_pc != null) ...[
          _screenView(),
          const SizedBox(height: 10),
          _keysRow(),
          const SizedBox(height: 10),
          _typeBox(),
          const SizedBox(height: 12),
          _askCard(),
        ],
      ],
    );
  }

  Widget _card({required Widget child, EdgeInsets padding = const EdgeInsets.all(16)}) => Container(
        padding: padding,
        decoration: BoxDecoration(color: NeoColors.card, borderRadius: BorderRadius.circular(24)),
        child: child,
      );

  Widget _pcPicker() {
    if (_status == 'error') {
      return _card(
        child: Row(children: [
          const Icon(Icons.error_outline, color: NeoColors.danger),
          const SizedBox(width: 12),
          const Expanded(child: Text('Could not connect to your PCs.')),
          TextButton(
            onPressed: () {
              final ch = _ch;
              if (ch != null) supabase.removeChannel(ch);
              _ch = null;
              setState(() => _status = 'connecting');
              _connect();
            },
            child: const Text('Retry'),
          ),
        ]),
      );
    }
    if (_pcs.isEmpty) {
      return _card(
        child: Row(children: [
          _status == 'connecting'
              ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.desktop_windows_outlined, color: NeoColors.muted),
          const SizedBox(width: 12),
          Expanded(
            child: Text(_status == 'connecting'
                ? 'Looking for your PCs…'
                : 'No PC online. Open Neo on your computer and turn on "Phone remote".'),
          ),
        ]),
      );
    }
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final p in _pcs)
          ChoiceChip(
            avatar: const Icon(Icons.desktop_windows_outlined, size: 18),
            label: Text(p.name),
            selected: p.id == _pcId,
            onSelected: (_) {
              _stopWatching();
              setState(() {
                _pcId = p.id;
                _frame = null;
              });
              _startWatching();
            },
          ),
      ],
    );
  }

  Widget _screenView() {
    final stale = DateTime.now().difference(_lastFrame) > const Duration(seconds: 8);
    return _card(
      padding: const EdgeInsets.all(8),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: AspectRatio(
              aspectRatio: _aspect,
              child: _frame == null
                  ? Container(
                      color: NeoColors.ink,
                      alignment: Alignment.center,
                      child: const Column(mainAxisSize: MainAxisSize.min, children: [
                        SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: NeoColors.onInk)),
                        SizedBox(height: 10),
                        Text('Waiting for the screen…', style: TextStyle(color: NeoColors.onInkMuted)),
                      ]),
                    )
                  : LayoutBuilder(
                      builder: (context, box) {
                        final size = Size(box.maxWidth, box.maxHeight);
                        return InteractiveViewer(
                          transformationController: _zoom,
                          minScale: 1,
                          maxScale: 5,
                          panEnabled: !_dragMode,
                          scaleEnabled: !_dragMode,
                          child: GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onTapUp: (d) => _send('click', _xy(_norm(d.localPosition, size))),
                            onDoubleTapDown: (d) => _send('click', {..._xy(_norm(d.localPosition, size)), 'double': true}),
                            onDoubleTap: () {},
                            onLongPressStart: (d) => _send('click', {..._xy(_norm(d.localPosition, size)), 'button': 'right'}),
                            onPanStart: _dragMode ? (d) => _send('down', _xy(_norm(d.localPosition, size))) : null,
                            onPanUpdate: _dragMode
                                ? (d) {
                                    _lastPan = d.localPosition;
                                    _send('move', _xy(_norm(d.localPosition, size)));
                                  }
                                : null,
                            onPanEnd: _dragMode ? (d) => _send('up', _xy(_norm(_lastPan ?? Offset.zero, size))) : null,
                            onPanDown: _dragMode ? (d) => _lastPan = d.localPosition : null,
                            child: Stack(fit: StackFit.expand, children: [
                              Image.memory(_frame!, gaplessPlayback: true, fit: BoxFit.fill, filterQuality: FilterQuality.medium),
                              if (stale)
                                Container(
                                  color: Colors.black45,
                                  alignment: Alignment.center,
                                  child: const Text('Reconnecting…', style: TextStyle(color: Colors.white)),
                                ),
                            ]),
                          ),
                        );
                      },
                    ),
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  _dragMode ? 'Drag mode: slide to drag the mouse' : 'Tap = click · double-tap · hold = right-click · pinch to zoom',
                  style: const TextStyle(fontSize: 12, color: NeoColors.muted),
                ),
              ),
              IconButton(
                tooltip: 'Drag mode',
                isSelected: _dragMode,
                icon: const Icon(Icons.pan_tool_alt_outlined),
                selectedIcon: const Icon(Icons.pan_tool_alt),
                onPressed: () => setState(() => _dragMode = !_dragMode),
              ),
              IconButton(tooltip: 'Scroll up', icon: const Icon(Icons.keyboard_arrow_up), onPressed: () => _send('scroll', {'dy': 5})),
              IconButton(tooltip: 'Scroll down', icon: const Icon(Icons.keyboard_arrow_down), onPressed: () => _send('scroll', {'dy': -5})),
              IconButton(tooltip: 'Reset zoom', icon: const Icon(Icons.fit_screen_outlined), onPressed: () => _zoom.value = Matrix4.identity()),
            ],
          ),
        ],
      ),
    );
  }

  Offset? _lastPan;

  Widget _keysRow() {
    const keys = <(String, String)>[
      ('Esc', 'esc'),
      ('Tab', 'tab'),
      ('Enter', 'enter'),
      ('⌫', 'backspace'),
      ('⊞ Win', 'win'),
      ('Alt+Tab', 'alt+tab'),
      ('Ctrl+C', 'ctrl+c'),
      ('Ctrl+V', 'ctrl+v'),
      ('Ctrl+Z', 'ctrl+z'),
      ('Desktop', 'win+d'),
      ('⏯', 'playpause'),
      ('🔉', 'volumedown'),
      ('🔊', 'volumeup'),
    ];
    return SizedBox(
      height: 40,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          for (final (label, key) in keys)
            Padding(
              padding: const EdgeInsets.only(right: 6),
              child: ActionChip(label: Text(label), onPressed: () => _send('key', {'key': key})),
            ),
          ActionChip(
            avatar: const Icon(Icons.lock_outline, size: 16),
            label: const Text('Lock'),
            onPressed: () => _send('lock'),
          ),
        ],
      ),
    );
  }

  Widget _typeBox() {
    return _card(
      padding: const EdgeInsets.fromLTRB(14, 4, 6, 4),
      child: Row(children: [
        const Icon(Icons.keyboard_outlined, color: NeoColors.muted),
        const SizedBox(width: 10),
        Expanded(
          child: TextField(
            controller: _typeCtl,
            decoration: const InputDecoration(border: InputBorder.none, hintText: 'Type on the PC…'),
            onSubmitted: (_) => _typeSend(enter: true),
          ),
        ),
        IconButton(tooltip: 'Type', icon: const Icon(Icons.keyboard_return), onPressed: () => _typeSend(enter: true)),
      ]),
    );
  }

  Widget _askCard() {
    return _card(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Ask Neo on this PC', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 2),
          const Text('"Open YouTube", "play music", "lock the PC", "set a timer for 5 minutes"…',
              style: TextStyle(fontSize: 12, color: NeoColors.muted)),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(
              child: TextField(
                controller: _askCtl,
                decoration: InputDecoration(
                  hintText: 'Tell Neo what to do',
                  filled: true,
                  fillColor: NeoColors.chip,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: NeoColors.line)),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                ),
                onSubmitted: (_) => _ask(),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filled(
              onPressed: _askBusy ? null : _ask,
              icon: _askBusy
                  ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.arrow_forward),
            ),
          ]),
          if (_askReply != null) ...[
            const SizedBox(height: 10),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: NeoColors.chip, borderRadius: BorderRadius.circular(14)),
              child: SelectableText(_askReply!),
            ),
          ],
        ],
      ),
    );
  }
}
