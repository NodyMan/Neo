import 'dart:io';

import 'package:flutter/material.dart';

import '../money/add_transaction_sheet.dart';
import '../neo/agent_tools.dart';
import '../neo/live_call.dart';
import '../neo/neo_brain.dart';
import '../neo/phone.dart';
import '../theme.dart';
import 'approvals_screen.dart';
import 'chat_screen.dart';
import 'home_screen.dart';
import 'live_screen.dart';
import 'money_screen.dart';
import 'pc_screen.dart';

/// Tabs (IndexedStack order): 0 Home · 1 Chat · 2 Approvals · 3 Money · 4 PC remote · 5 Live call.
class Shell extends StatefulWidget {
  const Shell({super.key});

  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  static const live = 5;
  int _tab = 0;

  void go(int i) => setState(() => _tab = i);

  @override
  void initState() {
    super.initState();
    // Long-press the Neo icon on the home screen → "Talk to Neo" / "Add expense".
    Phone.onShortcut = _shortcut;
    Phone.launchShortcut().then((s) {
      if (s != null) _shortcut(s);
    });
    AgentTools.confirm = _confirm;
    NeoCall.instance.addListener(_callChanged);
  }

  @override
  void dispose() {
    Phone.onShortcut = null;
    AgentTools.confirm = null;
    NeoCall.instance.removeListener(_callChanged);
    super.dispose();
  }

  void _callChanged() {
    if (mounted) setState(() {});
  }

  void _shortcut(String s) {
    if (!mounted) return;
    if (s == 'talk') {
      go(live);
    } else if (s == 'expense') {
      go(3);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) showAddTransaction(context);
      });
    }
  }

  /// Risky actions (delete, shut down…) wait for Max's tap here.
  Future<bool> _confirm(String title, String detail) async {
    if (!mounted) return false;
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isDismissible: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (c) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(children: [
                Icon(Icons.shield_outlined, color: neo.color),
                const SizedBox(width: 10),
                Expanded(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
              ]),
              if (detail.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(detail, style: const TextStyle(color: NeoColors.muted, height: 1.35)),
              ],
              const SizedBox(height: 18),
              Row(children: [
                Expanded(
                  child: OutlinedButton(
                    style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(46), side: const BorderSide(color: NeoColors.line)),
                    onPressed: () => Navigator.pop(c, false),
                    child: const Text('No', style: TextStyle(color: NeoColors.ink)),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton(
                    style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(46)),
                    onPressed: () => Navigator.pop(c, true),
                    child: const Text('Yes, do it'),
                  ),
                ),
              ]),
            ],
          ),
        ),
      ),
    );
    return ok == true;
  }

  @override
  Widget build(BuildContext context) {
    final onPc = Platform.isWindows;
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: IndexedStack(
          index: _tab,
          children: [
            // Only the visible tab runs animations (Neo's face is 60 fps).
            TickerMode(enabled: _tab == 0, child: HomeScreen(onOpenTab: go)),
            TickerMode(enabled: _tab == 1, child: const ChatScreen()),
            const ApprovalsScreen(),
            const MoneyScreen(),
            onPc ? const SizedBox.shrink() : PcScreen(active: _tab == 4),
            TickerMode(enabled: _tab == live, child: const LiveScreen()),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
          child: ListenableBuilder(
            listenable: neo,
            builder: (context, _) => Container(
              height: 60,
              padding: const EdgeInsets.symmetric(horizontal: 6),
              decoration: BoxDecoration(
                color: NeoColors.card,
                borderRadius: BorderRadius.circular(30),
                border: Border.all(color: NeoColors.line),
              ),
              child: Row(
                children: [
                  _NavItem(icon: Icons.blur_on_rounded, label: 'Home', selected: _tab == 0, onTap: () => go(0)),
                  _NavItem(icon: Icons.chat_bubble_outline_rounded, label: 'Chat', selected: _tab == 1, onTap: () => go(1)),
                  _LiveNavButton(selected: _tab == live, inCall: NeoCall.instance.active, onTap: () => go(live)),
                  _NavItem(icon: Icons.account_balance_wallet_outlined, label: 'Money', selected: _tab == 3, onTap: () => go(3)),
                  onPc
                      ? _NavItem(icon: Icons.task_alt_rounded, label: 'Approvals', selected: _tab == 2, onTap: () => go(2), badge: neo.pendingApprovals)
                      : _NavItem(icon: Icons.laptop_rounded, label: 'PC', selected: _tab == 4, onTap: () => go(4)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _LiveNavButton extends StatelessWidget {
  const _LiveNavButton({required this.selected, required this.inCall, required this.onTap});
  final bool selected;
  final bool inCall;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Semantics(
        button: true,
        selected: selected,
        label: 'Live call with Neo',
        child: GestureDetector(
          onTap: onTap,
          child: Center(
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 48,
              height: 42,
              decoration: BoxDecoration(
                color: inCall ? NeoColors.good : neo.color,
                borderRadius: BorderRadius.circular(21),
                boxShadow: selected ? [BoxShadow(color: neo.color.withValues(alpha: 0.45), blurRadius: 16)] : null,
              ),
              child: Icon(inCall ? Icons.call_rounded : Icons.graphic_eq_rounded, color: NeoColors.onInk, size: 22),
            ),
          ),
        ),
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({required this.icon, required this.label, required this.selected, required this.onTap, this.badge = 0});
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final int badge;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Semantics(
        selected: selected,
        button: true,
        label: label,
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: onTap,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Badge(
                isLabelVisible: badge > 0,
                label: Text('$badge'),
                child: Icon(icon, size: 22, color: selected ? NeoColors.ink : NeoColors.muted),
              ),
              const SizedBox(height: 3),
              AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                width: selected ? 14 : 0,
                height: 3,
                decoration: BoxDecoration(color: neo.color, borderRadius: BorderRadius.circular(2)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
