import 'dart:async';

import 'package:flutter/material.dart';

import '../neo/agent_tools.dart';
import '../neo/live_call.dart';
import '../neo/neo_brain.dart';
import '../neo/neo_face.dart';
import '../theme.dart';

/// Talk to Neo like a phone call: real-time voice, interrupt any time, he acts while you talk.
class LiveScreen extends StatefulWidget {
  const LiveScreen({super.key});

  @override
  State<LiveScreen> createState() => _LiveScreenState();
}

class _LiveScreenState extends State<LiveScreen> {
  final call = NeoCall.instance;
  final _scroll = ScrollController();
  final _text = TextEditingController();
  bool _typing = false;
  Timer? _clock;

  @override
  void initState() {
    super.initState();
    call.addListener(_changed);
    _clock = Timer.periodic(const Duration(seconds: 1), (_) {
      if (call.active && mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    call.removeListener(_changed);
    _clock?.cancel();
    _scroll.dispose();
    _text.dispose();
    super.dispose();
  }

  int _lineCount = 0;
  void _changed() {
    if (!mounted) return;
    setState(() {});
    if (call.lines.length != _lineCount) {
      _lineCount = call.lines.length;
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
      });
    }
  }

  NeoMood get _mood => switch (call.state) {
        CallState.listening => NeoMood.listening,
        CallState.thinking || CallState.connecting => NeoMood.thinking,
        CallState.speaking => NeoMood.talking,
        CallState.error => NeoMood.alert,
        CallState.off => NeoMood.idle,
      };

  String get _status => switch (call.state) {
        CallState.off => 'Tap to talk with Neo',
        CallState.connecting => 'Connecting…',
        CallState.listening => call.muted ? 'Muted' : 'Listening',
        CallState.thinking => 'Working on it…',
        CallState.speaking => 'Neo is talking · just speak to interrupt',
        CallState.error => call.error ?? 'Something went wrong',
      };

  String _hms(Duration d) => '${d.inMinutes.toString().padLeft(2, '0')}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';

  void _sendTyped() {
    final t = _text.text.trim();
    if (t.isEmpty) return;
    call.sendText(t);
    _text.clear();
    setState(() => _typing = false);
  }

  @override
  Widget build(BuildContext context) {
    final active = call.active;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(shape: BoxShape.circle, color: active ? NeoColors.good : NeoColors.muted),
              ),
              const SizedBox(width: 8),
              Text(active ? 'Live · ${_hms(call.elapsed)}' : 'Live', style: const TextStyle(fontWeight: FontWeight.w700)),
              const Spacer(),
              ValueListenableBuilder<List<NeoTimer>>(
                valueListenable: NeoTimers.active,
                builder: (context, timers, _) => Row(children: [
                  for (final t in timers.take(2))
                    Padding(
                      padding: const EdgeInsets.only(left: 6),
                      child: InputChip(
                        avatar: const Icon(Icons.timer_outlined, size: 16),
                        label: Text(_left(t), style: const TextStyle(fontSize: 12)),
                        onDeleted: () => NeoTimers.cancel(t),
                        visualDensity: VisualDensity.compact,
                      ),
                    ),
                ]),
              ),
            ],
          ),
          const SizedBox(height: 8),
          // Neo
          Expanded(
            flex: 5,
            child: GestureDetector(
              onTap: active ? null : call.start,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  _Halo(level: call.level, color: neo.color, on: active),
                  SizedBox(
                    width: 260,
                    height: 220,
                    child: NeoFace(mood: _mood, color: neo.color, voiceLevel: call.level, onTap: active ? null : call.start),
                  ),
                ],
              ),
            ),
          ),
          Text(_status, textAlign: TextAlign.center, style: TextStyle(color: call.state == CallState.error ? NeoColors.danger : NeoColors.muted)),
          const SizedBox(height: 10),
          // What was said
          Expanded(
            flex: 4,
            child: call.lines.isEmpty
                ? _Hints(onPc: AgentTools.onPc, onPick: (h) {
                    if (active) {
                      call.sendText(h);
                    } else {
                      call.start().then((_) => call.sendText(h));
                    }
                  })
                : ShaderMask(
                    shaderCallback: (r) => const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.transparent, Colors.white, Colors.white],
                      stops: [0, 0.18, 1],
                    ).createShader(r),
                    blendMode: BlendMode.dstIn,
                    child: ListView.builder(
                      controller: _scroll,
                      padding: const EdgeInsets.only(top: 24, bottom: 4),
                      itemCount: call.lines.length,
                      itemBuilder: (context, i) => _Line(call.lines[i]),
                    ),
                  ),
          ),
          if (_typing)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: TextField(
                controller: _text,
                autofocus: true,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _sendTyped(),
                decoration: InputDecoration(
                  hintText: 'Type to Neo…',
                  isDense: true,
                  suffixIcon: IconButton(icon: const Icon(Icons.arrow_upward_rounded), onPressed: _sendTyped),
                ),
              ),
            ),
          const SizedBox(height: 12),
          // Controls
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _RoundButton(
                icon: call.muted ? Icons.mic_off_rounded : Icons.mic_none_rounded,
                tooltip: call.muted ? 'Unmute' : 'Mute',
                selected: call.muted,
                onTap: active ? call.toggleMute : null,
              ),
              const SizedBox(width: 20),
              _CallButton(active: active, connecting: call.state == CallState.connecting, onTap: active ? call.stop : call.start),
              const SizedBox(width: 20),
              _RoundButton(
                icon: AgentTools.onPc && active ? Icons.screen_search_desktop_outlined : Icons.keyboard_alt_outlined,
                tooltip: AgentTools.onPc && active ? 'Show Neo my screen' : 'Type',
                onTap: AgentTools.onPc && active
                    ? () => call.sendText('Look at my screen now (use look_at_screen) and tell me what you see.')
                    : () => setState(() => _typing = !_typing),
                onLongPress: () => setState(() => _typing = !_typing),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _left(NeoTimer t) {
    final d = t.endsAt.difference(DateTime.now());
    return d.isNegative ? '0:00' : '${d.inMinutes}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';
  }
}

class _Halo extends StatelessWidget {
  const _Halo({required this.level, required this.color, required this.on});
  final double level;
  final Color color;
  final bool on;

  @override
  Widget build(BuildContext context) {
    final size = 210.0 + (on ? level * 90 : 0.0);
    return AnimatedContainer(
      duration: const Duration(milliseconds: 120),
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(colors: [color.withValues(alpha: on ? 0.28 : 0.12), color.withValues(alpha: 0)]),
      ),
    );
  }
}

class _Line extends StatelessWidget {
  const _Line(this.l);
  final CallLine l;

  @override
  Widget build(BuildContext context) {
    if (l.who == 'tool') {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          const Icon(Icons.bolt_rounded, size: 14, color: NeoColors.muted),
          const SizedBox(width: 6),
          Expanded(child: Text(l.text, style: const TextStyle(fontSize: 12, color: NeoColors.muted), maxLines: 1, overflow: TextOverflow.ellipsis)),
        ]),
      );
    }
    final me = l.who == 'me';
    return Align(
      alignment: me ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        constraints: const BoxConstraints(maxWidth: 320),
        decoration: BoxDecoration(
          color: me ? NeoColors.chip : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(l.text.trim(), style: TextStyle(fontSize: 14, height: 1.35, color: me ? NeoColors.muted : NeoColors.ink)),
      ),
    );
  }
}

class _Hints extends StatelessWidget {
  const _Hints({required this.onPc, required this.onPick});
  final bool onPc;
  final void Function(String) onPick;

  @override
  Widget build(BuildContext context) {
    final hints = onPc
        ? const [
            'What\'s on my desktop?',
            'Find my last invoice PDF',
            'How\'s my battery and disk space?',
            'Set a 25 minute focus timer',
            'Open Telegram',
            'How much did I spend this month?',
          ]
        : const [
            'What did I miss today?',
            'How much did I spend this week?',
            'Play some chill music',
            'Remind me at 9 to call Aziz',
            'Find a good cafe near me',
            'Dollar rate today?',
          ];
    return Center(
      child: Wrap(
        alignment: WrapAlignment.center,
        spacing: 8,
        runSpacing: 8,
        children: [for (final h in hints) ActionChip(label: Text(h, style: const TextStyle(fontSize: 13)), onPressed: () => onPick(h))],
      ),
    );
  }
}

class _RoundButton extends StatelessWidget {
  const _RoundButton({required this.icon, required this.tooltip, this.onTap, this.onLongPress, this.selected = false});
  final IconData icon;
  final String tooltip;
  final VoidCallback? onTap;
  final VoidCallback? onLongPress;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkResponse(
        onTap: onTap,
        onLongPress: onLongPress,
        radius: 30,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          width: 52,
          height: 52,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: selected ? NeoColors.ink : NeoColors.chip,
            border: Border.all(color: NeoColors.line),
          ),
          child: Icon(icon, size: 22, color: onTap == null ? NeoColors.onInkMuted : (selected ? NeoColors.onInk : NeoColors.ink)),
        ),
      ),
    );
  }
}

class _CallButton extends StatelessWidget {
  const _CallButton({required this.active, required this.connecting, required this.onTap});
  final bool active;
  final bool connecting;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: active ? 'End call' : 'Start call',
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          width: 72,
          height: 72,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: active ? NeoColors.danger : neo.color,
            boxShadow: [BoxShadow(color: (active ? NeoColors.danger : neo.color).withValues(alpha: 0.35), blurRadius: 24)],
          ),
          child: connecting
              ? const Padding(padding: EdgeInsets.all(24), child: CircularProgressIndicator(strokeWidth: 2.5, color: NeoColors.onInk))
              : Icon(active ? Icons.call_end_rounded : Icons.graphic_eq_rounded, color: NeoColors.onInk, size: 30),
        ),
      ),
    );
  }
}
