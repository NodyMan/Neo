import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';

import '../config.dart';
import '../neo/neo_brain.dart';
import '../neo/neo_face.dart';
import '../theme.dart';
import '../widgets/live.dart';
import '../widgets/talk_bar.dart';
import 'activity_screen.dart';
import 'notes_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.onOpenTab});
  final void Function(int tab) onOpenTab;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with AutomaticKeepAliveClientMixin {
  String? _weather;
  late Future<_Today> _today = _loadToday();
  late Future<List<Map<String, dynamic>>> _suggestions = _loadSuggestions();

  late final Stream<List<Map<String, dynamic>>> _activity =
      liveStream(() => supabase.from('activity_log').stream(primaryKey: ['id']).order('ts', ascending: false).limit(3));

  static const _spendTypes = {'purchase', 'p2p', 'withdrawal', 'fee'};
  static const _quick = [
    (Icons.notifications_none_rounded, 'What did I miss?'),
    (Icons.music_note_rounded, 'Play some chill music'),
    (Icons.payments_outlined, 'How much did I spend this week?'),
    (Icons.timer_outlined, 'Set a 10 minute timer'),
    (Icons.send_rounded, 'Open Telegram'),
    (Icons.checklist_rounded, 'What are my tasks?'),
    (Icons.wb_sunny_outlined, 'Weather for tomorrow?'),
    (Icons.alarm_rounded, 'Wake me up at 7:00'),
    (Icons.near_me_outlined, 'Find a cafe near me'),
    (Icons.translate_rounded, 'Translate "thank you very much" to Uzbek'),
  ];

  @override
  void initState() {
    super.initState();
    _loadWeather();
  }

  Future<void> _loadWeather() async {
    try {
      final r = await http
          .get(Uri.parse('https://api.open-meteo.com/v1/forecast?latitude=$homeLat&longitude=$homeLon&current=temperature_2m,weather_code&timezone=Asia%2FTashkent'))
          .timeout(const Duration(seconds: 8));
      final j = jsonDecode(r.body) as Map<String, dynamic>;
      final cur = j['current'] as Map<String, dynamic>;
      final code = (cur['weather_code'] as num).toInt();
      if (!mounted) return;
      setState(() => _weather ='${(cur['temperature_2m'] as num).round()}° ${_weatherWord(code)}');
    } catch (_) {}
  }

  static String _weatherWord(int c) {
    if (c == 0) return 'clear';
    if (c <= 2) return 'partly cloudy';
    if (c == 3) return 'cloudy';
    if (c <= 48) return 'foggy';
    if (c <= 67 || (c >= 80 && c <= 82)) return 'rainy';
    if (c <= 77 || c == 85 || c == 86) return 'snowy';
    return 'stormy';
  }

  Future<_Today> _loadToday() async {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day).toUtc().toIso8601String();
    double spent = 0;
    int payments = 0;
    Map<String, dynamic>? next;
    try {
      final tx = await supabase.from('transactions').select('amount,currency,direction,type').gte('ts', start);
      for (final r in tx) {
        if (r['direction'] == 'debit' && _spendTypes.contains(r['type']) && (r['currency'] ?? 'UZS') == 'UZS') {
          spent += (r['amount'] as num?)?.toDouble() ?? 0;
          payments++;
        }
      }
    } catch (_) {}
    try {
      final tasks = await supabase
          .from('tasks')
          .select('title,due')
          .eq('status', 'open')
          .gte('due', now.toUtc().toIso8601String())
          .order('due', ascending: true)
          .limit(1);
      if (tasks.isNotEmpty) next = tasks.first;
    } catch (_) {}
    final ok = spent > 0 || next != null;
    if (ok) {
      await _writeCache('today', {'day': DateFormat('yyyy-MM-dd').format(now), 'spent': spent, 'payments': payments, 'next': next});
    } else if (!neo.online.value) {
      final c = await _readCache('today');
      if (c is Map && c['day'] == DateFormat('yyyy-MM-dd').format(now)) {
        return _Today((c['spent'] as num?)?.toDouble() ?? 0, (c['payments'] as num?)?.toInt() ?? 0,
            c['next'] is Map ? Map<String, dynamic>.from(c['next'] as Map) : null);
      }
    }
    return _Today(spent, payments, next);
  }

  // Small offline cache so Home still shows something without internet.
  static Future<File> _cacheFile(String name) async => File('${(await getApplicationDocumentsDirectory()).path}/neo_cache_$name.json');

  static Future<void> _writeCache(String name, Object data) async {
    try {
      await (await _cacheFile(name)).writeAsString(jsonEncode(data));
    } catch (_) {}
  }

  static Future<Object?> _readCache(String name) async {
    try {
      final f = await _cacheFile(name);
      if (await f.exists()) return jsonDecode(await f.readAsString());
    } catch (_) {}
    return null;
  }

  Future<List<Map<String, dynamic>>> _loadSuggestions() async {
    List<Map<String, dynamic>> list;
    try {
      final r = await supabase.rpc('neo_suggestions').timeout(const Duration(seconds: 10));
      list = (r as List).whereType<Map>().map((m) => Map<String, dynamic>.from(m)).toList();
      await _writeCache('suggestions', list);
    } catch (_) {
      final c = await _readCache('suggestions');
      list = c is List ? c.whereType<Map>().map((m) => Map<String, dynamic>.from(m)).toList() : [];
    }
    _nudgeOncePerDay(list);
    return list;
  }

  /// Predictive nudge: the first time Home opens each day, Neo mentions the top thing he noticed.
  Future<void> _nudgeOncePerDay(List<Map<String, dynamic>> list) async {
    if (list.isEmpty) return;
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final last = await _readCache('nudge_day');
    if (last == today) return;
    await _writeCache('nudge_day', today);
    if (!mounted || neo.lastReply != null || neo.isBusy) return;
    neo.say('Psst — ${list.first['title']}. ${list.first['detail'] ?? ''}');
  }

  Future<void> _refresh() async {
    setState(() {
      _today = _loadToday();
      _suggestions = _loadSuggestions();
    });
    await Future.wait([_today, _suggestions, _loadWeather()]);
  }

  String _greeting() {
    final h = DateTime.now().hour;
    if (h < 5) return 'Still up, Max?';
    if (h < 12) return 'Morning, Max';
    if (h < 18) return 'Afternoon, Max';
    return 'Evening, Max';
  }

  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    final t = Theme.of(context).textTheme;
    final date = DateFormat('EEE, d MMM').format(DateTime.now());

    return Column(
      children: [
        Expanded(
          child: RefreshIndicator(
            onRefresh: _refresh,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 12),
              children: [
                const _OfflineBanner(),
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_weather == null ? date : '$date · $_weather', style: t.bodyMedium?.copyWith(color: NeoColors.muted)),
                          Text(_greeting(), style: t.headlineSmall?.copyWith(fontWeight: FontWeight.w800, letterSpacing: -0.5)),
                        ],
                      ),
                    ),
                    IconButton.filled(
                      tooltip: 'Settings',
                      style: IconButton.styleFrom(backgroundColor: NeoColors.card, foregroundColor: NeoColors.ink, fixedSize: const Size(48, 48)),
                      onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen())),
                      icon: const Icon(Icons.tune_rounded),
                    ),
                  ],
                ),
                const SizedBox(height: 14),

                // Living Neo
                ListenableBuilder(
                  listenable: neo,
                  builder: (context, _) => SoftCard(
                    padding: EdgeInsets.zero,
                    radius: 28,
                    child: SizedBox(
                      height: 236,
                      child: Stack(
                        children: [
                          Positioned.fill(
                            child: NeoFace(mood: neo.mood, color: neo.color, voiceLevel: neo.voiceLevel, onTap: neo.poke),
                          ),
                          if (neo.lastReply != null)
                            Positioned(left: 14, top: 14, child: SpeechBubble(text: neo.lastReply!)),
                          if (neo.handsFree)
                            Positioned(
                              right: 12,
                              top: 12,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                decoration: BoxDecoration(color: NeoColors.ink, borderRadius: BorderRadius.circular(20)),
                                child: Row(mainAxisSize: MainAxisSize.min, children: [
                                  Icon(Icons.hearing_rounded, size: 14, color: neo.color),
                                  const SizedBox(width: 5),
                                  const Text('Hey Neo', style: TextStyle(color: NeoColors.onInk, fontSize: 12, fontWeight: FontWeight.w700)),
                                ]),
                              ),
                            ),
                          Positioned(
                            left: 14,
                            right: 14,
                            bottom: 12,
                            child: ValueListenableBuilder<String?>(
                              valueListenable: neo.hearing,
                              builder: (context, h, _) => h == null || h.isEmpty
                                  ? const SizedBox.shrink()
                                  : Text('“$h”',
                                      textAlign: TextAlign.center,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(color: NeoColors.muted, fontStyle: FontStyle.italic)),
                            ),
                          ),
                          if (neo.lastReply == null && neo.mood == NeoMood.alert)
                            Positioned(
                              left: 14,
                              top: 14,
                              child: GestureDetector(
                                onTap: () => widget.onOpenTab(2),
                                child: SpeechBubble(text: 'Psst — ${neo.pendingApprovals} thing${neo.pendingApprovals == 1 ? '' : 's'} need your OK.'),
                              ),
                            ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),

                // Quick asks
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      for (final (icon, q) in _quick)
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ActionChip(
                            avatar: Icon(icon, size: 18, color: NeoColors.ink),
                            label: Text(q),
                            backgroundColor: NeoColors.card,
                            side: const BorderSide(color: NeoColors.line),
                            shape: const StadiumBorder(),
                            labelStyle: const TextStyle(fontWeight: FontWeight.w600, color: NeoColors.ink),
                            onPressed: () => neo.sendText(q),
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                const _MoodRow(),
                const SizedBox(height: 12),
                FutureBuilder<List<Map<String, dynamic>>>(
                  future: _suggestions,
                  builder: (context, snap) {
                    final list = snap.data ?? const [];
                    if (list.isEmpty) return const SizedBox.shrink();
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 4, bottom: 8),
                            child: Text('Neo noticed', style: t.titleSmall?.copyWith(fontWeight: FontWeight.w700, color: NeoColors.muted)),
                          ),
                          for (final sg in list.take(4)) _SuggestionCard(sg),
                        ],
                      ),
                    );
                  },
                ),

                FutureBuilder<_Today>(
                  future: _today,
                  builder: (context, snap) {
                    final d = snap.data;
                    return Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: SoftCard(
                                onTap: () => widget.onOpenTab(3),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Spent today', style: t.bodySmall?.copyWith(color: NeoColors.muted)),
                                    const SizedBox(height: 6),
                                    Text(d == null ? '…' : formatSum(d.spent), style: t.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
                                    const SizedBox(height: 4),
                                    Text(d == null ? 'UZS' : 'UZS · ${d.payments} payment${d.payments == 1 ? '' : 's'}',
                                        style: t.bodySmall?.copyWith(color: NeoColors.muted)),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: ListenableBuilder(
                                listenable: neo,
                                builder: (context, _) => SoftCard(
                                  color: NeoColors.ink,
                                  onTap: () => widget.onOpenTab(2),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text('Approvals', style: t.bodySmall?.copyWith(color: NeoColors.onInkMuted)),
                                      const SizedBox(height: 6),
                                      Text(neo.pendingApprovals == 0 ? 'All clear' : '${neo.pendingApprovals} waiting',
                                          style: t.headlineSmall?.copyWith(fontWeight: FontWeight.w800, color: NeoColors.onInk)),
                                      const SizedBox(height: 4),
                                      Text(neo.pendingApprovals == 0 ? 'Nothing to review' : 'Review now →',
                                          style: t.bodySmall?.copyWith(color: neo.color)),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        if (d?.next != null) ...[
                          const SizedBox(height: 12),
                          SoftCard(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                            child: Row(
                              children: [
                                Container(
                                  width: 48,
                                  height: 48,
                                  decoration: BoxDecoration(color: NeoColors.ground, borderRadius: BorderRadius.circular(16)),
                                  child: const Icon(Icons.alarm_rounded),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(d!.next!['title']?.toString() ?? '', style: t.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                                      Text('Next · ${DateFormat('EEE HH:mm').format(DateTime.parse(d.next!['due'].toString()).toLocal())}',
                                          style: t.bodySmall?.copyWith(color: NeoColors.muted)),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ],
                    );
                  },
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: SoftCard(
                        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NotesScreen())),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Icon(Icons.auto_stories_outlined),
                            const SizedBox(height: 8),
                            Text('Notes', style: t.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
                            Text('What Neo remembers', style: t.bodySmall?.copyWith(color: NeoColors.muted)),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: SoftCard(
                        color: neo.color.withValues(alpha: 0.30),
                        onTap: () => showModalBottomSheet<void>(
                          context: context,
                          backgroundColor: NeoColors.ground,
                          shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
                          builder: (_) => const _PhoneSkills(),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Icon(Icons.phone_android_rounded),
                            const SizedBox(height: 8),
                            Text('Phone control', style: t.titleSmall?.copyWith(fontWeight: FontWeight.w800)),
                            Text('What Neo can do', style: t.bodySmall?.copyWith(color: NeoColors.muted)),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                Row(
                  children: [
                    Expanded(child: Text('Today', style: t.titleSmall?.copyWith(fontWeight: FontWeight.w700, color: NeoColors.muted))),
                    TextButton(
                      onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ActivityScreen())),
                      child: const Text('See all', style: TextStyle(color: NeoColors.ink, fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
                StreamBuilder<List<Map<String, dynamic>>>(
                  stream: _activity,
                  builder: (context, snap) {
                    final rows = (snap.data ?? const <Map<String, dynamic>>[]).take(3).toList();
                    if (rows.isEmpty) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8),
                        child: Text('Nothing yet — say hi to Neo.', style: t.bodyMedium?.copyWith(color: NeoColors.muted)),
                      );
                    }
                    return SoftCard(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          for (final r in rows)
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              child: Row(
                                children: [
                                  Container(width: 8, height: 8, decoration: BoxDecoration(color: neo.color, shape: BoxShape.circle)),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text('${r['action'] ?? ''}', maxLines: 2, overflow: TextOverflow.ellipsis, style: t.bodyMedium),
                                  ),
                                  const SizedBox(width: 8),
                                  Text(_hm(r['ts']), style: t.bodySmall?.copyWith(color: NeoColors.muted)),
                                ],
                              ),
                            ),
                        ],
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
        const Padding(
          padding: EdgeInsets.fromLTRB(20, 4, 20, 8),
          child: TalkBar(),
        ),
      ],
    );
  }

  static String _hm(Object? ts) {
    final d = DateTime.tryParse(ts?.toString() ?? '')?.toLocal();
    return d == null ? '' : DateFormat('HH:mm').format(d);
  }
}

class _Today {
  _Today(this.spent, this.payments, this.next);
  final double spent;
  final int payments;
  final Map<String, dynamic>? next;
}

/// Cheat sheet of things Neo can do on the phone, each tappable as a quick ask.
class _PhoneSkills extends StatelessWidget {
  const _PhoneSkills();

  static const _items = [
    (Icons.apps_rounded, 'Open apps', 'Open Instagram'),
    (Icons.public_rounded, 'Websites & search', 'Search the web for best laptops 2026'),
    (Icons.music_note_rounded, 'Music', 'Play Eminem on Spotify'),
    (Icons.skip_next_rounded, 'Music controls', 'Next song'),
    (Icons.smart_display_outlined, 'YouTube', 'Find a funny cat video on YouTube'),
    (Icons.send_rounded, 'Write messages', 'Write to Aziz on WhatsApp that I am running late'),
    (Icons.notifications_none_rounded, 'Read notifications', 'What did I miss in Telegram?'),
    (Icons.call_outlined, 'Call', 'Call 90 123 45 67'),
    (Icons.sms_outlined, 'SMS', 'Text 90 123 45 67 that I am on my way'),
    (Icons.alarm_rounded, 'Alarms', 'Wake me up at 7:30'),
    (Icons.timer_outlined, 'Timers', 'Set a 25 minute focus timer'),
    (Icons.navigation_outlined, 'Navigation', 'Take me to Tashkent City Park'),
    (Icons.map_outlined, 'Map search', 'Find a pharmacy near me'),
    (Icons.photo_camera_outlined, 'Camera', 'Open the camera'),
    (Icons.settings_outlined, 'Settings', 'Open Wi-Fi settings'),
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        shrinkWrap: true,
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
        children: [
          const Text('Neo can control your phone', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          const Text('Just ask — by voice or text. You allowed all of these, so Neo does them right away. The kill switch in Settings stops everything.',
              style: TextStyle(color: NeoColors.muted)),
          const SizedBox(height: 12),
          for (final (icon, title, example) in _items)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(icon),
              title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('"$example"', style: const TextStyle(color: NeoColors.muted)),
              trailing: const Icon(Icons.north_east_rounded, size: 18),
              onTap: () {
                Navigator.pop(context);
                neo.sendText(example);
              },
            ),
        ],
      ),
    );
  }
}

class _OfflineBanner extends StatelessWidget {
  const _OfflineBanner();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: neo.online,
      builder: (context, online, _) => online
          ? const SizedBox.shrink()
          : ValueListenableBuilder<int>(
              valueListenable: neo.outboxCount,
              builder: (context, n, _) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: SoftCard(
                  color: NeoColors.ink,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  child: Row(
                    children: [
                      const Icon(Icons.cloud_off_rounded, color: NeoColors.onInk),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          'Offline. Timers, alarms, apps and calls still work.${n > 0 ? ' $n saved message${n == 1 ? '' : 's'} will send when you\'re back.' : ''}',
                          style: const TextStyle(color: NeoColors.onInk, height: 1.3),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
}

/// "How are you?" — one tap. Neo adjusts his tone and reminders to your mood.
class _MoodRow extends StatelessWidget {
  const _MoodRow();

  static const _moods = [
    (-2, '😫', 'awful'),
    (-1, '😕', 'stressed'),
    (0, '😐', 'okay'),
    (1, '🙂', 'good'),
    (2, '😄', 'great'),
  ];

  @override
  Widget build(BuildContext context) {
    return SoftCard(
      padding: const EdgeInsets.fromLTRB(16, 10, 8, 10),
      child: Row(
        children: [
          const Expanded(child: Text('How are you?', style: TextStyle(fontWeight: FontWeight.w700))),
          for (final (score, emoji, word) in _moods)
            Semantics(
              button: true,
              label: 'I feel $word',
              child: InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: () => neo.logMood(score, word),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                  child: Text(emoji, style: const TextStyle(fontSize: 26)),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _SuggestionCard extends StatelessWidget {
  const _SuggestionCard(this.s);
  final Map<String, dynamic> s;

  static IconData _icon(String? k) => switch (k) {
        'bill' => Icons.receipt_long_outlined,
        'overdue' => Icons.warning_amber_rounded,
        'today' => Icons.today_outlined,
        'budget' => Icons.trending_up_rounded,
        'spike' => Icons.insights_outlined,
        'mood' => Icons.spa_outlined,
        _ => Icons.lightbulb_outline,
      };

  @override
  Widget build(BuildContext context) {
    final ask = s['ask']?.toString();
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: SoftCard(
        padding: const EdgeInsets.fromLTRB(14, 12, 8, 12),
        onTap: ask == null ? null : () => neo.sendText(ask),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(color: neo.color.withValues(alpha: 0.25), borderRadius: BorderRadius.circular(14)),
              child: Icon(_icon(s['kind']?.toString()), size: 20),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(s['title']?.toString() ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
                  if ((s['detail'] ?? '').toString().isNotEmpty)
                    Text(s['detail'].toString(), style: const TextStyle(color: NeoColors.muted, fontSize: 13, height: 1.3)),
                ],
              ),
            ),
            if (ask != null) const Icon(Icons.chevron_right_rounded, color: NeoColors.muted),
          ],
        ),
      ),
    );
  }
}
