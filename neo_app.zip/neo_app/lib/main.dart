import 'dart:io';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:window_manager/window_manager.dart';

import 'assist.dart';
import 'config.dart';
import 'desktop/desktop_shell.dart';
import 'neo/neo_brain.dart';
import 'neo/phone.dart';
import 'screens/login_screen.dart';
import 'screens/shell.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Never show Flutter's grey error box to Max: a broken widget just disappears.
  ErrorWidget.builder = (details) => const SizedBox.shrink();
  if (Platform.isWindows) await _desktopWindow();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabasePublishableKey);
  Phone.init();
  runApp(const NeoApp());
}

/// Entry point of the compact "Hey Neo" popup (Android NeoAssistActivity, its own Flutter engine).
@pragma('vm:entry-point')
Future<void> assistMain() async {
  WidgetsFlutterBinding.ensureInitialized();
  ErrorWidget.builder = (details) => const SizedBox.shrink();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabasePublishableKey);
  Phone.init();
  // Neo's voice and colour, so the popup sounds and looks like the app.
  try {
    final rows = await supabase.from('settings').select('key,value').inFilter('key', ['gemini_voice', 'neo_color']).timeout(const Duration(seconds: 4));
    for (final r in rows) {
      final v = r['value'];
      if (r['key'] == 'gemini_voice' && v is String && v.isNotEmpty) neo.geminiVoice = v;
      if (r['key'] == 'neo_color') {
        final i = int.tryParse('$v');
        if (i != null && i >= 0 && i < NeoColors.accents.length) neo.colorListenable.value = NeoColors.accents[i];
      }
    }
  } catch (_) {}
  runApp(const AssistApp());
}

/// On the laptop Neo opens as a normal desktop app window.
Future<void> _desktopWindow() async {
  await windowManager.ensureInitialized();
  const opts = WindowOptions(
    size: Size(1280, 820),
    minimumSize: Size(900, 600),
    center: true,
    title: 'Neo',
    backgroundColor: Color(0xFF0D0D10),
    titleBarStyle: TitleBarStyle.normal,
  );
  await windowManager.waitUntilReadyToShow(opts, () async {
    await windowManager.show();
    await windowManager.focus();
  });
}

class NeoApp extends StatelessWidget {
  const NeoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Color>(
      valueListenable: neo.colorListenable,
      builder: (context, color, _) => MaterialApp(
        title: 'Neo',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(color),
        home: const AuthGate(),
      ),
    );
  }
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: supabase.auth.onAuthStateChange,
      builder: (context, _) {
        final signedIn = supabase.auth.currentSession != null;
        // Start/stop Neo's live subscriptions after this frame, never during build.
        WidgetsBinding.instance.addPostFrameCallback((_) => signedIn ? neo.start() : neo.stop());
        return signedIn ? (Platform.isWindows ? const DesktopShell() : const Shell()) : const LoginScreen();
      },
    );
  }
}
