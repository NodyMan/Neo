import 'dart:io';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:window_manager/window_manager.dart';

import 'config.dart';
import 'neo/neo_brain.dart';
import 'neo/phone.dart';
import 'screens/login_screen.dart';
import 'screens/shell.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Never show Flutter's grey error box to Max: a broken widget just disappears.
  ErrorWidget.builder = (details) => const SizedBox.shrink();
  if (Platform.isWindows) await _phoneSizedWindow();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabasePublishableKey);
  Phone.init();
  runApp(const NeoApp());
}

/// On the laptop Neo opens as a slim, phone-shaped window (resizable).
Future<void> _phoneSizedWindow() async {
  await windowManager.ensureInitialized();
  const opts = WindowOptions(
    size: Size(430, 860),
    minimumSize: Size(360, 600),
    center: true,
    title: 'Neo',
    backgroundColor: Color(0xFF0D0D10),
    titleBarStyle: TitleBarStyle.normal,
  );
  await windowManager.waitUntilReadyToShow(opts, () async {
    await windowManager.show();
    await windowManager.focus();
  });
}

class NeoApp extends StatelessWidget {
  const NeoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Color>(
      valueListenable: neo.colorListenable,
      builder: (context, color, _) => MaterialApp(
        title: 'Neo',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(color),
        home: const AuthGate(),
      ),
    );
  }
}

class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

class _AuthGateState extends State<AuthGate> {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: supabase.auth.onAuthStateChange,
      builder: (context, _) {
        final signedIn = supabase.auth.currentSession != null;
        // Start/stop Neo's live subscriptions after this frame, never during build.
        WidgetsBinding.instance.addPostFrameCallback((_) => signedIn ? neo.start() : neo.stop());
        return signedIn ? const Shell() : const LoginScreen();
      },
    );
  }
}
