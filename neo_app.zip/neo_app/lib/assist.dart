import 'dart:async';

import 'package:flutter/material.dart';

import 'neo/agent_tools.dart';
import 'neo/live_call.dart';
import 'neo/neo_brain.dart';
import 'neo/neo_face.dart';
import 'neo/phone.dart';
import 'theme.dart';

/// The compact Neo popup (Android NeoAssistActivity): opened by "Hey Neo" or the Assistant
/// button, over whatever app is on screen. It starts a live call at once and closes itself
/// a few seconds after the conversation goes quiet.
class AssistApp extends StatelessWidget {
  const AssistApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: buildTheme(neo.color).copyWith(scaffoldBackgroundColor: Colors.transparent),
      home: const AssistSheet(),
    );
  }
}

class AssistSheet extends StatefulWidget {
  const AssistSheet({super.key});

  @override
  State<AssistSheet> createState() => _AssistSheetState();
}

class _AssistSheetState extends State<AssistSheet> {
  final call = NeoCall.instance;
  Timer? _quiet;
  bool _closing = false;
  bool _heardSomething = false;

  static const _idleClose = Duration(seconds: 9);

  @override
  void initState() {
    super.initState();
    call.addListener(_changed);
    AgentTools.confirm = _confirm;
    WidgetsBinding.instance.addPostFrameCallback((_) => call.start());
  }

  @override
  void dispose() {
    call.removeListener(_changed);
    _quiet?.cancel();
    super.dispose();
  }

  void _changed() {
    if (!mounted) return;
    setState(() {});
    if (call.lines.isNotEmpty) _heardSomething = true;
    // Close when nothing has happened for a while after the last exchange.
    if (call.state == CallState.listening) {
      _quiet ??= Timer(_heardSomething ? _idleClose : const Duration(seconds: 14), _close);
    } else {
      _quiet?.cancel();
      _quiet = null;
    }
    if (call.state == CallState.error) {
      _quiet?.cancel();
      _quiet = Timer(const Duration(seconds: 5), _close);
    }
  }

  Future<void> _close() async {
    if (_closing) return;
    _closing = true;
    await call.stop();
    await Phone.assistDone();
  }

  Future<void> _openNeo() async {
    await call.stop();
    await Phone.openNeo();
  }

  Future<bool> _confirm(String title, String detail) async {
    _quiet?.cancel();
    _quiet = null;
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(title),
        content: detail.isEmpty ? null : Text(detail, style: const TextStyle(color: NeoColors.muted)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('No')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Yes, do it')),
        ],
      ),
    );
    return ok == true;
  }

  NeoMood get _mood => switch (call.state) {
        CallState.listening => NeoMood.listening,
        CallState.thinking || CallState.connecting => NeoMood.thinking,
        CallState.speaking => NeoMood.talking,
        CallState.error => NeoMood.alert,
        CallState.off => NeoMood.idle,
      };

  String get _caption {
    if (call.state == CallState.error) return call.error ?? 'Something went wrong';
    final last = call.lines.where((l) => l.who != 'tool').toList();
    if (last.isNotEmpty) return last.last.text.trim();
    return switch (call.state) {
      CallState.connecting => 'One sec…',
      CallState.listening => 'Listening…',
      CallState.thinking => 'On it…',
      CallState.speaking => '',
      _ => '',
    };
  }

  @override
  Widget build(BuildContext context) {
    final tool = call.lines.isNotEmpty && call.lines.last.who == 'tool' ? call.lines.last.text : null;
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _close, // tap outside the card to dismiss, like the Google Assistant sheet
        child: Align(
          alignment: Alignment.bottomCenter,
          child: GestureDetector(
            onTap: () {}, // taps on the card stay on the card
            child: SafeArea(
              child: Container(
                margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
                padding: const EdgeInsets.fromLTRB(14, 12, 10, 12),
                decoration: BoxDecoration(
                  color: NeoColors.card,
                  borderRadius: BorderRadius.circular(28),
                  border: Border.all(color: NeoColors.line),
                  boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 30, offset: Offset(0, 10))],
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 64,
                      height: 56,
                      child: NeoFace(mood: _mood, color: neo.color, voiceLevel: call.level, onTap: _openNeo),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          AnimatedSwitcher(
                            duration: const Duration(milliseconds: 150),
                            child: Text(
                              _caption,
                              key: ValueKey(_caption),
                              maxLines: 3,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 15,
                                height: 1.3,
                                color: call.state == CallState.error ? NeoColors.danger : NeoColors.ink,
                              ),
                            ),
                          ),
                          if (tool != null)
                            Padding(
                              padding: const EdgeInsets.only(top: 4),
                              child: Text('⚡ $tool', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: NeoColors.muted)),
                            ),
                          const SizedBox(height: 6),
                          _Wave(level: call.level, color: neo.color, on: call.active),
                        ],
                      ),
                    ),
                    IconButton(
                      tooltip: 'Close',
                      onPressed: _close,
                      icon: const Icon(Icons.close_rounded, color: NeoColors.muted),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// A thin live voice bar under the text.
class _Wave extends StatelessWidget {
  const _Wave({required this.level, required this.color, required this.on});
  final double level;
  final Color color;
  final bool on;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        for (var i = 0; i < 18; i++)
          AnimatedContainer(
            duration: const Duration(milliseconds: 90),
            margin: const EdgeInsets.only(right: 3),
            width: 3,
            height: on ? 4 + 14 * level * (0.4 + 0.6 * ((i * 7) % 5) / 4) : 4,
            decoration: BoxDecoration(color: color.withValues(alpha: on ? 0.9 : 0.3), borderRadius: BorderRadius.circular(2)),
          ),
      ],
    );
  }
}
