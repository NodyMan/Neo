import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// "Night" palette: dark, quiet, compact. `ink` is the high-contrast colour
/// (text, filled buttons); `onInk` is what sits on top of an ink fill.
class NeoColors {
  static const ground = Color(0xFF0D0D10);
  static const card = Color(0xFF16161B);
  static const ink = Color(0xFFF2F2F5);
  static const muted = Color(0xFF8A8A96);
  static const line = Color(0xFF25252C);
  static const chip = Color(0xFF1D1D23);
  static const onInk = Color(0xFF0D0D10);
  static const onInkMuted = Color(0xFF55555F);
  static const good = Color(0xFF4ADE80);
  static const danger = Color(0xFFF87171);

  /// Neo's face features stay dark on his coloured body, whatever the theme.
  static const faceInk = Color(0xFF1A1A1F);

  static const accents = <Color>[
    Color(0xFFF08A5D), // coral
    Color(0xFF9DD3A8), // sage
    Color(0xFFF5C451), // butter
    Color(0xFF8FA8F0), // periwinkle
  ];
}

ThemeData buildTheme(Color accent) {
  final base = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    colorScheme: ColorScheme.fromSeed(
      seedColor: accent,
      brightness: Brightness.dark,
      primary: NeoColors.ink,
      onPrimary: NeoColors.onInk,
      surface: NeoColors.ground,
      onSurface: NeoColors.ink,
    ),
    scaffoldBackgroundColor: NeoColors.ground,
  );
  final text = GoogleFonts.plusJakartaSansTextTheme(base.textTheme).apply(
    bodyColor: NeoColors.ink,
    displayColor: NeoColors.ink,
  );
  return base.copyWith(
    textTheme: text,
    appBarTheme: AppBarTheme(
      backgroundColor: NeoColors.ground,
      foregroundColor: NeoColors.ink,
      elevation: 0,
      scrolledUnderElevation: 0,
      titleTextStyle: text.titleLarge?.copyWith(fontWeight: FontWeight.w800),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: NeoColors.card,
      hintStyle: const TextStyle(color: NeoColors.muted),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none),
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating, backgroundColor: NeoColors.chip, contentTextStyle: TextStyle(color: NeoColors.ink)),
    visualDensity: VisualDensity.compact,
    dividerColor: NeoColors.line,
    dialogTheme: const DialogThemeData(backgroundColor: NeoColors.card),
    bottomSheetTheme: const BottomSheetThemeData(backgroundColor: NeoColors.card, surfaceTintColor: Colors.transparent),
    chipTheme: const ChipThemeData(backgroundColor: NeoColors.chip, side: BorderSide(color: NeoColors.line), labelStyle: TextStyle(color: NeoColors.ink)),
    listTileTheme: const ListTileThemeData(iconColor: NeoColors.ink, textColor: NeoColors.ink),
  );
}

/// Rounded card used everywhere: a hairline border keeps it crisp on the dark ground.
class SoftCard extends StatelessWidget {
  const SoftCard({super.key, required this.child, this.padding = const EdgeInsets.all(14), this.color = NeoColors.card, this.radius = 20, this.onTap});
  final Widget child;
  final EdgeInsets padding;
  final Color color;
  final double radius;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final box = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(radius),
        border: color == NeoColors.card ? Border.all(color: NeoColors.line) : null,
      ),
      child: child,
    );
    if (onTap == null) return box;
    return Material(
      color: Colors.transparent,
      child: InkWell(borderRadius: BorderRadius.circular(radius), onTap: onTap, child: box),
    );
  }
}

String formatSum(num v) {
  final s = v.round().abs().toString();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write(' ');
    b.write(s[i]);
  }
  return (v < 0 ? '−' : '') + b.toString();
}
