// Public connection details. The publishable key is safe in an app:
// Row Level Security keeps every Neo table private to Max's account.
// NEVER put the service_role key, Groq key or any AI key in this app.
const supabaseUrl = 'https://jsjxklslickhahyuajcc.supabase.co';
const supabasePublishableKey = 'sb_publishable_C_xF7SRRnrfzYN1WorHUZQ_x99_HxjS';

// n8n backend for the app. It only answers requests carrying Max's login token.
const neoWebhookUrl = 'https://assistant-neo.app.n8n.cloud/webhook/neo-app';

// Gemini Live model for real-time voice calls. The server (edge function neo-live-token)
// hands out short-lived tokens locked to its own model setting; this is only the fallback.
const liveModel = 'gemini-3.8-live';

// Tashkent, for the weather line.
const homeLat = 41.2995;
const homeLon = 69.2401;

/// Shown in Settings so you can check which build is installed.
const neoAppVersion = '2.4.1';
