// Public connection details. The publishable key is safe in an app:
// Row Level Security keeps every Neo table private to Max's account.
// NEVER put the service_role key, Groq key or any AI key in this app.
const supabaseUrl = 'https://jsjxklslickhahyuajcc.supabase.co';
const supabasePublishableKey = 'sb_publishable_C_xF7SRRnrfzYN1WorHUZQ_x99_HxjS';

// n8n backend for the app. It only answers requests carrying Max's login token.
const neoWebhookUrl = 'https://assistant-neo.app.n8n.cloud/webhook/neo-app';

// Tashkent, for the weather line.
const homeLat = 41.2995;
const homeLon = 69.2401;
