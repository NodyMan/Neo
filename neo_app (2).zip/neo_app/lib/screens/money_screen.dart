import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../money/add_transaction_sheet.dart';
import '../money/categories.dart';
import '../neo/neo_brain.dart';
import '../theme.dart';

/// Money: month overview, budget, daily chart, categories, top places and all transactions.
class MoneyScreen extends StatefulWidget {
  const MoneyScreen({super.key});

  @override
  State<MoneyScreen> createState() => _MoneyScreenState();
}

class _MonthData {
  _MonthData(this.rows, this.prevRows, this.budget);
  final List<Map<String, dynamic>> rows;
  final List<Map<String, dynamic>> prevRows;
  final double? budget;
}

class _MoneyScreenState extends State<MoneyScreen> with AutomaticKeepAliveClientMixin {
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month);
  late Future<_MonthData> _future = _load();

  Future<_MonthData> _load() async {
    final start = _month;
    final end = DateTime(_month.year, _month.month + 1);
    final prevStart = DateTime(_month.year, _month.month - 1);
    final rows = await supabase
        .from('transactions')
        .select()
        .gte('ts', start.toUtc().toIso8601String())
        .lt('ts', end.toUtc().toIso8601String())
        .order('ts', ascending: false);
    final prev = await supabase
        .from('transactions')
        .select('amount,currency,direction,type,category')
        .gte('ts', prevStart.toUtc().toIso8601String())
        .lt('ts', start.toUtc().toIso8601String());
    double? budget;
    try {
      final b = await supabase.from('settings').select('value').eq('key', 'monthly_budget').maybeSingle();
      final v = b?['value'];
      if (v != null) budget = double.tryParse(v.toString());
    } catch (_) {}
    return _MonthData(List<Map<String, dynamic>>.from(rows), List<Map<String, dynamic>>.from(prev), budget);
  }

  Future<void> _refresh() async {
    setState(() => _future = _load());
    await _future;
  }

  void _shiftMonth(int delta) {
    final next = DateTime(_month.year, _month.month + delta);
    if (next.isAfter(DateTime.now())) return;
    setState(() {
      _month = next;
      _future = _load();
    });
  }

  Future<void> _add() async {
    final saved = await showAddTransaction(context);
    if (saved == true) {
      neo.poke();
      _refresh();
    }
  }

  Future<void> _editBudget(double? current) async {
    final ctrl = TextEditingController(text: current == null ? '' : current.round().toString());
    final v = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Monthly budget (UZS)'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: const InputDecoration(hintText: 'e.g. 5000000'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(c, ctrl.text), child: const Text('Save')),
        ],
      ),
    );
    if (v == null) return;
    final n = double.tryParse(v);
    try {
      if (n == null || n <= 0) {
        await supabase.from('settings').delete().eq('key', 'monthly_budget');
      } else {
        await neo.saveSetting('monthly_budget', n);
      }
      _refresh();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Not saved: $e')));
    }
  }

  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Stack(
      children: [
        RefreshIndicator(
          onRefresh: _refresh,
          child: FutureBuilder<_MonthData>(
            future: _future,
            builder: (context, snap) {
              if (snap.hasError) {
                return ListView(children: [Padding(padding: const EdgeInsets.all(24), child: Text('Could not load money: ${snap.error}'))]);
              }
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              return _body(snap.data!);
            },
          ),
        ),
        Positioned(
          right: 20,
          bottom: 16,
          child: FloatingActionButton.extended(
            heroTag: 'add-tx',
            backgroundColor: NeoColors.ink,
            foregroundColor: NeoColors.onInk,
            onPressed: _add,
            icon: const Icon(Icons.add_rounded),
            label: const Text('Add', style: TextStyle(fontWeight: FontWeight.w700)),
          ),
        ),
      ],
    );
  }

  Widget _body(_MonthData d) {
    final t = Theme.of(context).textTheme;
    final isThisMonth = _month.year == DateTime.now().year && _month.month == DateTime.now().month;

    double spent = 0, income = 0, prevSpent = 0;
    int payments = 0;
    final otherCurrencies = <String, double>{};
    final byCat = <String, double>{};
    final byMerchant = <String, double>{};
    final daysInMonth = DateTime(_month.year, _month.month + 1, 0).day;
    final daily = List<double>.filled(daysInMonth, 0);

    for (final r in d.rows) {
      final a = (r['amount'] as num?)?.toDouble() ?? 0;
      final cur = r['currency']?.toString() ?? 'UZS';
      if (cur != 'UZS') {
        if (isSpend(r)) otherCurrencies[cur] = (otherCurrencies[cur] ?? 0) + a;
        continue;
      }
      if (isSpend(r)) {
        spent += a;
        payments++;
        final c = r['category']?.toString() ?? 'Other';
        byCat[c] = (byCat[c] ?? 0) + a;
        final m = r['merchant_norm']?.toString() ?? r['merchant_raw']?.toString();
        if (m != null && m.isNotEmpty) byMerchant[m] = (byMerchant[m] ?? 0) + a;
        final ts = DateTime.tryParse(r['ts']?.toString() ?? '')?.toLocal();
        if (ts != null && ts.month == _month.month) daily[ts.day - 1] += a;
      } else if (isIncome(r)) {
        income += a;
      }
    }
    for (final r in d.prevRows) {
      if ((r['currency'] ?? 'UZS') == 'UZS' && isSpend(r)) prevSpent += (r['amount'] as num?)?.toDouble() ?? 0;
    }

    final cats = byCat.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final merchants = byMerchant.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final daysPassed = isThisMonth ? DateTime.now().day : daysInMonth;
    final perDay = daysPassed == 0 ? 0.0 : spent / daysPassed;
    final forecast = isThisMonth ? perDay * daysInMonth : spent;
    final change = prevSpent > 0 ? (spent - prevSpent) / prevSpent * 100 : null;

    // Group transactions by day for the list.
    final groups = <String, List<Map<String, dynamic>>>{};
    for (final r in d.rows) {
      final ts = DateTime.tryParse(r['ts']?.toString() ?? '')?.toLocal();
      final key = ts == null ? '—' : DateFormat('EEEE, d MMM').format(ts);
      groups.putIfAbsent(key, () => []).add(r);
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 96),
      children: [
        Row(
          children: [
            Expanded(child: Text('Money', style: t.headlineSmall?.copyWith(fontWeight: FontWeight.w800))),
            IconButton(tooltip: 'Previous month', onPressed: () => _shiftMonth(-1), icon: const Icon(Icons.chevron_left_rounded)),
            Text(DateFormat('MMM yyyy').format(_month), style: const TextStyle(fontWeight: FontWeight.w700)),
            IconButton(tooltip: 'Next month', onPressed: isThisMonth ? null : () => _shiftMonth(1), icon: const Icon(Icons.chevron_right_rounded)),
          ],
        ),
        const SizedBox(height: 8),

        // Hero
        ListenableBuilder(
          listenable: neo.colorListenable,
          builder: (context, _) => SoftCard(
            color: NeoColors.ink,
            radius: 28,
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Spent', style: TextStyle(color: NeoColors.onInkMuted)),
                const SizedBox(height: 4),
                Text('${formatSum(spent)} UZS',
                    style: const TextStyle(color: NeoColors.onInk, fontSize: 32, fontWeight: FontWeight.w800, letterSpacing: -0.5)),
                for (final e in otherCurrencies.entries)
                  Text('+ ${formatSum(e.value)} ${e.key}', style: const TextStyle(color: NeoColors.onInkMuted)),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _Pill(text: '$payments payments', color: NeoColors.onInkMuted),
                    if (change != null)
                      _Pill(
                        text: '${change >= 0 ? '▲' : '▼'} ${change.abs().round()}% vs last month',
                        color: change > 10 ? const Color(0xFFFFB4A6) : const Color(0xFFA8E6B8),
                      ),
                    if (income > 0) _Pill(text: 'In: ${formatSum(income)}', color: const Color(0xFFA8E6B8)),
                  ],
                ),
                if (d.budget != null && isThisMonth) ...[
                  const SizedBox(height: 16),
                  _BudgetBar(spent: spent, budget: d.budget!, forecast: forecast, color: neo.color),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),

        // Quick stats
        Row(
          children: [
            Expanded(child: _Stat(label: 'Per day', value: formatSum(perDay))),
            const SizedBox(width: 10),
            Expanded(child: _Stat(label: isThisMonth ? 'Month forecast' : 'Last month', value: formatSum(isThisMonth ? forecast : prevSpent))),
            const SizedBox(width: 10),
            Expanded(
              child: _Stat(
                label: 'Budget',
                value: d.budget == null ? 'Set' : formatSum(d.budget!),
                onTap: () => _editBudget(d.budget),
              ),
            ),
          ],
        ),
        const SizedBox(height: 20),

        _Section('Daily spending'),
        SoftCard(
          padding: const EdgeInsets.fromLTRB(12, 16, 12, 8),
          child: SizedBox(
            height: 150,
            child: ListenableBuilder(
              listenable: neo.colorListenable,
              builder: (context, _) => CustomPaint(
                painter: _DailyBars(daily, highlightDay: isThisMonth ? DateTime.now().day : null, color: neo.color),
                size: Size.infinite,
              ),
            ),
          ),
        ),

        if (cats.isNotEmpty) ...[
          const SizedBox(height: 20),
          _Section('Where it went'),
          SoftCard(
            child: Column(
              children: [
                SizedBox(height: 14, child: _StackedBar(cats: cats, total: spent)),
                const SizedBox(height: 12),
                for (final c in cats) _CatRow(name: c.key, value: c.value, total: spent),
              ],
            ),
          ),
        ],

        if (merchants.isNotEmpty) ...[
          const SizedBox(height: 20),
          _Section('Top places'),
          SoftCard(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Column(
              children: [
                for (final m in merchants.take(5))
                  ListTile(
                    dense: true,
                    title: Text(_title(m.key), style: const TextStyle(fontWeight: FontWeight.w600)),
                    trailing: Text(formatSum(m.value), style: const TextStyle(fontWeight: FontWeight.w700)),
                  ),
              ],
            ),
          ),
        ],

        const SizedBox(height: 20),
        _Section('Transactions'),
        if (d.rows.isEmpty)
          SoftCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('No transactions yet', style: TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                const Text('Tap Add, or just tell Neo: "I paid 45 000 for lunch at Evos".', style: TextStyle(color: NeoColors.muted)),
              ],
            ),
          ),
        for (final g in groups.entries) ...[
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 8, 4, 6),
            child: Text(g.key, style: const TextStyle(color: NeoColors.muted, fontWeight: FontWeight.w600, fontSize: 13)),
          ),
          for (final r in g.value)
            _TxTile(
              row: r,
              onTap: () async {
                final changed = await showEditTransaction(context, r);
                if (changed == true) _refresh();
              },
            ),
        ],
      ],
    );
  }

  static String _title(String s) => s.isEmpty ? s : s[0].toUpperCase() + s.substring(1);
}

class _Section extends StatelessWidget {
  const _Section(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(left: 4, bottom: 8),
        child: Text(text, style: const TextStyle(fontWeight: FontWeight.w700, color: NeoColors.muted)),
      );
}

class _Pill extends StatelessWidget {
  const _Pill({required this.text, required this.color});
  final String text;
  final Color color;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(20)),
        child: Text(text, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600)),
      );
}

class _Stat extends StatelessWidget {
  const _Stat({required this.label, required this.value, this.onTap});
  final String label, value;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => SoftCard(
        onTap: onTap,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(color: NeoColors.muted, fontSize: 12)),
            const SizedBox(height: 4),
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
            ),
          ],
        ),
      );
}

class _BudgetBar extends StatelessWidget {
  const _BudgetBar({required this.spent, required this.budget, required this.forecast, required this.color});
  final double spent, budget, forecast;
  final Color color;
  @override
  Widget build(BuildContext context) {
    final p = (spent / budget).clamp(0.0, 1.0).toDouble();
    final over = forecast > budget;
    final left = budget - spent;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(value: p, minHeight: 10, backgroundColor: Colors.white.withValues(alpha: 0.12), color: spent > budget ? const Color(0xFFFFB4A6) : color),
        ),
        const SizedBox(height: 6),
        Text(
          left >= 0
              ? '${formatSum(left)} left of ${formatSum(budget)}${over ? ' · on track to go over' : ''}'
              : '${formatSum(-left)} over budget',
          style: TextStyle(color: over || left < 0 ? const Color(0xFFFFB4A6) : NeoColors.onInkMuted, fontSize: 12),
        ),
      ],
    );
  }
}

class _StackedBar extends StatelessWidget {
  const _StackedBar({required this.cats, required this.total});
  final List<MapEntry<String, double>> cats;
  final double total;
  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(7),
        child: Row(
          children: [
            for (final c in cats)
              Expanded(
                flex: math.max(1, (c.value / (total == 0 ? 1 : total) * 1000).round()),
                child: Container(color: catFor(c.key).color),
              ),
          ],
        ),
      );
}

class _CatRow extends StatelessWidget {
  const _CatRow({required this.name, required this.value, required this.total});
  final String name;
  final double value, total;
  @override
  Widget build(BuildContext context) {
    final c = catFor(name);
    final pct = total == 0 ? 0 : (value / total * 100).round();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(color: c.color.withValues(alpha: 0.25), borderRadius: BorderRadius.circular(12)),
            child: Icon(c.icon, size: 18, color: NeoColors.ink),
          ),
          const SizedBox(width: 12),
          Expanded(child: Text(name, style: const TextStyle(fontWeight: FontWeight.w600))),
          Text('$pct%', style: const TextStyle(color: NeoColors.muted)),
          const SizedBox(width: 12),
          Text(formatSum(value), style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _TxTile extends StatelessWidget {
  const _TxTile({required this.row, required this.onTap});
  final Map<String, dynamic> row;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final ts = DateTime.tryParse(row['ts']?.toString() ?? '')?.toLocal();
    final credit = row['direction'] == 'credit';
    final amount = (row['amount'] as num?)?.toDouble() ?? 0;
    final c = catFor(row['category']?.toString());
    final merchant = row['merchant_norm']?.toString() ?? row['merchant_raw']?.toString();
    final card = row['card_mask'] != null ? ' · *${row['card_mask']}' : '';
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: SoftCard(
        onTap: onTap,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(color: c.color.withValues(alpha: 0.25), borderRadius: BorderRadius.circular(14)),
              child: Icon(c.icon, size: 20, color: NeoColors.ink),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(merchant == null || merchant.isEmpty ? c.name : merchant[0].toUpperCase() + merchant.substring(1),
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  Text('${c.name}$card${ts != null ? ' · ${DateFormat('HH:mm').format(ts)}' : ''}',
                      style: const TextStyle(color: NeoColors.muted, fontSize: 12)),
                ],
              ),
            ),
            Text('${credit ? '+' : '−'}${formatSum(amount)}${row['currency'] == 'UZS' || row['currency'] == null ? '' : ' ${row['currency']}'}',
                style: TextStyle(fontWeight: FontWeight.w800, color: credit ? NeoColors.good : NeoColors.ink)),
          ],
        ),
      ),
    );
  }
}

/// Simple bar chart: one bar per day of the month.
class _DailyBars extends CustomPainter {
  _DailyBars(this.values, {this.highlightDay, required this.color});
  final List<double> values;
  final int? highlightDay;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final maxV = values.fold<double>(0, math.max);
    const labelH = 18.0;
    final chartH = size.height - labelH;
    final n = values.length;
    final slot = size.width / n;
    final barW = math.max(2.0, slot * 0.62);
    final base = Paint()..color = NeoColors.ground;
    final fill = Paint()..color = color;
    final today = Paint()..color = NeoColors.ink;

    for (var i = 0; i < n; i++) {
      final x = i * slot + (slot - barW) / 2;
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x, 0, barW, chartH), const Radius.circular(3)), base);
      if (maxV > 0 && values[i] > 0) {
        final h = math.max(3.0, values[i] / maxV * chartH);
        canvas.drawRRect(
          RRect.fromRectAndRadius(Rect.fromLTWH(x, chartH - h, barW, h), const Radius.circular(3)),
          highlightDay == i + 1 ? today : fill,
        );
      }
    }
    final style = const TextStyle(color: NeoColors.muted, fontSize: 10);
    for (final d in [1, 8, 15, 22, n]) {
      final tp = TextPainter(text: TextSpan(text: '$d', style: style), textDirection: TextDirection.ltr)..layout();
      final cx = (d - 1) * slot + slot / 2 - tp.width / 2;
      tp.paint(canvas, Offset(cx.clamp(0, size.width - tp.width).toDouble(), chartH + 4));
    }
    if (maxV == 0) {
      final tp = TextPainter(
        text: const TextSpan(text: 'No spending yet this month', style: TextStyle(color: NeoColors.muted, fontSize: 13)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset((size.width - tp.width) / 2, chartH / 2 - tp.height / 2));
    }
  }

  @override
  bool shouldRepaint(covariant _DailyBars old) => old.values != values || old.color != color || old.highlightDay != highlightDay;
}
