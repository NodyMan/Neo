import 'package:flutter/material.dart';

import '../neo/neo_brain.dart';
import '../theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _set(BuildContext context, String key, Object value) async {
    try {
      await neo.saveSetting(key, value);
    } catch (e) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Not saved: $e')));
    }
  }

  Future<void> _kill(BuildContext context, bool on) async {
    if (!on) return _set(context, 'kill_switch', false);
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Stop Neo?'),
        content: const Text('Neo will stop taking any actions until you turn this off. It can still read and chat.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Stop Neo')),
        ],
      ),
    );
    if (ok == true && context.mounted) await _set(context, 'kill_switch', true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListenableBuilder(
        listenable: neo,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
          children: [
            SoftCard(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(
                children: [
                  SwitchListTile(
                    secondary: Icon(Icons.pan_tool_outlined, color: neo.killSwitch ? NeoColors.danger : null),
                    title: const Text('Kill switch'),
                    subtitle: Text(neo.killSwitch ? 'Neo is stopped — no actions will run' : 'Neo is running'),
                    value: neo.killSwitch,
                    onChanged: (v) => _kill(context, v),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            SoftCard(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(
                children: [
                  SwitchListTile(
                    secondary: const Icon(Icons.record_voice_over_outlined),
                    title: const Text('Speak replies aloud'),
                    subtitle: const Text('Voice messages are always answered out loud'),
                    value: neo.voiceReplies,
                    onChanged: (v) => _set(context, 'voice_replies', v),
                  ),
                  ListTile(
                    leading: const Icon(Icons.graphic_eq_rounded),
                    title: const Text('Neo\'s voice'),
                    subtitle: const Text('Male by default · pick any voice on your phone'),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const VoicePickerScreen())),
                  ),
                  ListTile(
                    leading: const Icon(Icons.translate),
                    title: const Text('Neo\'s voice language'),
                    trailing: DropdownButton<String>(
                      value: const ['same_as_user', 'uz', 'ru', 'en'].contains(neo.replyLanguage) ? neo.replyLanguage : 'same_as_user',
                      underline: const SizedBox.shrink(),
                      items: const [
                        DropdownMenuItem(value: 'same_as_user', child: Text('Auto')),
                        DropdownMenuItem(value: 'uz', child: Text('Oʻzbekcha')),
                        DropdownMenuItem(value: 'ru', child: Text('Русский')),
                        DropdownMenuItem(value: 'en', child: Text('English')),
                      ],
                      onChanged: (v) => v == null ? null : _set(context, 'reply_language', v),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            SoftCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Neo\'s colour', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      for (var i = 0; i < NeoColors.accents.length; i++)
                        Padding(
                          padding: const EdgeInsets.only(right: 12),
                          child: Semantics(
                            button: true,
                            selected: neo.color == NeoColors.accents[i],
                            label: ['Coral', 'Sage', 'Butter', 'Periwinkle'][i],
                            child: GestureDetector(
                              onTap: () => _set(context, 'neo_color', i),
                              child: Container(
                                width: 48,
                                height: 48,
                                decoration: BoxDecoration(
                                  color: NeoColors.accents[i],
                                  shape: BoxShape.circle,
                                  border: Border.all(color: neo.color == NeoColors.accents[i] ? NeoColors.ink : Colors.transparent, width: 3),
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            SoftCard(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: ListTile(
                leading: const Icon(Icons.logout),
                title: const Text('Sign out'),
                subtitle: Text(supabase.auth.currentUser?.email ?? ''),
                onTap: () async {
                  await supabase.auth.signOut();
                  if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Choose Neo's voice for each language and its pitch.
class VoicePickerScreen extends StatefulWidget {
  const VoicePickerScreen({super.key});

  @override
  State<VoicePickerScreen> createState() => _VoicePickerScreenState();
}

class _VoicePickerScreenState extends State<VoicePickerScreen> {
  static const _langs = {
    'ru': ('Русский', 'ru-RU', 'Привет, Макс! Я Нео, твоя правая рука.'),
    'en': ('English', 'en-US', 'Hi Max, I am Neo, your right hand.'),
    'uz': ('Oʻzbekcha', 'uz-UZ', 'Salom Maks! Men Neo, sizning yordamchingizman.'),
  };
  String _lang = 'ru';
  late Future<List<Map<String, String>>> _voices = neo.voicesFor(_lang);
  late double _pitch = neo.ttsPitch;

  void _setLang(String l) => setState(() {
        _lang = l;
        _voices = neo.voicesFor(l);
      });

  @override
  Widget build(BuildContext context) {
    final info = _langs[_lang]!;
    return Scaffold(
      appBar: AppBar(title: const Text('Neo\'s voice')),
      body: ListenableBuilder(
        listenable: neo,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
          children: [
            SegmentedButton<String>(
              segments: [for (final e in _langs.entries) ButtonSegment(value: e.key, label: Text(e.value.$1))],
              selected: {_lang},
              onSelectionChanged: (s) => _setLang(s.first),
              style: SegmentedButton.styleFrom(
                selectedBackgroundColor: NeoColors.ink,
                selectedForegroundColor: NeoColors.onInk,
                backgroundColor: NeoColors.card,
              ),
            ),
            const SizedBox(height: 12),
            SoftCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Pitch · ${_pitch.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w700)),
                  const Text('Lower sounds deeper', style: TextStyle(color: NeoColors.muted, fontSize: 12)),
                  Slider(
                    value: _pitch,
                    min: 0.6,
                    max: 1.2,
                    divisions: 12,
                    activeColor: NeoColors.ink,
                    onChanged: (v) => setState(() => _pitch = v),
                    onChangeEnd: (v) {
                      neo.ttsPitch = v;
                      neo.saveSetting('tts_pitch', v);
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            FutureBuilder<List<Map<String, String>>>(
              future: _voices,
              builder: (context, snap) {
                if (!snap.hasData) return const Padding(padding: EdgeInsets.all(24), child: Center(child: CircularProgressIndicator()));
                final vs = snap.data!;
                if (vs.isEmpty) {
                  return SoftCard(
                    child: Text(
                      _lang == 'uz'
                          ? 'Your phone has no Uzbek voice. Neo will speak Uzbek text with a Russian voice. You can install more voices in Android Settings → Text-to-speech.'
                          : 'No voices found for this language. Install voices in Android Settings → Text-to-speech.',
                      style: const TextStyle(color: NeoColors.muted),
                    ),
                  );
                }
                final chosen = neo.ttsVoices[info.$2];
                return SoftCard(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Column(
                    children: [
                      for (var i = 0; i < vs.length; i++)
                        ListTile(
                          leading: Icon(
                            (chosen == null ? (i == 0 && NeoBrain.looksMale(vs[i]['name']!)) : chosen == vs[i]['name'])
                                ? Icons.radio_button_checked_rounded
                                : Icons.radio_button_off_rounded,
                          ),
                          title: Text('Voice ${i + 1}${NeoBrain.looksMale(vs[i]['name']!) ? ' · male' : ''}',
                              style: const TextStyle(fontWeight: FontWeight.w600)),
                          subtitle: Text(vs[i]['name']!, style: const TextStyle(fontSize: 11, color: NeoColors.muted)),
                          trailing: IconButton(
                            tooltip: 'Play sample',
                            icon: const Icon(Icons.play_arrow_rounded),
                            onPressed: () => neo.previewVoice(vs[i]['name']!, vs[i]['locale']!, info.$3),
                          ),
                          onTap: () {
                            neo.chooseVoice(info.$2, vs[i]['name']!);
                            neo.previewVoice(vs[i]['name']!, vs[i]['locale']!, info.$3);
                          },
                        ),
                    ],
                  ),
                );
              },
            ),
            const SizedBox(height: 12),
            const Text(
              'Tip: voices marked "male" are a best guess from their names. Tap ▶ to listen and pick the one you like.',
              style: TextStyle(color: NeoColors.muted, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
