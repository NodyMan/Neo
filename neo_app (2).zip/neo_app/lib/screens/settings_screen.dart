import 'package:flutter/material.dart';

import '../neo/neo_brain.dart';
import '../neo/phone.dart';
import '../config.dart';
import '../theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _set(BuildContext context, String key, Object value) async {
    try {
      await neo.saveSetting(key, value);
    } catch (e) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Not saved: $e')));
    }
  }

  Future<void> _kill(BuildContext context, bool on) async {
    if (!on) return _set(context, 'kill_switch', false);
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Stop Neo?'),
        content: const Text('Neo will stop taking any actions until you turn this off. It can still read and chat.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Stop Neo')),
        ],
      ),
    );
    if (ok == true && context.mounted) await _set(context, 'kill_switch', true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListenableBuilder(
        listenable: neo,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
          children: [
            SoftCard(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(
                children: [
                  SwitchListTile(
                    secondary: Icon(Icons.pan_tool_outlined, color: neo.killSwitch ? NeoColors.danger : null),
                    title: const Text('Kill switch'),
                    subtitle: Text(neo.killSwitch ? 'Neo is stopped — no actions will run' : 'Neo is running'),
                    value: neo.killSwitch,
                    onChanged: (v) => _kill(context, v),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            const _ControlCard(),
            const SizedBox(height: 12),
            SoftCard(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(
                children: [
                  SwitchListTile(
                    secondary: const Icon(Icons.record_voice_over_outlined),
                    title: const Text('Speak replies aloud'),
                    subtitle: const Text('Voice messages are always answered out loud'),
                    value: neo.voiceReplies,
                    onChanged: (v) => _set(context, 'voice_replies', v),
                  ),
                  ListTile(
                    leading: const Icon(Icons.graphic_eq_rounded),
                    title: const Text('Neo\'s voice'),
                    subtitle: Text('${neo.geminiVoice} · male voice'),
                    trailing: const Icon(Icons.chevron_right_rounded),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const VoicePickerScreen())),
                  ),
                  SwitchListTile(
                    secondary: const Icon(Icons.hearing_rounded),
                    title: const Text('"Hey Neo" hands-free'),
                    subtitle: const Text('Neo listens while the app is open and the screen stays on'),
                    value: neo.handsFree,
                    onChanged: (v) => neo.setHandsFree(v),
                  ),
                  ListTile(
                    leading: const Icon(Icons.record_voice_over_rounded),
                    title: const Text('Hands-free language'),
                    subtitle: const Text('The language you speak after "Hey Neo"'),
                    trailing: DropdownButton<String>(
                      value: const ['en-US', 'ru-RU', 'uz-UZ'].contains(neo.wakeLang) ? neo.wakeLang : 'en-US',
                      underline: const SizedBox.shrink(),
                      items: const [
                        DropdownMenuItem(value: 'en-US', child: Text('English')),
                        DropdownMenuItem(value: 'ru-RU', child: Text('Русский')),
                        DropdownMenuItem(value: 'uz-UZ', child: Text('Oʻzbekcha')),
                      ],
                      onChanged: (v) {
                        if (v == null) return;
                        neo.wakeLang = v;
                        _set(context, 'wake_lang', v);
                      },
                    ),
                  ),
                  ListTile(
                    leading: const Icon(Icons.translate),
                    title: const Text('Reply language'),
                    subtitle: const Text('Auto = same as you'),
                    trailing: DropdownButton<String>(
                      value: const ['same_as_user', 'uz', 'ru', 'en'].contains(neo.replyLanguage) ? neo.replyLanguage : 'same_as_user',
                      underline: const SizedBox.shrink(),
                      items: const [
                        DropdownMenuItem(value: 'same_as_user', child: Text('Auto')),
                        DropdownMenuItem(value: 'uz', child: Text('Oʻzbekcha')),
                        DropdownMenuItem(value: 'ru', child: Text('Русский')),
                        DropdownMenuItem(value: 'en', child: Text('English')),
                      ],
                      onChanged: (v) => v == null ? null : _set(context, 'reply_language', v),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            SoftCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Neo\'s colour', style: TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      for (var i = 0; i < NeoColors.accents.length; i++)
                        Padding(
                          padding: const EdgeInsets.only(right: 12),
                          child: Semantics(
                            button: true,
                            selected: neo.color == NeoColors.accents[i],
                            label: ['Coral', 'Sage', 'Butter', 'Periwinkle'][i],
                            child: GestureDetector(
                              onTap: () => _set(context, 'neo_color', i),
                              child: Container(
                                width: 48,
                                height: 48,
                                decoration: BoxDecoration(
                                  color: NeoColors.accents[i],
                                  shape: BoxShape.circle,
                                  border: Border.all(color: neo.color == NeoColors.accents[i] ? NeoColors.ink : Colors.transparent, width: 3),
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            SoftCard(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: ListTile(
                leading: const Icon(Icons.logout),
                title: const Text('Sign out'),
                subtitle: Text(supabase.auth.currentUser?.email ?? ''),
                onTap: () async {
                  await supabase.auth.signOut();
                  if (context.mounted) Navigator.of(context).popUntil((r) => r.isFirst);
                },
              ),
            ),
            const SizedBox(height: 16),
            const Center(child: Text('Neo app $neoAppVersion', style: TextStyle(color: NeoColors.muted, fontSize: 12))),
          ],
        ),
      ),
    );
  }
}

/// Pick Neo's voice from Google Gemini's male voices. Tap to hear it.
class VoicePickerScreen extends StatefulWidget {
  const VoicePickerScreen({super.key});

  @override
  State<VoicePickerScreen> createState() => _VoicePickerScreenState();
}

class _VoicePickerScreenState extends State<VoicePickerScreen> {
  String? _loading;

  Future<void> _pick(String v) async {
    setState(() => _loading = v);
    await neo.chooseVoice(v);
    final ok = await neo.previewVoice(v);
    if (!mounted) return;
    setState(() => _loading = null);
    if (!ok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Saved. Could not play a sample right now — try again in a minute.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Neo\'s voice')),
      body: ListenableBuilder(
        listenable: neo,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(4, 0, 4, 12),
              child: Text(
                'Male voices. They speak Russian, Uzbek and English. Tap one to hear it — it becomes Neo\'s voice.',
                style: TextStyle(color: NeoColors.muted),
              ),
            ),
            SoftCard(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Column(
                children: [
                  for (final (name, vibe) in NeoBrain.geminiVoices)
                    ListTile(
                      leading: Icon(
                        neo.geminiVoice == name ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                        color: neo.geminiVoice == name ? NeoColors.ink : NeoColors.muted,
                      ),
                      title: Text(name, style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text(vibe, style: const TextStyle(color: NeoColors.muted)),
                      trailing: _loading == name
                          ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5))
                          : const Icon(Icons.play_arrow_rounded),
                      onTap: _loading == null ? () => _pick(name) : null,
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Everything Neo needs to really control the phone, with live status. Re-checks when you come back from Android settings.
class _ControlCard extends StatefulWidget {
  const _ControlCard();

  @override
  State<_ControlCard> createState() => _ControlCardState();
}

class _ControlCardState extends State<_ControlCard> with WidgetsBindingObserver {
  Map<String, bool> _c = const {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _refresh();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refresh();
  }

  Future<void> _refresh() async {
    final c = await Phone.control();
    if (mounted) setState(() => _c = c);
  }

  Widget _row(IconData icon, String title, String sub, bool on, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: on ? NeoColors.good : NeoColors.muted),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text(on ? 'On' : sub, style: TextStyle(color: on ? NeoColors.good : NeoColors.muted)),
      trailing: Icon(on ? Icons.check_circle_rounded : Icons.chevron_right_rounded, color: on ? NeoColors.good : null),
      onTap: onTap,
    );
  }

  @override
  Widget build(BuildContext context) {
    final all = (_c['accessibility'] ?? false) && (_c['overlay'] ?? false) && (_c['notifications'] ?? false) && neo.wakeBackground;
    return SoftCard(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
            child: Text(all ? 'Full control — all set' : 'Give Neo full control',
                style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 0, 16, 4),
            child: Text(
              'If Android blocks a switch ("restricted setting"): long-press the Neo icon → App info → ⋮ → Allow restricted settings, then try again.',
              style: TextStyle(color: NeoColors.muted, fontSize: 12),
            ),
          ),
          SwitchListTile(
            secondary: Icon(Icons.hearing_rounded, color: neo.wakeBackground ? NeoColors.good : NeoColors.muted),
            title: const Text('"Hey Neo" anytime', style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: const Text('Works with Neo closed, like "OK Google"'),
            value: neo.wakeBackground,
            onChanged: (v) async {
              await neo.setWakeBackground(v);
              _refresh();
            },
          ),
          _row(Icons.touch_app_rounded, 'Control the screen', 'Tap, type, send, install — Accessibility → Neo → On',
              _c['accessibility'] ?? false, Phone.openAccessibility),
          _row(Icons.open_in_new_rounded, 'Pop up over apps', 'So "Hey Neo" can open Neo from anywhere', _c['overlay'] ?? false,
              Phone.openOverlay),
          _row(Icons.notifications_active_outlined, 'Read notifications', 'For "What did I miss?" and bank tracking',
              _c['notifications'] ?? false, () => Phone.run({'action': 'notification_access'})),
          ListTile(
            leading: const Icon(Icons.battery_saver_rounded, color: NeoColors.muted),
            title: const Text('Keep Neo awake', style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: const Text('Allow "no battery limits" so Android doesn\'t stop "Hey Neo"'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: Phone.openBattery,
          ),
          SwitchListTile(
            secondary: const Icon(Icons.send_rounded),
            title: const Text('Press Send for me', style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: const Text('Neo sends messages himself (needs Control the screen)'),
            value: neo.autoSend,
            onChanged: (v) {
              neo.autoSend = v;
              neo.saveSetting('auto_send', v);
              setState(() {});
            },
          ),
          const ListTile(
            leading: Icon(Icons.assistant_rounded, color: NeoColors.muted),
            title: Text('Make Neo your Assistant button', style: TextStyle(fontWeight: FontWeight.w700)),
            subtitle: Text('Android Settings → Apps → Default apps → Digital assistant → Neo (if your phone offers it)'),
          ),
        ],
      ),
    );
  }
}
