import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';

/// Talks to Neo's Android side (MainActivity.kt): runs phone actions,
/// plays Neo's Gemini voice, and passes home-screen shortcuts.
class Phone {
  Phone._();
  static const _ch = MethodChannel('neo/phone');

  /// Called when a home-screen shortcut is tapped while Neo is already open.
  static void Function(String shortcut)? onShortcut;

  /// "Hey Neo" from the background / Assistant button while Neo is already open: (command, listen).
  static void Function(String command, bool listen)? onCommand;

  /// Speech recognizer events: type = ready, begin, level, partial, final, error, end.
  static final speechEvents = StreamController<SpeechEvent>.broadcast();

  static void init() {
    _ch.setMethodCallHandler((call) async {
      if (call.method == 'shortcut' && call.arguments is String) onShortcut?.call(call.arguments as String);
      if (call.method == 'command' && call.arguments is Map) {
        final m = call.arguments as Map;
        onCommand?.call((m['command'] ?? '').toString(), m['listen'] == true);
      }
      if (call.method == 'speech' && call.arguments is Map) {
        final m = call.arguments as Map;
        speechEvents.add(SpeechEvent(
          (m['type'] ?? '').toString(),
          (m['text'] ?? '').toString(),
          (m['code'] as num?)?.toInt() ?? 0,
          (m['level'] as num?)?.toDouble() ?? 0,
        ));
      }
      return null;
    });
  }

  // ---- Android speech recognizer (hands-free "Hey Neo", offline voice) ----

  static Future<bool> speechAvailable() async {
    try {
      return await _ch.invokeMethod<bool>('srAvailable') ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> speechStart({required bool continuous, String lang = '', bool offline = false}) async {
    try {
      await _ch.invokeMethod('srStart', {'continuous': continuous, 'lang': lang, 'offline': offline});
    } catch (_) {}
  }

  /// Finish the current phrase (a final result still arrives), then stop.
  static Future<void> speechStop() async {
    try {
      await _ch.invokeMethod('srStop');
    } catch (_) {}
  }

  static Future<void> speechCancel() async {
    try {
      await _ch.invokeMethod('srCancel');
    } catch (_) {}
  }

  // ---- notifications (needs "Notification access" for Neo in Android settings) ----

  static Future<bool> notificationAccess() async {
    try {
      return await _ch.invokeMethod<bool>('notifAccess') ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Notifications posted after [sinceMs] (epoch ms): {app, pkg, title, text, ts}.
  static Future<List<Map<String, dynamic>>> notificationsSince(int sinceMs) async {
    try {
      final raw = await _ch.invokeMethod<String>('notifications', {'since': sinceMs});
      if (raw == null || raw.isEmpty) return const [];
      return (jsonDecode(raw) as List).whereType<Map>().map((m) => Map<String, dynamic>.from(m)).toList();
    } catch (_) {
      return const [];
    }
  }

  // ---- full control ----

  /// What Neo is allowed to do: accessibility (screen control), overlay (pop up), wake (background "Hey Neo"), notifications.
  static Future<Map<String, bool>> control() async {
    try {
      final m = await _ch.invokeMethod<Map>('control');
      return {for (final e in (m ?? {}).entries) e.key.toString(): e.value == true};
    } catch (_) {
      return const {};
    }
  }

  static Future<void> _call(String method, [Map<String, dynamic>? args]) async {
    try {
      await _ch.invokeMethod(method, args);
    } catch (_) {}
  }

  static Future<void> openAccessibility() => _call('openAccessibility');
  static Future<void> openOverlay() => _call('openOverlay');
  static Future<void> openBattery() => _call('openBattery');
  static Future<void> askPermissions() => _call('askPermissions');
  static Future<void> wakeStop() => _call('wakeStop');
  static Future<bool> wakeStart(String lang) async {
    try {
      return await _ch.invokeMethod<bool>('wakeStart', {'lang': lang}) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// The command Neo was opened with ("Hey Neo …" in the background, or the Assistant button).
  static Future<(String, bool)> launchCommand() async {
    try {
      final m = await _ch.invokeMethod<Map>('launchCommand');
      return ((m?['command'] ?? '').toString(), m?['listen'] == true);
    } catch (_) {
      return ('', false);
    }
  }

  static Future<void> keepScreenOn(bool on) async {
    try {
      await _ch.invokeMethod('keepScreenOn', {'on': on});
    } catch (_) {}
  }

  /// The shortcut Neo was launched with (once), e.g. 'talk' or 'expense'.
  static Future<String?> launchShortcut() async {
    try {
      return await _ch.invokeMethod<String>('shortcut');
    } catch (_) {
      return null;
    }
  }

  /// Runs one action from Neo, e.g. {action: 'open_app', target: 'Telegram', package: 'org.telegram.messenger'}.
  /// Returns 'ok' or a short reason.
  static Future<String> run(Map<String, dynamic> a, {bool autoSend = false}) async {
    final action = (a['action'] ?? a['type'] ?? '').toString();
    if (action.isEmpty) return 'no action';
    try {
      final r = await _ch.invokeMethod<String>('do', {
        'type': action,
        'target': (a['target'] ?? '').toString(),
        'package': (a['package'] ?? '').toString(),
        'extra': (a['extra'] ?? '').toString(),
        'subject': (a['subject'] ?? '').toString(),
        'auto': autoSend,
      });
      return r ?? 'ok';
    } on MissingPluginException {
      return 'not available';
    } catch (e) {
      return 'error';
    }
  }

  /// Plays audio bytes (WAV, or raw 16-bit PCM which gets a WAV header).
  /// Completes when playback ends or is stopped. Returns false if it could not play.
  static Future<bool> play(Uint8List bytes, {String? mime}) async {
    try {
      var data = bytes;
      final m = (mime ?? '').toLowerCase();
      final isRiff = data.length > 4 && data[0] == 0x52 && data[1] == 0x49 && data[2] == 0x46 && data[3] == 0x46;
      if (!isRiff && (m.contains('pcm') || m.contains('l16'))) {
        final rate = int.tryParse(RegExp(r'rate=(\d+)').firstMatch(m)?.group(1) ?? '') ?? 24000;
        data = _wav(data, rate);
      }
      final dir = await getTemporaryDirectory();
      final ext = m.contains('mpeg') || m.contains('mp3') ? 'mp3' : 'wav';
      final f = File('${dir.path}/neo_reply_${DateTime.now().millisecondsSinceEpoch % 4}.$ext');
      await f.writeAsBytes(data, flush: true);
      final ok = await _ch.invokeMethod<bool>('play', {'path': f.path});
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> stopAudio() async {
    try {
      await _ch.invokeMethod('stopAudio');
    } catch (_) {}
  }

  static Uint8List _wav(Uint8List pcm, int rate) {
    final h = ByteData(44);
    void str(int o, String s) {
      for (var i = 0; i < 4; i++) {
        h.setUint8(o + i, s.codeUnitAt(i));
      }
    }

    str(0, 'RIFF');
    h.setUint32(4, 36 + pcm.length, Endian.little);
    str(8, 'WAVE');
    str(12, 'fmt ');
    h.setUint32(16, 16, Endian.little);
    h.setUint16(20, 1, Endian.little);
    h.setUint16(22, 1, Endian.little);
    h.setUint32(24, rate, Endian.little);
    h.setUint32(28, rate * 2, Endian.little);
    h.setUint16(32, 2, Endian.little);
    h.setUint16(34, 16, Endian.little);
    str(36, 'data');
    h.setUint32(40, pcm.length, Endian.little);
    return Uint8List.fromList([...h.buffer.asUint8List(), ...pcm]);
  }
}

class SpeechEvent {
  const SpeechEvent(this.type, this.text, this.code, this.level);
  final String type;
  final String text;
  final int code;
  final double level;
}
