package uz.max.neo_app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

// "Hey Neo" in the background, like "OK Google": listens while Neo is closed, then opens Neo with the command.
class NeoWakeService : Service() {

    companion object {
        @Volatile
        var instance: NeoWakeService? = null
        const val CHANNEL = "neo_wake"
        private val WAKE = Regex("(?:^|[\\s,.!?])(?:(?:hey|hi|hello|ok|okay|эй|хей|привет|salom|ey)[\\s,]+)?(neo|nio|neyo|neho|нео|нио|неа|ниа)(?=$|[\\s,.!?])", RegexOption.IGNORE_CASE)

        fun start(ctx: Context, lang: String) {
            ctx.getSharedPreferences("neo", Context.MODE_PRIVATE).edit().putString("wake_lang", lang).putBoolean("wake_on", true).apply()
            val i = Intent(ctx, NeoWakeService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.getSharedPreferences("neo", Context.MODE_PRIVATE).edit().putBoolean("wake_on", false).apply()
            ctx.stopService(Intent(ctx, NeoWakeService::class.java))
        }
    }

    private val ui = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var running = false
    private var paused = false
    private var muted = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            startAsForeground()
        } catch (e: Exception) {
            // Android only allows a microphone service started from Neo's own screen.
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            running = true
            listen()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        ui.removeCallbacksAndMessages(null)
        unmute()
        try { recognizer?.destroy() } catch (e: Exception) { }
        recognizer = null
        instance = null
        super.onDestroy()
    }

    /** Neo's own screen is open — it listens by itself, so the service steps aside. */
    fun pause() {
        paused = true
        ui.removeCallbacksAndMessages(null)
        try { recognizer?.cancel() } catch (e: Exception) { }
        unmute()
    }

    fun resume() {
        if (!paused) return
        paused = false
        ui.postDelayed({ listen() }, 800)
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "Hey Neo", NotificationManager.IMPORTANCE_MIN)
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        val n = b.setContentTitle("Neo is listening")
            .setContentText("Say \"Hey Neo\" and what you need")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 30) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(7, n)
        }
    }

    // Some phones beep every time listening restarts; keep it quiet when no music is playing.
    private fun mute() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (!muted && !am.isMusicActive) {
            try {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                muted = true
            } catch (e: Exception) { }
        }
    }

    private fun unmute() {
        if (!muted) return
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0) } catch (e: Exception) { }
        muted = false
    }

    private fun again(delay: Long) {
        if (!running || paused) return
        ui.postDelayed({ if (running && !paused) listen() }, delay)
    }

    private fun listen() {
        if (!running || paused) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { stopSelf(); return }
        var r = recognizer
        if (r == null) {
            r = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { ui.postDelayed({ unmute() }, 350) }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) {
                    unmute()
                    when (error) {
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> stopSelf()
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> {
                            val old = recognizer
                            recognizer = null
                            try { old?.destroy() } catch (e: Exception) { }
                            again(1500)
                        }
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> again(250)
                        else -> again(3000)
                    }
                }
                override fun onResults(results: Bundle?) {
                    unmute()
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    if (!handle(text)) again(250)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }
        val lang = getSharedPreferences("neo", Context.MODE_PRIVATE).getString("wake_lang", "") ?: ""
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        if (lang.isNotEmpty()) i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
        try {
            mute()
            r.startListening(i)
        } catch (e: Exception) {
            unmute()
            again(3000)
        }
    }

    /** Heard "Hey Neo …": open Neo with the command. Returns true if Neo was opened. */
    private fun handle(text: String): Boolean {
        val m = WAKE.find(text.lowercase()) ?: return false
        val cmd = text.substring(minOf(m.range.last + 1, text.length)).trimStart(' ', ',', '.', '!', '?', ':', '-', '—').trim()
        val open = Intent(this, MainActivity::class.java)
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        if (cmd.isNotEmpty()) open.putExtra("neo_command", cmd) else open.putExtra("neo_listen", true)
        val canPop = Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(this)
        if (canPop) {
            try {
                startActivity(open)
                pause() // Neo's screen takes over; it resumes us when it goes to the background
                ui.postDelayed({ if (!MainActivity.visible) resume() }, 8000)
                return true
            } catch (e: Exception) {
            }
        }
        // Without "Display over other apps" Android won't let Neo pop up by itself: show a tap-to-open notification.
        notifyCommand(cmd, open)
        again(400)
        return true
    }

    private fun notifyCommand(cmd: String, open: Intent) {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel("neo_cmd") == null) {
                nm.createNotificationChannel(NotificationChannel("neo_cmd", "Neo commands", NotificationManager.IMPORTANCE_HIGH))
            }
            val pi = PendingIntent.getActivity(this, 11, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "neo_cmd") else Notification.Builder(this)
            val n = b.setContentTitle(if (cmd.isEmpty()) "Neo: yes?" else "Neo: tap to do it")
                .setContentText(if (cmd.isEmpty()) "Tap and tell me what you need" else cmd)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(8, n)
        } catch (e: Exception) {
        }
    }
}
