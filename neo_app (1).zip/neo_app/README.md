# Neo — Android app (v0.6, "Soft Day")

Max's admin app for Neo: a living, animated Neo you can talk to, who can now also control the phone.

## New in 0.6
- Fix: chat no longer breaks with "InvalidJWTToken / token expired" after the phone sleeps — Neo refreshes the login and reconnects by himself.
- Smarter, more natural Neo (Google Gemini brain, Groq as backup); talks like a person in Russian, Uzbek and English.
- Music: "play Eminem on Spotify", "next song", "pause", "louder".
- Messages: "write to Aziz on WhatsApp that I'm late" — Neo writes it and opens the chat ready to send. Telegram too.
- Reads notifications: turn on Settings → Read my notifications, then ask "What did I miss?". One-time codes are hidden.
- 5 voices only. App version shown at the bottom of Settings.
- The build picks the newest zip in the repo automatically (by app version).

## New in 0.5
- **"Hey Neo" hands-free.** Tap the ear button next to the text box (or Settings). While Neo is open, just say "Hey Neo, open Telegram" or "Hey Neo" … "set a timer for 10 minutes". The screen stays on while it listens. Choose the language you speak in Settings → Hands-free language.
- **Offline mode.** No internet? Timers, alarms, opening apps, calls, camera, settings and navigation still work (voice too, if your phone has offline speech). Everything else is saved and sent to Neo automatically when you're back online. Home keeps today's numbers.
- **Mood-aware.** Tap how you feel on Home, or just tell Neo. He notices on his own too. When you're stressed he's calmer, keeps things short, writes reminders gently and suggests better times.
- **Predictive.** "Neo noticed" on Home: bills you usually pay around this date but haven't yet, overdue and today's tasks, spending faster than your budget, unusual spending, stress. Tap one and Neo helps. Once a day he mentions the top one himself.

## New in 0.4
- **Neo controls your phone.** Ask by voice or text: open apps and websites, search Google or YouTube, call or text a number, set alarms and timers, navigate or find places on the map, open the camera or settings, share text. You've allowed all of these, so Neo just does them. The kill switch in Settings stops all actions.
- **A man's voice.** Neo speaks with Google Gemini voices (default: Charon). Settings → Neo's voice lists 14 male voices; tap one to hear it. The phone's own voice is only a backup.
- **Faster replies.** Neo's text shows up first, and his voice follows a moment later. Hold the mic while he talks to interrupt him.
- **Chat in the right order.** Your message always appears before Neo's answer.
- **Neo icon** instead of the Flutter logo.
- **Shortcuts**: long-press the Neo icon on your home screen → "Talk to Neo" or "Add expense".
- **Notes**: everything you ask Neo to remember ("remember that my passport expires in May"), searchable. Neo searches them too.
- **Home**: new quick asks, a Notes card and a "Phone control" cheat sheet.

## Build with GitHub (no PC setup)
1. In your repo **NodyMan/Neo**, delete the old zip and upload this `neo_app.zip`. Keep only one zip.
2. The build starts by itself (Actions tab). Wait ~10 minutes → **Releases** → download `app-release.apk` → install over the old Neo.

## Build on a PC
```
cd neo_app
bash tool/prepare_android.sh      # on Windows: run it in Git Bash
flutter pub get
flutter run                       # phone connected with USB debugging
```

No AI keys are in this app. It only holds the public Supabase key; the n8n backend only answers requests carrying Max's login.
