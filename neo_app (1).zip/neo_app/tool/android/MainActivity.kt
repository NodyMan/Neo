package uz.max.neo_app

import android.app.SearchManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.media.AudioManager
import android.view.KeyEvent
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.WindowManager
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

// Neo's Android side: phone actions, Neo's voice playback, home-screen shortcuts.
class MainActivity : FlutterActivity() {
    private var channel: MethodChannel? = null
    private var pendingShortcut: String? = null
    private var player: MediaPlayer? = null
    private var playResult: MethodChannel.Result? = null

    // speech recognition ("Hey Neo" hands-free mode, offline voice)
    private val ui = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var srActive = false
    private var srContinuous = false
    private var srLang = ""
    private var srOffline = false
    private var lastRms = 0L

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        pendingShortcut = intent?.getStringExtra("neo_shortcut")
        val ch = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "neo/phone")
        channel = ch
        ch.setMethodCallHandler { call, result ->
            when (call.method) {
                "do" -> {
                    val r = try {
                        doAction(
                            call.argument<String>("type") ?: "",
                            call.argument<String>("target") ?: "",
                            call.argument<String>("package") ?: "",
                            call.argument<String>("extra") ?: ""
                        )
                    } catch (e: Exception) {
                        "error: " + (e.message ?: "unknown")
                    }
                    result.success(r)
                }
                "play" -> play(call.argument<String>("path") ?: "", result)
                "stopAudio" -> {
                    stopPlayer()
                    result.success(true)
                }
                "shortcut" -> {
                    result.success(pendingShortcut)
                    pendingShortcut = null
                }
                "srAvailable" -> result.success(SpeechRecognizer.isRecognitionAvailable(this))
                "notifAccess" -> {
                    val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
                    result.success(enabled.contains(packageName))
                }
                "notifications" -> {
                    val since = (call.argument<Number>("since") ?: 0).toLong()
                    result.success(NeoNotes.since(this, since))
                }
                "srStart" -> {
                    srContinuous = call.argument<Boolean>("continuous") ?: false
                    srLang = call.argument<String>("lang") ?: ""
                    srOffline = call.argument<Boolean>("offline") ?: false
                    srActive = true
                    srListen()
                    result.success(true)
                }
                "srStop" -> {
                    // finish the current phrase (results still arrive), no restart
                    srContinuous = false
                    try { recognizer?.stopListening() } catch (e: Exception) { }
                    result.success(true)
                }
                "srCancel" -> {
                    srCancel()
                    result.success(true)
                }
                "keepScreenOn" -> {
                    if (call.argument<Boolean>("on") == true) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val s = intent.getStringExtra("neo_shortcut")
        if (s != null) channel?.invokeMethod("shortcut", s)
    }

    override fun onDestroy() {
        stopPlayer()
        srCancel()
        super.onDestroy()
    }

    // ---------- speech recognition ----------

    private fun speechEvent(type: String, text: String = "", code: Int = 0, level: Double = 0.0) {
        channel?.invokeMethod("speech", mapOf("type" to type, "text" to text, "code" to code, "level" to level))
    }

    private fun srCancel() {
        srActive = false
        srContinuous = false
        ui.removeCallbacksAndMessages(null)
        val r = recognizer
        recognizer = null
        if (r != null) {
            try { r.cancel() } catch (e: Exception) { }
            try { r.destroy() } catch (e: Exception) { }
        }
    }

    private fun srRestart(delayMs: Long) {
        if (!srActive || !srContinuous) {
            srActive = false
            speechEvent("end")
            return
        }
        ui.postDelayed({ if (srActive) srListen() }, delayMs)
    }

    private fun srListen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            srActive = false
            speechEvent("error", "Speech recognition is not available on this phone", -1)
            return
        }
        var r = recognizer
        if (r == null) {
            r = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { speechEvent("ready") }
                override fun onBeginningOfSpeech() { speechEvent("begin") }
                override fun onRmsChanged(rmsdB: Float) {
                    val now = System.currentTimeMillis()
                    if (now - lastRms > 100) {
                        lastRms = now
                        speechEvent("level", level = ((rmsdB + 2.0) / 12.0).coerceIn(0.0, 1.0))
                    }
                }
                override fun onBufferReceived(buffer: ByteArray?) { }
                override fun onEndOfSpeech() { speechEvent("endOfSpeech") }
                override fun onError(error: Int) {
                    speechEvent("error", "", error)
                    when (error) {
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { srActive = false; speechEvent("end") }
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> {
                            val old = recognizer
                            recognizer = null
                            try { old?.destroy() } catch (e: Exception) { }
                            srRestart(600)
                        }
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> srRestart(150)
                        else -> srRestart(1200)
                    }
                }
                override fun onResults(results: Bundle?) {
                    val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    speechEvent("final", list?.firstOrNull() ?: "")
                    srRestart(200)
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val t = list?.firstOrNull() ?: ""
                    if (t.isNotEmpty()) speechEvent("partial", t)
                }
                override fun onEvent(eventType: Int, params: Bundle?) { }
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        if (srLang.isNotEmpty()) i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, srLang)
        if (srOffline) i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        if (srContinuous) {
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
        }
        try {
            r.startListening(i)
        } catch (e: Exception) {
            speechEvent("error", e.message ?: "", -2)
            srRestart(1200)
        }
    }

    // ---------- voice playback ----------

    private fun finishPlay(ok: Boolean) {
        val r = playResult
        playResult = null
        r?.success(ok)
    }

    private fun releasePlayer() {
        val p = player
        player = null
        if (p != null) {
            try { p.stop() } catch (e: Exception) { }
            try { p.release() } catch (e: Exception) { }
        }
    }

    private fun stopPlayer() {
        releasePlayer()
        finishPlay(false)
    }

    private fun play(path: String, result: MethodChannel.Result) {
        stopPlayer()
        playResult = result
        try {
            val p = MediaPlayer()
            player = p
            p.setDataSource(path)
            p.setOnCompletionListener {
                releasePlayer()
                finishPlay(true)
            }
            p.setOnErrorListener { _, _, _ ->
                releasePlayer()
                finishPlay(false)
                true
            }
            p.prepare()
            p.start()
        } catch (e: Exception) {
            releasePlayer()
            finishPlay(false)
        }
    }

    // ---------- phone actions ----------

    private fun start(i: Intent): String {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            startActivity(i)
            "ok"
        } catch (e: ActivityNotFoundException) {
            "no app can do that"
        } catch (e: SecurityException) {
            "not allowed"
        }
    }

    private fun view(u: String): String = start(Intent(Intent.ACTION_VIEW, Uri.parse(u)))

    private fun enc(s: String): String = Uri.encode(s)

    private fun digits(s: String): String = s.filter { it.isDigit() || it == '+' }

    private fun doAction(type: String, target: String, pkg: String, extra: String): String {
        return when (type) {
            "open_app" -> openApp(target, pkg)
            "open_url" -> view(if (target.startsWith("http")) target else "https://$target")
            "web_search" -> view("https://www.google.com/search?q=" + enc(target))
            "youtube" -> view("https://www.youtube.com/results?search_query=" + enc(target))
            "call" -> start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + digits(target))))
            "sms" -> {
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + digits(target)))
                i.putExtra("sms_body", extra)
                start(i)
            }
            "alarm" -> {
                val m = Regex("(\\d{1,2})[:.](\\d{2})").find(target)
                val h = m?.groupValues?.get(1)?.toIntOrNull() ?: target.filter { it.isDigit() }.take(2).toIntOrNull() ?: 7
                val min = m?.groupValues?.get(2)?.toIntOrNull() ?: 0
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                i.putExtra(AlarmClock.EXTRA_HOUR, h.coerceIn(0, 23))
                i.putExtra(AlarmClock.EXTRA_MINUTES, min.coerceIn(0, 59))
                i.putExtra(AlarmClock.EXTRA_MESSAGE, extra.ifEmpty { "Neo" })
                i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                start(i)
            }
            "timer" -> {
                val secs = target.filter { it.isDigit() }.toIntOrNull() ?: 60
                val i = Intent(AlarmClock.ACTION_SET_TIMER)
                i.putExtra(AlarmClock.EXTRA_LENGTH, secs.coerceIn(1, 86400))
                i.putExtra(AlarmClock.EXTRA_MESSAGE, extra.ifEmpty { "Neo" })
                i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                start(i)
            }
            "navigate" -> {
                val r = view("google.navigation:q=" + enc(target))
                if (r == "ok") r else view("geo:0,0?q=" + enc(target))
            }
            "map_search" -> view("geo:0,0?q=" + enc(target))
            "camera" -> start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            "settings" -> {
                val t = target.lowercase()
                val action = when {
                    t.contains("wi") -> Settings.ACTION_WIFI_SETTINGS
                    t.contains("blue") -> Settings.ACTION_BLUETOOTH_SETTINGS
                    t.contains("display") || t.contains("bright") -> Settings.ACTION_DISPLAY_SETTINGS
                    t.contains("sound") || t.contains("volume") -> Settings.ACTION_SOUND_SETTINGS
                    t.contains("batter") -> Intent.ACTION_POWER_USAGE_SUMMARY
                    t.contains("locat") || t.contains("gps") -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                    t.contains("app") -> Settings.ACTION_APPLICATION_SETTINGS
                    else -> Settings.ACTION_SETTINGS
                }
                start(Intent(action))
            }
            "play_music" -> playMusic(target, pkg)
            "media" -> media(target)
            "send_message" -> sendMessage(target, pkg, extra)
            "copy_text" -> {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Neo", target))
                "ok"
            }
            "notification_access" -> start(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            "share_text" -> {
                val send = Intent(Intent.ACTION_SEND)
                send.type = "text/plain"
                send.putExtra(Intent.EXTRA_TEXT, target)
                start(Intent.createChooser(send, "Share"))
            }
            else -> "unknown action"
        }
    }

    private fun musicPackage(p: String): String {
        val s = p.lowercase()
        return when {
            s.contains("spotify") -> "com.spotify.music"
            s.contains("yandex") || s.contains("яндекс") -> "ru.yandex.music"
            s.contains("youtube music") || s.contains("yt music") || s == "com.google.android.apps.youtube.music" -> "com.google.android.apps.youtube.music"
            s.contains("youtube") -> "com.google.android.youtube"
            s.contains(".") -> p
            else -> ""
        }
    }

    private fun playMusic(query: String, app: String): String {
        val pkg = musicPackage(app)
        if (pkg == "com.google.android.youtube") return view("https://www.youtube.com/results?search_query=" + enc(query))
        val i = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
        i.putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
        i.putExtra(SearchManager.QUERY, query)
        if (pkg.isNotEmpty()) i.setPackage(pkg)
        val r = start(i)
        if (r == "ok") return r
        if (pkg == "com.spotify.music") {
            val s = view("spotify:search:" + enc(query))
            if (s == "ok") return s
        }
        val m = view("https://music.youtube.com/search?q=" + enc(query))
        return if (m == "ok") m else view("https://www.youtube.com/results?search_query=" + enc(query))
    }

    private fun media(cmd: String): String {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val c = cmd.lowercase()
        fun key(code: Int): String {
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
            return "ok"
        }
        return when {
            c.contains("next") || c.contains("skip") -> key(KeyEvent.KEYCODE_MEDIA_NEXT)
            c.contains("prev") || c.contains("back") -> key(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            c.contains("pause") || c.contains("stop") -> key(KeyEvent.KEYCODE_MEDIA_PAUSE)
            c == "play" || c.contains("resume") -> key(KeyEvent.KEYCODE_MEDIA_PLAY)
            c.contains("volume_up") || c.contains("louder") || c == "up" -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); "ok"
            }
            c.contains("volume_down") || c.contains("quieter") || c == "down" -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); "ok"
            }
            c.contains("unmute") -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI); "ok"
            }
            c.contains("mute") -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); "ok"
            }
            else -> key(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        }
    }

    private fun uzPhone(t: String): String {
        var d = t.filter { it.isDigit() }
        if (d.length == 9) d = "998$d"
        return d
    }

    private fun sendMessage(to: String, app: String, text: String): String {
        val a = app.lowercase()
        if (a.contains("whatsapp")) {
            val d = uzPhone(to)
            if (d.length >= 10) return view("https://wa.me/$d?text=" + enc(text))
            val i = Intent(Intent.ACTION_SEND)
            i.type = "text/plain"
            i.putExtra(Intent.EXTRA_TEXT, text)
            i.setPackage("com.whatsapp")
            return start(i)
        }
        if (a.contains("sms")) {
            val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + digits(to)))
            i.putExtra("sms_body", text)
            return start(i)
        }
        // Telegram: open the chat if we know the username, text is copied so Max can paste;
        // otherwise Telegram's chat picker opens with the text ready.
        val user = to.trim().removePrefix("@")
        if (user.isNotEmpty() && user.all { it.isLetterOrDigit() || it == '_' } && !user.all { it.isDigit() }) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Neo", text))
            return view("https://t.me/$user")
        }
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(Intent.EXTRA_TEXT, text)
        i.setPackage("org.telegram.messenger")
        val r = start(i)
        return if (r == "ok") r else view("https://t.me/share/url?url=%20&text=" + enc(text))
    }

    private fun openApp(name: String, pkg: String): String {
        val pm = packageManager
        if (pkg.isNotEmpty()) {
            val li = pm.getLaunchIntentForPackage(pkg)
            if (li != null) return start(li)
        }
        val n = name.lowercase().trim()
        if (n.isNotEmpty()) {
            val main = Intent(Intent.ACTION_MAIN)
            main.addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(main, 0)
            val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
                ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
            if (hit != null) {
                val li = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
                if (li != null) return start(li)
            }
        }
        val store = if (pkg.isNotEmpty()) "market://details?id=$pkg" else "market://search?q=" + enc(name)
        val r = view(store)
        return if (r == "ok") "not installed, opened Play Store" else r
    }
}
