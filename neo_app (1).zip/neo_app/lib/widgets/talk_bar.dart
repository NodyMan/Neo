import 'package:flutter/material.dart';

import '../neo/neo_brain.dart';
import '../theme.dart';

/// Text box + hold-to-talk mic. Typing shows a send button instead of the mic.
class TalkBar extends StatefulWidget {
  const TalkBar({super.key, this.hint = 'Ask Neo anything…'});
  final String hint;

  @override
  State<TalkBar> createState() => _TalkBarState();
}

class _TalkBarState extends State<TalkBar> {
  final _text = TextEditingController();
  bool _hasText = false;

  @override
  void initState() {
    super.initState();
    _text.addListener(() {
      final has = _text.text.trim().isNotEmpty;
      if (has != _hasText) setState(() => _hasText = has);
    });
  }

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final t = _text.text;
    if (t.trim().isEmpty || neo.isBusy) return;
    _text.clear();
    FocusScope.of(context).unfocus();
    await neo.sendText(t);
  }

  Future<void> _holdStart() async {
    final ok = await neo.startListening();
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Neo needs microphone permission to hear you.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: neo,
      builder: (context, _) {
        final listening = neo.isListening;
        return Row(
          children: [
            Semantics(
              button: true,
              toggled: neo.handsFree,
              label: 'Hey Neo hands-free mode',
              child: Tooltip(
                message: neo.handsFree ? 'Hands-free on — say "Hey Neo"' : 'Turn on "Hey Neo"',
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: () => neo.setHandsFree(!neo.handsFree),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: neo.handsFree ? NeoColors.ink : NeoColors.card,
                      shape: BoxShape.circle,
                      border: Border.all(color: neo.handsFree ? NeoColors.ink : NeoColors.line),
                    ),
                    child: Icon(neo.handsFree ? Icons.hearing_rounded : Icons.hearing_disabled_rounded,
                        size: 20, color: neo.handsFree ? neo.color : NeoColors.muted),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: TextField(
                controller: _text,
                minLines: 1,
                maxLines: 4,
                enabled: !listening,
                textInputAction: TextInputAction.send,
                onSubmitted: (_) => _send(),
                decoration: InputDecoration(
                  hintText: listening
                      ? 'Listening… let go to send'
                      : neo.handsFree
                          ? 'Say "Hey Neo…" or type'
                          : widget.hint,
                ),
              ),
            ),
            const SizedBox(width: 10),
            if (_hasText)
              _RoundButton(
                label: 'Send',
                color: NeoColors.ink,
                iconColor: NeoColors.onInk,
                icon: Icons.arrow_upward_rounded,
                onTap: neo.isBusy ? null : _send,
              )
            else
              Semantics(
                button: true,
                label: 'Hold to talk to Neo',
                child: GestureDetector(
                  onLongPressStart: (_) => _holdStart(),
                  onLongPressEnd: (_) => neo.stopListeningAndSend(),
                  onLongPressCancel: () => neo.cancelListening(),
                  onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Hold the mic while you talk, then let go.'), duration: Duration(seconds: 2)),
                  ),
                  child: AnimatedScale(
                    scale: listening ? 1.18 : 1,
                    duration: const Duration(milliseconds: 150),
                    child: Container(
                      width: 56,
                      height: 56,
                      decoration: BoxDecoration(color: listening ? NeoColors.ink : neo.color, shape: BoxShape.circle),
                      child: Icon(Icons.mic_none_rounded, color: listening ? NeoColors.onInk : NeoColors.ink),
                    ),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }
}

class _RoundButton extends StatelessWidget {
  const _RoundButton({required this.label, required this.color, required this.iconColor, required this.icon, required this.onTap});
  final String label;
  final Color color, iconColor;
  final IconData icon;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: label,
      child: Material(
        color: color,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onTap,
          child: SizedBox(width: 56, height: 56, child: Icon(icon, color: iconColor)),
        ),
      ),
    );
  }
}

/// Neo's speech bubble, shown over the face.
class SpeechBubble extends StatelessWidget {
  const SpeechBubble({super.key, required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 240),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: const BoxDecoration(
        color: NeoColors.ink,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(14), topRight: Radius.circular(14), bottomRight: Radius.circular(14), bottomLeft: Radius.circular(4),
        ),
      ),
      child: Text(text, maxLines: 5, overflow: TextOverflow.ellipsis, style: const TextStyle(color: NeoColors.onInk, fontSize: 13, height: 1.35)),
    );
  }
}
